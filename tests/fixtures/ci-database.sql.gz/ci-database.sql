-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: ojs_test_ci
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcement_settings`
--

DROP TABLE IF EXISTS `announcement_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement_settings` (
  `announcement_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `announcement_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`announcement_setting_id`),
  UNIQUE KEY `announcement_settings_unique` (`announcement_id`,`locale`,`setting_name`),
  KEY `announcement_settings_announcement_id` (`announcement_id`),
  CONSTRAINT `announcement_settings_announcement_id_foreign` FOREIGN KEY (`announcement_id`) REFERENCES `announcements` (`announcement_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about announcements, including localized properties like names and contents.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_settings`
--

LOCK TABLES `announcement_settings` WRITE;
/*!40000 ALTER TABLE `announcement_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcement_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement_type_settings`
--

DROP TABLE IF EXISTS `announcement_type_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement_type_settings` (
  `announcement_type_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`announcement_type_setting_id`),
  UNIQUE KEY `announcement_type_settings_unique` (`type_id`,`locale`,`setting_name`),
  KEY `announcement_type_settings_type_id` (`type_id`),
  CONSTRAINT `announcement_type_settings_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `announcement_types` (`type_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about announcement types, including localized properties like their names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_type_settings`
--

LOCK TABLES `announcement_type_settings` WRITE;
/*!40000 ALTER TABLE `announcement_type_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcement_type_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement_types`
--

DROP TABLE IF EXISTS `announcement_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcement_types` (
  `type_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint DEFAULT NULL,
  PRIMARY KEY (`type_id`),
  KEY `announcement_types_context_id` (`context_id`),
  CONSTRAINT `announcement_types_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Announcement types allow for announcements to optionally be categorized.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_types`
--

LOCK TABLES `announcement_types` WRITE;
/*!40000 ALTER TABLE `announcement_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcement_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `announcement_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` smallint DEFAULT NULL,
  `assoc_id` bigint DEFAULT NULL,
  `type_id` bigint DEFAULT NULL,
  `date_expire` date DEFAULT NULL,
  `date_posted` datetime NOT NULL,
  PRIMARY KEY (`announcement_id`),
  KEY `announcements_type_id` (`type_id`),
  KEY `announcements_assoc` (`assoc_type`,`assoc_id`),
  CONSTRAINT `announcements_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `announcement_types` (`type_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Announcements are messages that can be presented to users e.g. on the homepage.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `author_affiliation_settings`
--

DROP TABLE IF EXISTS `author_affiliation_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `author_affiliation_settings` (
  `author_affiliation_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `author_affiliation_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`author_affiliation_setting_id`),
  UNIQUE KEY `author_affiliation_settings_unique` (`author_affiliation_id`,`locale`,`setting_name`),
  CONSTRAINT `author_affiliation_settings_author_affiliation_id_foreign` FOREIGN KEY (`author_affiliation_id`) REFERENCES `author_affiliations` (`author_affiliation_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COMMENT='More data about author affiliations';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `author_affiliation_settings`
--

LOCK TABLES `author_affiliation_settings` WRITE;
/*!40000 ALTER TABLE `author_affiliation_settings` DISABLE KEYS */;
INSERT INTO `author_affiliation_settings` VALUES (2,2,'en','name','Check1212'),(3,3,'en','name','Check1212'),(5,5,'en','name','Research Institute'),(10,10,'en','name','Research Institute'),(11,11,'en','name','Science University'),(12,12,'en','name','Science University'),(13,13,'en','name','Science University'),(14,14,'en','name','Science University'),(15,15,'en','name','Science University'),(16,16,'en','name','Science University'),(17,17,'en','name','State University');
/*!40000 ALTER TABLE `author_affiliation_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `author_affiliations`
--

DROP TABLE IF EXISTS `author_affiliations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `author_affiliations` (
  `author_affiliation_id` bigint NOT NULL AUTO_INCREMENT,
  `author_id` bigint NOT NULL,
  `ror` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`author_affiliation_id`),
  KEY `author_affiliations_ror` (`ror`),
  KEY `author_affiliations_author_id_foreign` (`author_id`),
  CONSTRAINT `author_affiliations_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `authors` (`author_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COMMENT='Author affiliations';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `author_affiliations`
--

LOCK TABLES `author_affiliations` WRITE;
/*!40000 ALTER TABLE `author_affiliations` DISABLE KEYS */;
INSERT INTO `author_affiliations` VALUES (2,5,NULL),(3,6,NULL),(5,15,NULL),(10,20,NULL),(11,21,NULL),(12,22,NULL),(13,23,NULL),(14,24,NULL),(15,25,NULL),(16,26,NULL),(17,27,NULL);
/*!40000 ALTER TABLE `author_affiliations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `author_settings`
--

DROP TABLE IF EXISTS `author_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `author_settings` (
  `author_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `author_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`author_setting_id`),
  UNIQUE KEY `author_settings_unique` (`author_id`,`locale`,`setting_name`),
  KEY `author_settings_author_id` (`author_id`),
  CONSTRAINT `author_settings_author_id` FOREIGN KEY (`author_id`) REFERENCES `authors` (`author_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb3 COMMENT='More data about authors, including localized properties such as their name and affiliation.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `author_settings`
--

LOCK TABLES `author_settings` WRITE;
/*!40000 ALTER TABLE `author_settings` DISABLE KEYS */;
INSERT INTO `author_settings` VALUES (1,1,'','country','US'),(2,1,'en','familyName','Author1'),(3,1,'en','givenName','Test1'),(4,2,'','country','CA'),(5,2,'en','familyName','Author2'),(6,2,'en','givenName','Test2'),(7,3,'','country','CA'),(8,3,'en','familyName','Author3'),(9,3,'en','givenName','Test3'),(13,5,'','country','UM'),(14,5,'en','familyName','Author5'),(15,5,'en','givenName','Test5'),(16,6,'','country','UM'),(17,6,'en','familyName','Author6'),(18,6,'en','givenName','Test6'),(27,11,'en','familyName','Author11'),(28,11,'en','givenName','Test11'),(29,12,'en','biography',''),(30,12,'','country','US'),(31,12,'en','familyName','Author12'),(32,12,'en','givenName','Test12'),(33,12,'en','preferredPublicName','Test Author 12'),(34,13,'','country','US'),(35,13,'en','familyName','Author13'),(36,13,'en','givenName','Test13'),(40,15,'','country','GB'),(41,15,'en','familyName','Author15'),(42,15,'en','givenName','Test15'),(55,20,'','country','GB'),(56,20,'en','familyName','Author20'),(57,20,'en','givenName','Test20'),(58,21,'','country','MY'),(59,21,'en','familyName','Author21'),(60,21,'en','givenName','Test21'),(61,22,'','country','MY'),(62,22,'en','familyName','Author22'),(63,22,'en','givenName','Test22'),(64,23,'','country','MY'),(65,23,'en','familyName','Author23'),(66,23,'en','givenName','Test23'),(67,24,'','country','MY'),(68,24,'en','familyName','Author24'),(69,24,'en','givenName','Test24'),(70,25,'','country','MY'),(71,25,'en','familyName','Author25'),(72,25,'en','givenName','Test25'),(73,26,'','country','MY'),(74,26,'en','familyName','Author26'),(75,26,'en','givenName','Test26'),(76,27,'','country','US'),(77,27,'en','familyName','Author27'),(78,27,'en','givenName','Test27');
/*!40000 ALTER TABLE `author_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authors` (
  `author_id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(90) NOT NULL,
  `include_in_browse` smallint NOT NULL DEFAULT '1',
  `publication_id` bigint NOT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `user_group_id` bigint DEFAULT NULL,
  PRIMARY KEY (`author_id`),
  KEY `authors_user_group_id` (`user_group_id`),
  KEY `authors_publication_id` (`publication_id`),
  CONSTRAINT `authors_publication_id_foreign` FOREIGN KEY (`publication_id`) REFERENCES `publications` (`publication_id`) ON DELETE CASCADE,
  CONSTRAINT `authors_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`user_group_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3 COMMENT='The authors of a publication.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES (1,'ci_author_1@example.test',1,3,0,14),(2,'ci_author_2@example.test',1,4,0,14),(3,'ci_author_3@example.test',1,5,0,14),(5,'ci_author_5@example.test',1,7,0,14),(6,'ci_author_6@example.test',1,8,0,14),(11,'ci_author_11@example.test',1,15,1,14),(12,'ci_author_12@example.test',1,16,0,14),(13,'ci_author_13@example.test',1,18,0,14),(15,'ci_author_15@example.test',1,20,0,14),(20,'ci_author_20@example.test',1,25,0,14),(21,'ci_author_21@example.test',1,26,0,14),(22,'ci_author_22@example.test',1,27,0,14),(23,'ci_author_23@example.test',1,28,0,14),(24,'ci_author_24@example.test',1,30,0,14),(25,'ci_author_25@example.test',1,31,0,14),(26,'ci_author_26@example.test',1,32,0,14),(27,'ci_author_27@example.test',1,33,0,14);
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `category_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `parent_id` bigint DEFAULT NULL,
  `seq` bigint DEFAULT NULL,
  `path` varchar(255) NOT NULL,
  `image` text,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `category_path` (`context_id`,`path`),
  KEY `category_context_id` (`context_id`),
  KEY `category_context_parent_id` (`context_id`,`parent_id`),
  KEY `category_parent_id` (`parent_id`),
  CONSTRAINT `categories_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Categories permit the organization of submissions into a heirarchical structure.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_settings`
--

DROP TABLE IF EXISTS `category_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_settings` (
  `category_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`category_setting_id`),
  UNIQUE KEY `category_settings_unique` (`category_id`,`locale`,`setting_name`),
  KEY `category_settings_category_id` (`category_id`),
  CONSTRAINT `category_settings_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about categories, including localized properties such as names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_settings`
--

LOCK TABLES `category_settings` WRITE;
/*!40000 ALTER TABLE `category_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `category_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citation_settings`
--

DROP TABLE IF EXISTS `citation_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `citation_settings` (
  `citation_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `citation_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`citation_setting_id`),
  UNIQUE KEY `citation_settings_unique` (`citation_id`,`locale`,`setting_name`),
  KEY `citation_settings_citation_id` (`citation_id`),
  CONSTRAINT `citation_settings_citation_id` FOREIGN KEY (`citation_id`) REFERENCES `citations` (`citation_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Additional data about citations, including localized content.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citation_settings`
--

LOCK TABLES `citation_settings` WRITE;
/*!40000 ALTER TABLE `citation_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `citation_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citations`
--

DROP TABLE IF EXISTS `citations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `citations` (
  `citation_id` bigint NOT NULL AUTO_INCREMENT,
  `publication_id` bigint NOT NULL,
  `raw_citation` text NOT NULL,
  `seq` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`citation_id`),
  UNIQUE KEY `citations_publication_seq` (`publication_id`,`seq`),
  KEY `citations_publication` (`publication_id`),
  CONSTRAINT `citations_publication` FOREIGN KEY (`publication_id`) REFERENCES `publications` (`publication_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='A citation made by an associated publication.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citations`
--

LOCK TABLES `citations` WRITE;
/*!40000 ALTER TABLE `citations` DISABLE KEYS */;
/*!40000 ALTER TABLE `citations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `completed_payments`
--

DROP TABLE IF EXISTS `completed_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `completed_payments` (
  `completed_payment_id` bigint NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `payment_type` bigint NOT NULL,
  `context_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `assoc_id` bigint DEFAULT NULL,
  `amount` decimal(8,2) unsigned NOT NULL,
  `currency_code_alpha` varchar(3) DEFAULT NULL,
  `payment_method_plugin_name` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`completed_payment_id`),
  KEY `completed_payments_context_id` (`context_id`),
  KEY `completed_payments_user_id` (`user_id`),
  CONSTRAINT `completed_payments_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `completed_payments_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='A list of completed (fulfilled) payments relating to a payment type such as a subscription payment.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `completed_payments`
--

LOCK TABLES `completed_payments` WRITE;
/*!40000 ALTER TABLE `completed_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `completed_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controlled_vocab_entries`
--

DROP TABLE IF EXISTS `controlled_vocab_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `controlled_vocab_entries` (
  `controlled_vocab_entry_id` bigint NOT NULL AUTO_INCREMENT,
  `controlled_vocab_id` bigint NOT NULL,
  `seq` double DEFAULT NULL,
  PRIMARY KEY (`controlled_vocab_entry_id`),
  KEY `controlled_vocab_entries_controlled_vocab_id` (`controlled_vocab_id`),
  KEY `controlled_vocab_entries_cv_id` (`controlled_vocab_id`,`seq`),
  CONSTRAINT `controlled_vocab_entries_controlled_vocab_id_foreign` FOREIGN KEY (`controlled_vocab_id`) REFERENCES `controlled_vocabs` (`controlled_vocab_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb3 COMMENT='The order that a word or phrase used in a controlled vocabulary should appear. For example, the order of keywords in a publication.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controlled_vocab_entries`
--

LOCK TABLES `controlled_vocab_entries` WRITE;
/*!40000 ALTER TABLE `controlled_vocab_entries` DISABLE KEYS */;
INSERT INTO `controlled_vocab_entries` VALUES (3,5,1),(4,5,2),(19,5,3),(38,10,1),(42,14,1),(43,14,2),(44,14,3),(11,18,1),(12,18,2),(13,18,3),(16,26,1),(33,30,1);
/*!40000 ALTER TABLE `controlled_vocab_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controlled_vocab_entry_settings`
--

DROP TABLE IF EXISTS `controlled_vocab_entry_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `controlled_vocab_entry_settings` (
  `controlled_vocab_entry_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `controlled_vocab_entry_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`controlled_vocab_entry_setting_id`),
  UNIQUE KEY `c_v_e_s_pkey` (`controlled_vocab_entry_id`,`locale`,`setting_name`),
  KEY `c_v_e_s_entry_id` (`controlled_vocab_entry_id`),
  CONSTRAINT `c_v_e_s_entry_id` FOREIGN KEY (`controlled_vocab_entry_id`) REFERENCES `controlled_vocab_entries` (`controlled_vocab_entry_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb3 COMMENT='More data about a controlled vocabulary entry, including localized properties such as the actual word or phrase.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controlled_vocab_entry_settings`
--

LOCK TABLES `controlled_vocab_entry_settings` WRITE;
/*!40000 ALTER TABLE `controlled_vocab_entry_settings` DISABLE KEYS */;
INSERT INTO `controlled_vocab_entry_settings` VALUES (3,3,'','name','stuff'),(4,4,'','name','things'),(11,11,'en','name','Poetics'),(12,12,'en','name','Modernism'),(13,13,'en','name','Affect Theory'),(16,16,'en','name','nonsense, chocolate, cheese, four score and seven years ago i decided to see if i could make a keyword that was too long for the system'),(19,19,'','name','Only the good shit'),(33,33,'en','name','banality, scum, villainy, numb3rzzz'),(38,38,'en','name','Testing'),(42,42,'en','name','Marxism'),(43,43,'en','name','Psychoanalysis'),(44,44,'en','name','New Materialism');
/*!40000 ALTER TABLE `controlled_vocab_entry_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `controlled_vocabs`
--

DROP TABLE IF EXISTS `controlled_vocabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `controlled_vocabs` (
  `controlled_vocab_id` bigint NOT NULL AUTO_INCREMENT,
  `symbolic` varchar(64) NOT NULL,
  `assoc_type` bigint NOT NULL DEFAULT '0',
  `assoc_id` bigint DEFAULT NULL,
  PRIMARY KEY (`controlled_vocab_id`),
  UNIQUE KEY `controlled_vocab_symbolic` (`symbolic`,`assoc_type`,`assoc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb3 COMMENT='Every word or phrase used in a controlled vocabulary. Controlled vocabularies are used for submission metadata like keywords and subjects, reviewer interests, and wherever a similar dictionary of words or phrases is required. Each entry corresponds to a word or phrase like "cellular reproduction" and a type like "submissionKeyword".';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `controlled_vocabs`
--

LOCK TABLES `controlled_vocabs` WRITE;
/*!40000 ALTER TABLE `controlled_vocabs` DISABLE KEYS */;
INSERT INTO `controlled_vocabs` VALUES (5,'interest',0,NULL),(13,'submissionAgency',1048588,3),(17,'submissionAgency',1048588,4),(21,'submissionAgency',1048588,5),(29,'submissionAgency',1048588,7),(33,'submissionAgency',1048588,8),(37,'submissionAgency',1048588,9),(57,'submissionAgency',1048588,15),(61,'submissionAgency',1048588,16),(65,'submissionAgency',1048588,17),(69,'submissionAgency',1048588,18),(93,'submissionAgency',1048588,20),(89,'submissionAgency',1048588,25),(97,'submissionAgency',1048588,26),(101,'submissionAgency',1048588,27),(105,'submissionAgency',1048588,28),(109,'submissionAgency',1048588,29),(113,'submissionAgency',1048588,30),(117,'submissionAgency',1048588,31),(121,'submissionAgency',1048588,32),(125,'submissionAgency',1048588,33),(12,'submissionDiscipline',1048588,3),(16,'submissionDiscipline',1048588,4),(20,'submissionDiscipline',1048588,5),(28,'submissionDiscipline',1048588,7),(32,'submissionDiscipline',1048588,8),(36,'submissionDiscipline',1048588,9),(56,'submissionDiscipline',1048588,15),(60,'submissionDiscipline',1048588,16),(64,'submissionDiscipline',1048588,17),(68,'submissionDiscipline',1048588,18),(92,'submissionDiscipline',1048588,20),(88,'submissionDiscipline',1048588,25),(96,'submissionDiscipline',1048588,26),(100,'submissionDiscipline',1048588,27),(104,'submissionDiscipline',1048588,28),(108,'submissionDiscipline',1048588,29),(112,'submissionDiscipline',1048588,30),(116,'submissionDiscipline',1048588,31),(120,'submissionDiscipline',1048588,32),(124,'submissionDiscipline',1048588,33),(10,'submissionKeyword',1048588,3),(14,'submissionKeyword',1048588,4),(18,'submissionKeyword',1048588,5),(26,'submissionKeyword',1048588,7),(30,'submissionKeyword',1048588,8),(34,'submissionKeyword',1048588,9),(54,'submissionKeyword',1048588,15),(58,'submissionKeyword',1048588,16),(62,'submissionKeyword',1048588,17),(66,'submissionKeyword',1048588,18),(90,'submissionKeyword',1048588,20),(86,'submissionKeyword',1048588,25),(94,'submissionKeyword',1048588,26),(98,'submissionKeyword',1048588,27),(102,'submissionKeyword',1048588,28),(106,'submissionKeyword',1048588,29),(110,'submissionKeyword',1048588,30),(114,'submissionKeyword',1048588,31),(118,'submissionKeyword',1048588,32),(122,'submissionKeyword',1048588,33),(11,'submissionSubject',1048588,3),(15,'submissionSubject',1048588,4),(19,'submissionSubject',1048588,5),(27,'submissionSubject',1048588,7),(31,'submissionSubject',1048588,8),(35,'submissionSubject',1048588,9),(55,'submissionSubject',1048588,15),(59,'submissionSubject',1048588,16),(63,'submissionSubject',1048588,17),(67,'submissionSubject',1048588,18),(91,'submissionSubject',1048588,20),(87,'submissionSubject',1048588,25),(95,'submissionSubject',1048588,26),(99,'submissionSubject',1048588,27),(103,'submissionSubject',1048588,28),(107,'submissionSubject',1048588,29),(111,'submissionSubject',1048588,30),(115,'submissionSubject',1048588,31),(119,'submissionSubject',1048588,32),(123,'submissionSubject',1048588,33);
/*!40000 ALTER TABLE `controlled_vocabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_issue_orders`
--

DROP TABLE IF EXISTS `custom_issue_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_issue_orders` (
  `custom_issue_order_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `issue_id` bigint NOT NULL,
  `journal_id` bigint NOT NULL,
  `seq` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`custom_issue_order_id`),
  UNIQUE KEY `custom_issue_orders_unique` (`issue_id`),
  KEY `custom_issue_orders_issue_id` (`issue_id`),
  KEY `custom_issue_orders_journal_id` (`journal_id`),
  CONSTRAINT `custom_issue_orders_issue_id` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE,
  CONSTRAINT `custom_issue_orders_journal_id` FOREIGN KEY (`journal_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Ordering information for the issue list, when custom issue ordering is specified.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_issue_orders`
--

LOCK TABLES `custom_issue_orders` WRITE;
/*!40000 ALTER TABLE `custom_issue_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_issue_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_section_orders`
--

DROP TABLE IF EXISTS `custom_section_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_section_orders` (
  `custom_section_order_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `issue_id` bigint NOT NULL,
  `section_id` bigint NOT NULL,
  `seq` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`custom_section_order_id`),
  UNIQUE KEY `custom_section_orders_unique` (`issue_id`,`section_id`),
  KEY `custom_section_orders_issue_id` (`issue_id`),
  KEY `custom_section_orders_section_id` (`section_id`),
  CONSTRAINT `custom_section_orders_issue_id` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE,
  CONSTRAINT `custom_section_orders_section_id` FOREIGN KEY (`section_id`) REFERENCES `sections` (`section_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Ordering information for sections within issues, when issue-specific section ordering is specified.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_section_orders`
--

LOCK TABLES `custom_section_orders` WRITE;
/*!40000 ALTER TABLE `custom_section_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_section_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_object_tombstone_oai_set_objects`
--

DROP TABLE IF EXISTS `data_object_tombstone_oai_set_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_object_tombstone_oai_set_objects` (
  `object_id` bigint NOT NULL AUTO_INCREMENT,
  `tombstone_id` bigint NOT NULL,
  `assoc_type` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  PRIMARY KEY (`object_id`),
  KEY `data_object_tombstone_oai_set_objects_tombstone_id` (`tombstone_id`),
  CONSTRAINT `data_object_tombstone_oai_set_objects_tombstone_id` FOREIGN KEY (`tombstone_id`) REFERENCES `data_object_tombstones` (`tombstone_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Relationships between tombstones and other data that can be collected in OAI sets, e.g. sections.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_object_tombstone_oai_set_objects`
--

LOCK TABLES `data_object_tombstone_oai_set_objects` WRITE;
/*!40000 ALTER TABLE `data_object_tombstone_oai_set_objects` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_object_tombstone_oai_set_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_object_tombstone_settings`
--

DROP TABLE IF EXISTS `data_object_tombstone_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_object_tombstone_settings` (
  `tombstone_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tombstone_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`tombstone_setting_id`),
  UNIQUE KEY `data_object_tombstone_settings_unique` (`tombstone_id`,`locale`,`setting_name`),
  KEY `data_object_tombstone_settings_tombstone_id` (`tombstone_id`),
  CONSTRAINT `data_object_tombstone_settings_tombstone_id` FOREIGN KEY (`tombstone_id`) REFERENCES `data_object_tombstones` (`tombstone_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about data object tombstones, including localized content.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_object_tombstone_settings`
--

LOCK TABLES `data_object_tombstone_settings` WRITE;
/*!40000 ALTER TABLE `data_object_tombstone_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_object_tombstone_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_object_tombstones`
--

DROP TABLE IF EXISTS `data_object_tombstones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_object_tombstones` (
  `tombstone_id` bigint NOT NULL AUTO_INCREMENT,
  `data_object_id` bigint NOT NULL,
  `date_deleted` datetime NOT NULL,
  `set_spec` varchar(255) NOT NULL,
  `set_name` varchar(255) NOT NULL,
  `oai_identifier` varchar(255) NOT NULL,
  PRIMARY KEY (`tombstone_id`),
  KEY `data_object_tombstones_data_object_id` (`data_object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Entries for published data that has been removed. Usually used in the OAI endpoint.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_object_tombstones`
--

LOCK TABLES `data_object_tombstones` WRITE;
/*!40000 ALTER TABLE `data_object_tombstones` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_object_tombstones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doi_settings`
--

DROP TABLE IF EXISTS `doi_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doi_settings` (
  `doi_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `doi_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`doi_setting_id`),
  UNIQUE KEY `doi_settings_unique` (`doi_id`,`locale`,`setting_name`),
  KEY `doi_settings_doi_id` (`doi_id`),
  CONSTRAINT `doi_settings_doi_id_foreign` FOREIGN KEY (`doi_id`) REFERENCES `dois` (`doi_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about DOIs, including the registration agency.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doi_settings`
--

LOCK TABLES `doi_settings` WRITE;
/*!40000 ALTER TABLE `doi_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `doi_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dois`
--

DROP TABLE IF EXISTS `dois`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dois` (
  `doi_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `doi` varchar(255) NOT NULL,
  `status` smallint NOT NULL DEFAULT '1',
  PRIMARY KEY (`doi_id`),
  KEY `dois_context_id` (`context_id`),
  CONSTRAINT `dois_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Stores all DOIs used in the system.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dois`
--

LOCK TABLES `dois` WRITE;
/*!40000 ALTER TABLE `dois` DISABLE KEYS */;
/*!40000 ALTER TABLE `dois` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `edit_decisions`
--

DROP TABLE IF EXISTS `edit_decisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `edit_decisions` (
  `edit_decision_id` bigint NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `review_round_id` bigint DEFAULT NULL,
  `stage_id` bigint DEFAULT NULL,
  `round` smallint DEFAULT NULL,
  `editor_id` bigint NOT NULL,
  `decision` smallint NOT NULL COMMENT 'A numeric constant indicating the decision that was taken. Possible values are listed in the Decision class.',
  `date_decided` datetime NOT NULL,
  PRIMARY KEY (`edit_decision_id`),
  KEY `edit_decisions_submission_id` (`submission_id`),
  KEY `edit_decisions_editor_id` (`editor_id`),
  KEY `edit_decisions_review_round_id` (`review_round_id`),
  CONSTRAINT `edit_decisions_editor_id` FOREIGN KEY (`editor_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `edit_decisions_review_round_id_foreign` FOREIGN KEY (`review_round_id`) REFERENCES `review_rounds` (`review_round_id`) ON DELETE CASCADE,
  CONSTRAINT `edit_decisions_submission_id` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb3 COMMENT='Editorial decisions recorded on a submission, such as decisions to accept or decline the submission, as well as decisions to send for review, send to copyediting, request revisions, and more.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edit_decisions`
--

LOCK TABLES `edit_decisions` WRITE;
/*!40000 ALTER TABLE `edit_decisions` DISABLE KEYS */;
INSERT INTO `edit_decisions` VALUES (2,3,NULL,1,NULL,1,3,'2025-11-21 18:12:06'),(3,3,1,3,1,1,2,'2025-11-23 19:15:33'),(4,3,NULL,4,NULL,1,30,'2025-11-23 19:15:59'),(5,3,1,3,1,1,4,'2025-11-23 19:16:20'),(6,3,1,3,1,1,2,'2025-11-23 19:18:40'),(7,5,NULL,1,NULL,12,8,'2025-12-19 19:13:05'),(8,4,NULL,1,NULL,12,3,'2025-12-19 19:14:22'),(9,4,2,3,1,12,2,'2025-12-20 01:07:40'),(10,8,NULL,1,NULL,13,3,'2025-12-20 06:49:29'),(11,7,NULL,1,NULL,13,3,'2025-12-20 06:49:57'),(12,7,4,3,1,13,6,'2025-12-20 06:53:48'),(13,8,3,3,1,13,5,'2025-12-20 07:30:39'),(14,8,3,3,1,13,14,'2025-12-20 07:35:03'),(15,8,5,3,2,13,2,'2025-12-20 07:39:20'),(25,8,NULL,4,NULL,1,7,'2026-07-06 02:32:58'),(26,8,NULL,5,NULL,1,999,'2026-07-06 15:32:13'),(27,3,NULL,4,NULL,1,7,'2026-07-06 15:45:18'),(28,3,NULL,5,NULL,1,999,'2026-07-06 19:54:00'),(29,4,NULL,4,NULL,1,7,'2026-07-08 21:16:39'),(30,4,NULL,5,NULL,1,999,'2026-07-08 21:28:08'),(31,15,NULL,5,NULL,1,999,'2026-07-08 22:07:31'),(32,9,NULL,1,NULL,1,3,'2026-07-08 23:29:24'),(34,9,NULL,1,NULL,1,3,'2026-07-08 23:30:35'),(36,9,NULL,1,NULL,1,3,'2026-07-09 17:56:00'),(37,9,8,3,1,1,6,'2026-07-19 17:46:47'),(38,9,8,3,1,1,15,'2026-07-19 17:47:03'),(39,9,8,3,1,1,5,'2026-07-19 18:52:18'),(40,9,8,3,1,1,4,'2026-07-20 15:39:42'),(41,16,NULL,1,NULL,1,3,'2026-07-20 15:41:34'),(43,16,NULL,1,NULL,1,3,'2026-07-20 15:42:33'),(44,25,NULL,1,NULL,1,3,'2026-07-23 23:32:20'),(45,31,NULL,1,NULL,1,3,'2026-07-24 19:43:41'),(46,32,NULL,1,NULL,1,3,'2026-07-24 19:48:53'),(47,33,NULL,1,NULL,1,3,'2026-07-24 20:16:36'),(48,33,14,3,1,1,2,'2026-07-25 17:21:21');
/*!40000 ALTER TABLE `edit_decisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_log`
--

DROP TABLE IF EXISTS `email_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_log` (
  `log_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  `sender_id` bigint DEFAULT NULL,
  `date_sent` datetime NOT NULL,
  `event_type` bigint DEFAULT NULL,
  `from_address` varchar(255) DEFAULT NULL,
  `recipients` text,
  `cc_recipients` text,
  `bcc_recipients` text,
  `subject` varchar(255) DEFAULT NULL,
  `body` text,
  PRIMARY KEY (`log_id`),
  KEY `email_log_sender_id` (`sender_id`),
  KEY `email_log_assoc` (`assoc_type`,`assoc_id`),
  CONSTRAINT `email_log_sender_id_foreign` FOREIGN KEY (`sender_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='A record of email messages that are sent in relation to an associated entity, such as a submission.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_log`
--

LOCK TABLES `email_log` WRITE;
/*!40000 ALTER TABLE `email_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_log_users`
--

DROP TABLE IF EXISTS `email_log_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_log_users` (
  `email_log_user_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email_log_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`email_log_user_id`),
  UNIQUE KEY `email_log_user_id` (`email_log_id`,`user_id`),
  KEY `email_log_users_email_log_id` (`email_log_id`),
  KEY `email_log_users_user_id` (`user_id`),
  CONSTRAINT `email_log_users_email_log_id_foreign` FOREIGN KEY (`email_log_id`) REFERENCES `email_log` (`log_id`) ON DELETE CASCADE,
  CONSTRAINT `email_log_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='A record of users associated with an email log entry.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_log_users`
--

LOCK TABLES `email_log_users` WRITE;
/*!40000 ALTER TABLE `email_log_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_log_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `email_id` bigint NOT NULL AUTO_INCREMENT,
  `email_key` varchar(255) NOT NULL COMMENT 'Unique identifier for this email.',
  `context_id` bigint NOT NULL,
  `alternate_to` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`email_id`),
  UNIQUE KEY `email_templates_email_key` (`email_key`,`context_id`),
  KEY `email_templates_context_id` (`context_id`),
  KEY `email_templates_alternate_to` (`alternate_to`),
  CONSTRAINT `email_templates_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COMMENT='Custom email templates created by each context, and overrides of the default templates.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` VALUES (1,'COPYEDIT_REQUEST',1,'DISCUSSION_NOTIFICATION_COPYEDITING'),(2,'EDITOR_ASSIGN_SUBMISSION',1,'DISCUSSION_NOTIFICATION_SUBMISSION'),(3,'EDITOR_ASSIGN_REVIEW',1,'DISCUSSION_NOTIFICATION_REVIEW'),(4,'EDITOR_ASSIGN_PRODUCTION',1,'DISCUSSION_NOTIFICATION_PRODUCTION'),(5,'LAYOUT_REQUEST',1,'DISCUSSION_NOTIFICATION_PRODUCTION'),(6,'LAYOUT_COMPLETE',1,'DISCUSSION_NOTIFICATION_PRODUCTION'),(7,'DISCUSSION_NOTIFICATION_REVIEW',1,NULL),(8,'DISCUSSION_NOTIFICATION_SUBMISSION',1,NULL),(9,'EDITOR_ASSIGN',1,NULL),(10,'EDITORIAL_REMINDER',1,NULL),(11,'editor-decision-template',1,'EDITOR_DECISION_INITIAL_DECLINE'),(12,'decision-template',1,'EDITOR_DECISION_DECLINE'),(13,'SUBMISSION_ACK',1,NULL);
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates_default_data`
--

DROP TABLE IF EXISTS `email_templates_default_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates_default_data` (
  `email_templates_default_data_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email_key` varchar(255) NOT NULL COMMENT 'Unique identifier for this email.',
  `locale` varchar(28) NOT NULL DEFAULT 'en',
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text,
  PRIMARY KEY (`email_templates_default_data_id`),
  UNIQUE KEY `email_templates_default_data_unique` (`email_key`,`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb3 COMMENT='Default email templates created for every installed locale.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates_default_data`
--

LOCK TABLES `email_templates_default_data` WRITE;
/*!40000 ALTER TABLE `email_templates_default_data` DISABLE KEYS */;
INSERT INTO `email_templates_default_data` VALUES (1,'PASSWORD_RESET_CONFIRM','en','Password Reset Confirm','Password Reset Confirmation','We have received a request to reset your password for the {$siteTitle} web site.<br />\n<br />\nIf you did not make this request, please ignore this email and your password will not be changed. If you wish to reset your password, click on the below URL.<br />\n<br />\nReset my password: {$passwordResetUrl}<br />\n<br />\n{$siteContactName}'),(2,'USER_REGISTER','en','User Created','Journal Registration','{$recipientName}<br />\n<br />\nYou have now been registered as a user with {$contextName}. We have included your username and password in this email, which are needed for all work with this journal through its website. At any point, you can ask to be removed from the journal\'s list of users by contacting me.<br />\n<br />\nUsername: {$recipientUsername}<br />\nPassword: {$password}<br />\n<br />\nThank you,<br />\n{$signature}'),(3,'USER_VALIDATE_CONTEXT','en','Validate Email (Journal Registration)','Validate Your Account','{$recipientName}<br />\n<br />\nYou have created an account with {$contextName}, but before you can start using it, you need to validate your email account. To do this, simply follow the link below:<br />\n<br />\n{$activateUrl}<br />\n<br />\nThank you,<br />\n{$contextSignature}'),(4,'USER_VALIDATE_SITE','en','Validate Email (Site)','Validate Your Account','{$recipientName}<br />\n<br />\nYou have created an account with {$siteTitle}, but before you can start using it, you need to validate your email account. To do this, simply follow the link below:<br />\n<br />\n{$activateUrl}<br />\n<br />\nThank you,<br />\n{$siteSignature}'),(5,'REVIEWER_REGISTER','en','Reviewer Register','Registration as Reviewer with {$contextName}','<p>Dear {$recipientName},</p><p>In light of your expertise, we have registered your name in the reviewer database for {$contextName}. This does not entail any form of commitment on your part, but simply enables us to approach you with a submission to possibly review. On being invited to review, you will have an opportunity to see the title and abstract of the paper in question, and you\'ll always be in a position to accept or decline the invitation. You can also ask at any point to have your name removed from this reviewer list.</p><p>We are providing you with a username and password, which is used in all interactions with the journal through its website. You may wish, for example, to update your profile, including your reviewing interests.</p><p>Username: {$recipientUsername}<br />Password: {$password}</p><p>Thank you,</p>{$signature}'),(6,'ISSUE_PUBLISH_NOTIFY','en','Issue Published Notify','Just published: {$issueIdentification} of {$contextName}','<p>Dear {$recipientName},</p><p>We are pleased to announce the publication of <a href=\"{$issueUrl}\">{$issueIdentification}</a> of {$contextName}.  We invite you to read and share this work with your scholarly community.</p><p>Many thanks to our authors, reviewers, and editors for their valuable contributions, and to our readers for your continued interest.</p><div>{$issueToc}</div><p>Thank you,</p>{$signature}'),(7,'SUBMISSION_ACK','en','Submission Confirmation','Thank you for your submission to {$contextName}','<p>Dear {$recipientName},</p><p>Thank you for your submission to {$contextName}. We have received your submission, \"{$submissionTitle}\", and a member of our editorial team will see it soon. You will be sent an email when an initial decision is made, and we may contact you for further information.</p><p>You can view your submission and track its progress through the editorial process at the following location:</p><p>Submission URL: {$authorSubmissionUrl}</p><p>If you have been logged out, you can login again with the username {$recipientUsername}.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>Thank you for considering {$contextName} as a venue for your work.</p>{$contextSignature}'),(8,'SUBMISSION_ACK_NOT_USER','en','Submission Confirmation (Other Authors)','Submission confirmation','<p>Dear {$recipientName},</p><p>You have been named as a co-author on a submission to {$contextName}. The submitter, {$submitterName}, provided the following details:</p><p>\"{$submissionTitle}\"<br>{$authorsWithAffiliation}</p><p>If any of these details are incorrect, or you do not wish to be named on this submission, please contact me.</p><p>Thank you for considering {$contextName} as a venue for your work.</p><p>Kind regards,</p>{$contextSignature}'),(9,'EDITOR_ASSIGN','en','Editor Assigned','You have been assigned as an editor on a submission to {$contextName}','<p>Dear {$recipientName},</p><p>The following submission has been assigned to you to see through the editorial process.</p><p><a href=\"{$submissionUrl}\">{$submissionTitle}</a><br />{$authors}</p><p><b>Abstract</b></p>{$submissionAbstract}<p>If you find the submission to be relevant for {$contextName}, please forward the submission to the review stage by selecting \"Send to Review\" and then assign reviewers by clicking \"Add Reviewer\".</p><p>If the submission is not appropriate for this journal, please decline the submission.</p><p>Thank you in advance.</p><p>Kind regards,</p>{$contextSignature}'),(10,'REVIEW_CANCEL','en','Reviewer Unassign','Request for Review Cancelled','<p>Dear {$recipientName},</p><p>Recently, we asked you to review a submission to {$contextName}. We have decided to cancel the request for you to reivew the submission, {$submissionTitle}.</p><p>We apologize any inconvenience this may cause you and hope that we will be able to call on you to assist with this journal\'s review process in the future.</p><p>If you have any questions, please contact me.</p>{$signature}'),(11,'REVIEW_REINSTATE','en','Reviewer Reinstate','Can you still review something for {$contextName}?','<p>Dear {$recipientName},</p><p>We recently cancelled our request for you to review a submission, {$submissionTitle}, for {$contextName}. We\'ve reversed that decision and we hope that you are still able to conduct the review.</p><p>If you are able to assist with this submission\'s review, you can <a href=\"{$reviewAssignmentUrl}\">login to the journal</a> to view the submission, upload review files, and submit your review request.</p><p>If you have any questions, please contact me.</p><p>Kind regards,</p>{$signature}'),(12,'REVIEW_RESEND_REQUEST','en','Resend Review Request to Reviewer','Requesting your review again for {$contextName}','<p>Dear {$recipientName},</p><p>Recently, you declined our request to review a submission, \"{$submissionTitle}\", for {$contextName}. I\'m writing to see if you are able to conduct the review after all.</p><p>We would be grateful if you\'re able to perform this review, but we understand if that is not possible at this time. Either way, please <a href=\"{$reviewAssignmentUrl}\">accept or decline the request</a> by {$responseDueDate}, so that we can find an alternate reviewer.</p><p>If you have any questions, please contact me.</p><p>Kind regards,</p>{$signature}'),(13,'REVIEW_REQUEST','en','Review Request','Invitation to review','<p>Dear {$recipientName},</p><p>I believe that you would serve as an excellent reviewer for a submission  to {$contextName}. The submission\'s title and abstract are below, and I hope that you will consider undertaking this important task for us.</p><p>If you are able to review this submission, your review is due by {$reviewDueDate}. You can view the submission, upload review files, and submit your review by logging into the journal site and following the steps at the link below.</p><p><a href=\"{$reviewAssignmentUrl}\">{$submissionTitle}</a></p><p><b>Abstract</b></p>{$submissionAbstract}<p>Please <a href=\"{$reviewAssignmentUrl}\">accept or decline</a> the review by <b>{$responseDueDate}</b>.</p><p>You may contact me with any questions about the submission or the review process.</p><p>Thank you for considering this request. Your help is much appreciated.</p><p>Kind regards,</p>{$signature}'),(14,'REVIEW_REQUEST_SUBSEQUENT','en','Review Request Subsequent','Request to review a revised submission','<p>Dear {$recipientName},</p><p>Thank you for your review of <a href=\"{$reviewAssignmentUrl}\">{$submissionTitle}</a>. The authors have considered the reviewers\' feedback and have now submitted a revised version of their work. I\'m writing to ask if you would conduct a second round of peer review for this submission.</p><p>If you are able to review this submission, your review is due by {$reviewDueDate}. You can <a href=\"{$reviewAssignmentUrl}\">follow the review steps</a> to view the submission, upload review files, and submit your review comments.<p><p><a href=\"{$reviewAssignmentUrl}\">{$submissionTitle}</a></p><p><b>Abstract</b></p>{$submissionAbstract}<p>Please <a href=\"{$reviewAssignmentUrl}\">accept or decline</a> the review by <b>{$responseDueDate}</b>.</p><p>Please feel free to contact me with any questions about the submission or the review process.</p><p>Thank you for considering this request. Your help is much appreciated.</p><p>Kind regards,</p>{$signature}'),(15,'REVIEW_RESPONSE_OVERDUE_AUTO','en','Review Response Overdue (Automated)','Will you be able to review this for us?','<p>Dear {$recipientName},</p><p>This email is an automated reminder from {$contextName} in regards to our request for your review of the submission, \"{$submissionTitle}.\"</p><p>You are receiving this email because we have not yet received a confirmation from you indicating whether or not you are able to undertake the review of this submission.</p><p>Please let us know whether or not you are able to undertake this review by using our submission management software to accept or decline this request.</p><p>If you are able to review this submission, your review is due by {$reviewDueDate}. You can follow the review steps to view the submission, upload review files, and submit your review comments.</p><p><a href=\"{$reviewAssignmentUrl}\">{$submissionTitle}</a></p><p><b>Abstract</b></p>{$submissionAbstract}<p>Please feel free to contact me with any questions about the submission or the review process.</p><p>Thank you for considering this request. Your help is much appreciated.</p><p>Kind regards,</p>{$contextSignature}'),(16,'REVIEW_CONFIRM','en','Review Confirm','Review accepted: {$reviewerName} accepted review assignment for #{$submissionId} {$authorsShort} — \"{$submissionTitle}\"','<p>Dear {$recipientName},</p><p>{$reviewerName} has accepted the following review:</p><p><a href=\"{$submissionUrl}\">#{$submissionId} {$authorsShort} — \"{$submissionTitle}\"</a><br /><b>Type:</b> {$reviewMethod}</p><p><b>Review Due:</b> {$reviewDueDate}</p><p>Login to <a href=\"{$submissionUrl}\">view all reviewer assignments</a> for this submission.</p><br><br>—<br>This is an automated message from <a href=\"{$contextUrl}\">{$contextName}</a>.'),(17,'REVIEW_DECLINE','en','Review Decline','Unable to Review','Editors:<br />\n<br />\nI am afraid that at this time I am unable to review the submission, &quot;{$submissionTitle},&quot; for {$contextName}. Thank you for thinking of me, and another time feel free to call on me.<br />\n<br />\n{$senderName}'),(18,'REVIEW_ACK','en','Review Acknowledgement','Thank you for your review','<p>Dear {$recipientName},</p>\n<p>Thank you for completing your review of the submission, \"{$submissionTitle}\", for {$contextName}. We appreciate your time and expertise in contributing to the quality of the work that we publish.</p>\n<p>It has been a pleasure to work with you as a reviewer for {$contextName}, and we hope to have the opportunity to work with you again in the future.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>'),(19,'REVIEW_REMIND','en','Review Reminder','A reminder to please complete your review','<p>Dear {$recipientName},</p><p>Just a gentle reminder of our request for your review of the submission, \"{$submissionTitle},\" for {$contextName}. We were expecting to have this review by {$reviewDueDate} and we would be pleased to receive it as soon as you are able to prepare it.</p><p>You can <a href=\"{$reviewAssignmentUrl}\">login to the journal</a> and follow the review steps to view the submission, upload review files, and submit your review comments.</p><p>If you need an extension of the deadline, please contact me. I look forward to hearing from you.</p><p>Thank you in advance and kind regards,</p>{$signature}'),(20,'REVIEW_REMIND_AUTO','en','Review Reminder (Automated)','A reminder to please complete your review','<p>Dear {$recipientName}:</p><p>This email is an automated reminder from {$contextName} in regards to our request for your review of the submission, \"{$submissionTitle}.\"</p><p>We were expecting to have this review by {$reviewDueDate} and we would be pleased to receive it as soon as you are able to prepare it.</p><p>Please <a href=\"{$reviewAssignmentUrl}\">login to the journal</a> and follow the review steps to view the submission, upload review files, and submit your review comments.</p><p>If you need an extension of the deadline, please contact me. I look forward to hearing from you.</p><p>Thank you in advance and kind regards,</p>{$contextSignature}'),(21,'REVIEW_COMPLETE','en','Review Completed','Review complete: {$reviewerName} recommends {$reviewRecommendation} for #{$submissionId} {$authorsShort} — \"{$submissionTitle}\"','<p>Dear {$recipientName},</p><p>{$reviewerName} completed the following review:</p><p><a href=\"{$submissionUrl}\">#{$submissionId} {$authorsShort} — \"{$submissionTitle}\"</a><br /><b>Recommendation:</b> {$reviewRecommendation}<br /><b>Type:</b> {$reviewMethod}</p><p>Login to <a href=\"{$submissionUrl}\">view all files and comments</a> provided by this reviewer.</p>'),(22,'REVIEW_EDIT','en','Review Edited','Your review assignment has been changed for {$contextName}','<p>Dear {$recipientName},</p><p>An editor has made changes to your review assignment for {$contextName}. Please review the details below and let us know if you have any questions.</p><p><a href=\"{$reviewAssignmentUrl}\">\"{$submissionTitle}\"</a><br /><b>Type:</b> {$reviewMethod}<br /><b>Accept or Decline By:</b> {$responseDueDate}<br /><b>Submit Review By:</b> {$reviewDueDate}</p><p>You can login to <a href=\"{$reviewAssignmentUrl}\">complete this review</a> at any time.</p>'),(23,'EDITOR_DECISION_ACCEPT','en','Submission Accepted','Your submission has been accepted to {$contextName}','<p>Dear {$recipientName},</p><p>I am pleased to inform you that we have decided to accept your submission without further revision. After careful review, we found your submission, {$submissionTitle}, to meet or exceed our expectations. We are excited to publish your piece in {$contextName} and we thank you for choosing our journal as a venue for your work.</p><p>Your submission is now forthcoming in a future issue of {$contextName} and you are welcome to include it in your list of publications. We recognize the hard work that goes into every successful submission and we want to congratulate you on reaching this stage.</p><p>Your submission will now undergo copy editing and formatting to prepare it for publication.</p><p>You will shortly receive further instructions.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>Kind regards,</p>{$signature}'),(24,'EDITOR_DECISION_SEND_TO_EXTERNAL','en','Sent to Review','Your submission has been sent for review','<p>Dear {$recipientName},</p><p>I am pleased to inform you that an editor has reviewed your submission, \"{$submissionTitle}\", and has decided to send it for peer review. An editor will identify qualified reviewers who will provide feedback on your submission.</p><p>{$reviewTypeDescription} You will hear from us with feedback from the reviewers and information about the next steps.</p><p>Please note that sending the submission to peer review does not guarantee that it will be published. We will consider the reviewers\' recommendations before deciding to accept the submission for publication. You may be asked to make revisions and respond to the reviewers\' comments before a final decision is made.</p><p>If you have any questions, please contact me from your submission dashboard.</p><p>{$signature}</p>'),(25,'EDITOR_DECISION_SEND_TO_PRODUCTION','en','Sent to Production','Next steps for publishing your submission','<p>Dear {$recipientName},</p><p>I am writing from {$contextName} to let you know that the editing of your submission, \"{$submissionTitle}\", is complete. Your submission will now advance to the production stage, where the final galleys will be prepared for publication. We will contact you if we need any further assistance.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>Kind regards,</p>{$signature}'),(26,'EDITOR_DECISION_REVISIONS','en','Revisions Requested','Your submission has been reviewed and we encourage you to submit revisions','<p>Dear {$recipientName},</p><p>Your submission \"{$submissionTitle}\" has been reviewed and we would like to encourage you to submit revisions that address the reviewers\' comments. An editor will review these revisions and if they address the concerns adequately, your submission may be accepted for publication.</p><p>The reviewers\' comments are included at the bottom of this email. Please respond to each point in the reviewers\' comments and identify what changes you have made. If you find any of the reviewer\'s comments to be unjustified or inappropriate, please explain your perspective.</p><p>When you have completed your revisions, you can upload revised documents along with your response to the reviewers\' comments at your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>. If you have been logged out, you can login again with the username {$recipientUsername}.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>We look forward to receiving your revised submission.</p><p>Kind regards,</p>{$signature}<hr><p>The following comments were received from reviewers.</p>{$allReviewerComments}'),(27,'EDITOR_DECISION_RESUBMIT','en','Resubmit for Review','Your submission has been reviewed - please revise and resubmit','<p>Dear {$recipientName},</p><p>After reviewing your submission, \"{$submissionTitle}\", the reviewers have recommended that your submission cannot be accepted for publication in its current form. However, we would like to encourage you to submit a revised version that addresses the reviewers\' comments. Your revisions will be reviewed by an editor and may be sent out for another round of peer review.</p><p>Please note that resubmitting your work does not guarantee that it will be accepted.</p><p>The reviewers\' comments are included at the bottom of this email. Please respond to each point and identify what changes you have made. If you find any of the reviewer\'s comments inappropriate, please explain your perspective. If you have questions about the recommendations in your review, please include these in your response.</p><p>When you have completed your revisions, you can upload revised documents along with your response to the reviewers\' comments <a href=\"{$authorSubmissionUrl}\">at your submission dashboard</a>. If you have been logged out, you can login again with the username {$recipientUsername}.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>We look forward to receiving your revised submission.</p><p>Kind regards,</p>{$signature}<hr><p>The following comments were received from reviewers.</p>{$allReviewerComments}'),(28,'EDITOR_DECISION_DECLINE','en','Submission Declined','Your submission has been declined','<p>Dear {$recipientName},</p><p>While we appreciate receiving your submission, we are unable to accept \"{$submissionTitle}\" for publication on the basis of the comments from reviewers.</p><p>The reviewers\' comments are included at the bottom of this email.</p><p>Thank you for submitting to {$contextName}. Although it is disappointing to have a submission declined, I hope you find the reviewers\' comments to be constructive and helpful.</p><p>You are now free to submit the work elsewhere if you choose to do so.</p><p>Kind regards,</p>{$signature}<hr><p>The following comments were received from reviewers.</p>{$allReviewerComments}'),(29,'EDITOR_DECISION_INITIAL_DECLINE','en','Submission Declined (Pre-Review)','Your submission has been declined','<p>Dear {$recipientName},</p><p>I’m sorry to inform you that, after reviewing your submission, \"{$submissionTitle}\", the editor has found that it does not meet our requirements for publication in {$contextName}.</p><p>I wish you success if you consider submitting your work elsewhere.</p><p>Kind regards,</p>{$signature}'),(30,'EDITOR_RECOMMENDATION','en','Recommendation Made','Editor Recommendation','<p>Dear {$recipientName},</p><p>After considering the reviewers\' feedback, I would like to make the following recommendation regarding the submission \"{$submissionTitle}\".</p><p>My recommendation is: {$recommendation}.</p><p>Please visit the submission\'s <a href=\"{$submissionUrl}\">editorial workflow</a> to act on this recommendation.</p><p>Please feel free to contact me with any questions.</p><p>Kind regards,</p><p>{$senderName}</p>'),(31,'EDITOR_DECISION_NOTIFY_OTHER_AUTHORS','en','Notify Other Authors','An update regarding your submission','<p>The following email was sent to {$submittingAuthorName} from {$contextName} regarding \"{$submissionTitle}\".</p>\n<p>You are receiving a copy of this notification because you are identified as an author of the submission. Any instructions in the message below are intended for the submitting author, {$submittingAuthorName}, and no action is required of you at this time.</p>\n\n{$messageToSubmittingAuthor}'),(32,'EDITOR_DECISION_NOTIFY_REVIEWERS','en','Notify Reviewers of Decision','Thank you for your review','<p>Dear {$recipientName},</p>\n<p>Thank you for completing your review of the submission, \"{$submissionTitle}\", for {$contextName}. We appreciate your time and expertise in contributing to the quality of the work that we publish. We have shared your comments with the authors, along with our other reviewers\' comments and the editor\'s decision.</p>\n<p>Based on the feedback we received, we have notified the authors of the following:</p>\n<p>{$decisionDescription}</p>\n<p>Your recommendation was considered alongside the recommendations of other reviewers before coming to a decision. Occasionally the editor\'s decision may differ from the recommendation made by one or more reviewers. The editor considers many factors, and does not take these decisions lightly. We are grateful for our reviewers\' expertise and suggestions.</p>\n<p>It has been a pleasure to work with you as a reviewer for {$contextName}, and we hope to have the opportunity to work with you again in the future.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>'),(33,'EDITOR_DECISION_NEW_ROUND','en','New Review Round Initiated','Your submission has been sent for another round of review','<p>Dear {$recipientName},</p>\n<p>Your revised submission, \"{$submissionTitle}\", has been sent for a new round of peer review. \nYou will hear from us with feedback from the reviewers and information about the next steps.</p>\n<p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>\n'),(34,'EDITOR_DECISION_REVERT_DECLINE','en','Reinstate Declined Submission','We have reversed the decision to decline your submission','<p>Dear {$recipientName},</p>\n<p>The decision to decline your submission, \"{$submissionTitle}\", has been reversed. \nAn editor will complete the round of review and you will be notified when a \ndecision is made.</p>\n<p>Occasionally, a decision to decline a submission will be recorded accidentally in \nour system and must be reverted. I apologize for any confusion this may have caused.</p>\n<p>We will contact you if we need any further assistance.</p>\n<p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>\n'),(35,'EDITOR_DECISION_REVERT_INITIAL_DECLINE','en','Reinstate Submission Declined Without Review','We have reversed the decision to decline your submission','<p>Dear {$recipientName},</p>\n<p>The decision to decline your submission, \"{$submissionTitle}\", has been reversed. \nAn editor will look further at your submission before deciding whether to decline \nthe submission or send it for review.</p>\n<p>Occasionally, a decision to decline a submission will be recorded accidentally in \nour system and must be reverted. I apologize for any confusion this may have caused.</p>\n<p>We will contact you if we need any further assistance.</p>\n<p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>\n'),(36,'EDITOR_DECISION_SKIP_REVIEW','en','Submission Accepted (Without Review)','Your submission has been sent for copyediting','<p>Dear {$recipientName},</p>\n<p>I am pleased to inform you that we have decided to accept your submission without peer review. We found your submission, {$submissionTitle}, to meet our expectations, and we do not require that work of this type undergo peer review. We are excited to publish your piece in {$contextName} and we thank you for choosing our journal as a venue for your work.</p>\nYour submission is now forthcoming in a future issue of {$contextName} and you are welcome to include it in your list of publications. We recognize the hard work that goes into every successful submission and we want to congratulate you on your efforts.</p>\n<p>Your submission will now undergo copy editing and formatting to prepare it for publication. </p>\n<p>You will shortly receive further instructions.</p>\n<p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>\n'),(37,'EDITOR_DECISION_BACK_FROM_PRODUCTION','en','Submission Sent Back to Copyediting','Your submission has been sent back to copyediting','<p>Dear {$recipientName},</p><p>Your submission, \"{$submissionTitle}\", has been sent back to the copyediting stage, where it will undergo further copyediting and formatting to prepare it for publication.</p><p>Occasionally, a submission is sent to the production stage before it is ready for the final galleys to be prepared for publication. Your submission is still forthcoming. I apologize for any confusion.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>We will contact you if we need any further assistance.</p><p>Kind regards,</p><p>{$signature}</p>'),(38,'EDITOR_DECISION_BACK_FROM_COPYEDITING','en','Submission Sent Back from Copyediting','Your submission has been sent back to review','<p>Dear {$recipientName},</p><p>Your submission, \"{$submissionTitle}\", has been sent back to the review stage. It will undergo further review before it can be accepted for publication.</p><p>Occasionally, a decision to accept a submission will be recorded accidentally in our system and we must send it back to review. I apologize for any confusion this has caused. We will work to complete any further review quickly so that you have a final decision as soon as possible.</p><p>We will contact you if we need any further assistance.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>Kind regards,</p><p>{$signature}</p>'),(39,'EDITOR_DECISION_CANCEL_REVIEW_ROUND','en','Review Round Cancelled','A review round for your submission has been cancelled','<p>Dear {$recipientName},</p><p>We recently opened a new review round for your submission, \"{$submissionTitle}\". We are closing this review round now.</p><p>Occasionally, a decision to open a round of review will be recorded accidentally in our system and we must cancel this review round. I apologize for any confusion this may have caused.</p><p>We will contact you if we need any further assistance.</p><p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p><p>Kind regards,</p><p>{$signature}</p>'),(40,'SUBSCRIPTION_NOTIFY','en','Subscription Notify','Subscription Notification','{$recipientName}:<br />\n<br />\nYou have now been registered as a subscriber in our online journal management system for {$contextName}, with the following subscription:<br />\n<br />\n{$subscriptionType}<br />\n<br />\nTo access content that is available only to subscribers, simply log in to the system with your username, &quot;{$recipientUsername}&quot;.<br />\n<br />\nOnce you have logged in to the system you can change your profile details and password at any point.<br />\n<br />\nPlease note that if you have an institutional subscription, there is no need for users at your institution to log in, since requests for subscription content will be automatically authenticated by the system.<br />\n<br />\nIf you have any questions, please feel free to contact me.<br />\n<br />\n{$subscriptionSignature}'),(41,'OPEN_ACCESS_NOTIFY','en','Open Access Notify','Free to read: {$issueIdentification} of {$contextName} is now open access','<p>Dear {$recipientName},</p><p>We are pleased to inform you that <a href=\"{$issueUrl}\">{$issueIdentification}</a> of {$contextName} is now available under open access.  A subscription is no longer required to read this issue.</p><p>Thank you for your continuing interest in our work.</p>{$contextSignature}'),(42,'SUBSCRIPTION_BEFORE_EXPIRY','en','Subscription Expires Soon','Notice of Subscription Expiry','{$recipientName}:<br />\n<br />\nYour {$contextName} subscription is about to expire.<br />\n<br />\n{$subscriptionType}<br />\nExpiry date: {$expiryDate}<br />\n<br />\nTo ensure the continuity of your access to this journal, please go to the journal website and renew your subscription. You are able to log in to the system with your username, &quot;{$recipientUsername}&quot;.<br />\n<br />\nIf you have any questions, please feel free to contact me.<br />\n<br />\n{$subscriptionSignature}'),(43,'SUBSCRIPTION_AFTER_EXPIRY','en','Subscription Expired','Subscription Expired','{$recipientName}:<br />\n<br />\nYour {$contextName} subscription has expired.<br />\n<br />\n{$subscriptionType}<br />\nExpiry date: {$expiryDate}<br />\n<br />\nTo renew your subscription, please go to the journal website. You are able to log in to the system with your username, &quot;{$recipientUsername}&quot;.<br />\n<br />\nIf you have any questions, please feel free to contact me.<br />\n<br />\n{$subscriptionSignature}'),(44,'SUBSCRIPTION_AFTER_EXPIRY_LAST','en','Subscription Expired Last','Subscription Expired - Final Reminder','{$recipientName}:<br />\n<br />\nYour {$contextName} subscription has expired.<br />\nPlease note that this is the final reminder that will be emailed to you.<br />\n<br />\n{$subscriptionType}<br />\nExpiry date: {$expiryDate}<br />\n<br />\nTo renew your subscription, please go to the journal website. You are able to log in to the system with your username, &quot;{$recipientUsername}&quot;.<br />\n<br />\nIf you have any questions, please feel free to contact me.<br />\n<br />\n{$subscriptionSignature}'),(45,'SUBSCRIPTION_PURCHASE_INDL','en','Purchase Individual Subscription','Subscription Purchase: Individual','An individual subscription has been purchased online for {$contextName} with the following details.<br />\n<br />\nSubscription Type:<br />\n{$subscriptionType}<br />\n<br />\nUser:<br />\n{$subscriberDetails}<br />\n<br />\nMembership Information (if provided):<br />\n{$membership}<br />\n<br />\nTo view or edit this subscription, please use the following URL.<br />\n<br />\nSubscription URL: {$subscriptionUrl}<br />\n'),(46,'SUBSCRIPTION_PURCHASE_INSTL','en','Purchase Institutional Subscription','Subscription Purchase: Institutional','An institutional subscription has been purchased online for {$contextName} with the following details. To activate this subscription, please use the provided Subscription URL and set the subscription status to \'Active\'.<br />\n<br />\nSubscription Type:<br />\n{$subscriptionType}<br />\n<br />\nInstitution:<br />\n{$institutionName}<br />\n{$institutionMailingAddress}<br />\n<br />\nDomain (if provided):<br />\n{$domain}<br />\n<br />\nIP Ranges (if provided):<br />\n{$ipRanges}<br />\n<br />\nContact Person:<br />\n{$subscriberDetails}<br />\n<br />\nMembership Information (if provided):<br />\n{$membership}<br />\n<br />\nTo view or edit this subscription, please use the following URL.<br />\n<br />\nSubscription URL: {$subscriptionUrl}<br />\n'),(47,'SUBSCRIPTION_RENEW_INDL','en','Renew Individual Subscription','Subscription Renewal: Individual','An individual subscription has been renewed online for {$contextName} with the following details.<br />\n<br />\nSubscription Type:<br />\n{$subscriptionType}<br />\n<br />\nUser:<br />\n{$subscriberDetails}<br />\n<br />\nMembership Information (if provided):<br />\n{$membership}<br />\n<br />\nTo view or edit this subscription, please use the following URL.<br />\n<br />\nSubscription URL: {$subscriptionUrl}<br />\n'),(48,'SUBSCRIPTION_RENEW_INSTL','en','Renew Institutional Subscription','Subscription Renewal: Institutional','An institutional subscription has been renewed online for {$contextName} with the following details.<br />\n<br />\nSubscription Type:<br />\n{$subscriptionType}<br />\n<br />\nInstitution:<br />\n{$institutionName}<br />\n{$institutionMailingAddress}<br />\n<br />\nDomain (if provided):<br />\n{$domain}<br />\n<br />\nIP Ranges (if provided):<br />\n{$ipRanges}<br />\n<br />\nContact Person:<br />\n{$subscriberDetails}<br />\n<br />\nMembership Information (if provided):<br />\n{$membership}<br />\n<br />\nTo view or edit this subscription, please use the following URL.<br />\n<br />\nSubscription URL: {$subscriptionUrl}<br />\n'),(49,'REVISED_VERSION_NOTIFY','en','Revised Version Notification','Revised Version Uploaded','<p>Dear {$recipientName},</p><p>The author has uploaded revisions for the submission, <b>{$authorsShort} — {$submissionTitle}</b>. <p>As an assigned editor, we ask that you login and <a href=\"{$submissionUrl}\">view the revisions</a> and make a decision to accept, decline or send the submission for further review.</p><br><br>—<br>This is an automated message from <a href=\"{$contextUrl}\">{$contextName}</a>.'),(50,'STATISTICS_REPORT_NOTIFICATION','en','Statistics Report Notification','Editorial activity for {$month}, {$year}','\n{$recipientName}, <br />\n<br />\nYour journal health report for {$month}, {$year} is now available. Your key stats for this month are below.<br />\n<ul>\n	<li>New submissions this month: {$newSubmissions}</li>\n	<li>Declined submissions this month: {$declinedSubmissions}</li>\n	<li>Accepted submissions this month: {$acceptedSubmissions}</li>\n	<li>Total submissions in the system: {$totalSubmissions}</li>\n</ul>\nLogin to the journal to view more detailed <a href=\"{$editorialStatsLink}\">editorial trends</a> and <a href=\"{$publicationStatsLink}\">published article stats</a>. A full copy of this month\'s editorial trends is attached.<br />\n<br />\nSincerely,<br />\n{$contextSignature}'),(51,'ANNOUNCEMENT','en','New Announcement','{$announcementTitle}','<b>{$announcementTitle}</b><br />\n<br />\n{$announcementSummary}<br />\n<br />\nVisit our website to read the <a href=\"{$announcementUrl}\">full announcement</a>.'),(52,'DISCUSSION_NOTIFICATION_SUBMISSION','en','Discussion (Submission)','A message regarding {$contextName}','Please enter your message.'),(53,'DISCUSSION_NOTIFICATION_REVIEW','en','Discussion (Review)','A message regarding {$contextName}','Please enter your message.'),(54,'DISCUSSION_NOTIFICATION_COPYEDITING','en','Discussion (Copyediting)','A message regarding {$contextName}','Please enter your message.'),(55,'DISCUSSION_NOTIFICATION_PRODUCTION','en','Discussion (Production)','A message regarding {$contextName}','Please enter your message.'),(56,'COPYEDIT_REQUEST','en','Request Copyedit','Submission {$submissionId} is ready to be copyedited for {$contextAcronym}','<p>Dear {$recipientName},</p><p>A new submission is ready to be copyedited:</p><p><a href\"{$submissionUrl}\">{$submissionId} — \"{$submissionTitle}\"</a><br />{$contextName}</p><p>Please follow these steps to complete this task:</p><ol><li>Click on the Submission URL below.</li><li>Open any files available under Draft Files and edit the files. Use the Copyediting Discussions area if you need to contact the editor(s) or author(s).</li><li>Save the copyedited file(s) and upload them to the Copyedited panel.</li><li>Use the Copyediting Discussions to notify the editor(s) that all files have been prepared, and that the Production process may begin.</li></ol><p>If you are unable to undertake this work at this time or have any questions, please contact me. Thank you for your contribution to {$contextName}.</p><p>Kind regards,</p>{$signature}'),(57,'EDITOR_ASSIGN_SUBMISSION','en','Assign Editor','You have been assigned as an editor on a submission to {$contextName}','<p>Dear {$recipientName},</p><p>The following submission has been assigned to you to see through the editorial process.</p><p><a href=\"{$submissionUrl}\">{$submissionTitle}</a><br />{$authors}</p><p><b>Abstract</b></p>{$submissionAbstract}<p>If you find the submission to be relevant for {$contextName}, please forward the submission to the review stage by selecting \"Send to Review\" and then assign reviewers by clicking \"Add Reviewer\".</p><p>If the submission is not appropriate for this journal, please decline the submission.</p><p>Thank you in advance.</p><p>Kind regards,</p>{$contextSignature}'),(58,'EDITOR_ASSIGN_REVIEW','en','Assign Editor','You have been assigned as an editor on a submission to {$contextName}','<p>Dear {$recipientName},</p><p>The following submission has been assigned to you to see through the peer review process.</p><p><a href=\"{$submissionUrl}\">{$submissionTitle}</a><br />{$authors}</p><p><b>Abstract</b></p>{$submissionAbstract}<p>Please login to <a href=\"{$submissionUrl}\">view the submission</a> and assign qualified reviewers. You can assign a reviewer by clicking \"Add Reviewer\".</p><p>Thank you in advance.</p><p>Kind regards,</p>{$signature}'),(59,'EDITOR_ASSIGN_PRODUCTION','en','Assign Editor','You have been assigned as an editor on a submission to {$contextName}','<p>Dear {$recipientName},</p><p>The following submission has been assigned to you to see through the production stage.</p><p><a href=\"{$submissionUrl}\">{$submissionTitle}</a><br />{$authors}</p><p><b>Abstract</b></p>{$submissionAbstract}<p>Please login to <a href=\"{$submissionUrl}\">view the submission</a>. Once production-ready files are available, upload them under the <strong>Publication > Galleys</strong> section. Then schedule the work for publication by clicking the <strong>Schedule for Publication</strong> button.</p><p>Thank you in advance.</p><p>Kind regards,</p>{$signature}'),(60,'LAYOUT_REQUEST','en','Ready for Production','Submission {$submissionId} is ready for production at {$contextAcronym}','<p>Dear {$recipientName},</p><p>A new submission is ready for layout editing:</p><p><a href=\"{$submissionUrl}\">{$submissionId} — {$submissionTitle}</a><br />{$contextName}</p><ol><li>Click on the Submission URL above.</li><li>Download the Production Ready files and use them to create the galleys according to the journal\'s standards.</li><li>Upload the galleys to the Publication section of the submission.</li><li>Use the  Production Discussions to notify the editor that the galleys are ready.</li></ol><p>If you are unable to undertake this work at this time or have any questions, please contact me. Thank you for your contribution to this journal.</p><p>Kind regards,</p>{$signature}'),(61,'LAYOUT_COMPLETE','en','Galleys Complete','Galleys Complete','<p>Dear {$recipientName},</p><p>Galleys have now been prepared for the following submission and are ready for final review.</p><p><a href=\"{$submissionUrl}\">{$submissionTitle}</a><br />{$contextName}</p><p>If you have any questions, please contact me.</p><p>Kind regards,</p><p>{$signature}</p>'),(62,'VERSION_CREATED','en','Version Created','A new version was created for \"{$submissionTitle}\"','<p>Dear {$recipientName}, </p><p>This is an automated message to inform you that a new version of your submission, \"{$submissionTitle}\", was created. You can view this version from your submission dashboard at the following link:</p><p><a href=\"{$submissionUrl}\">\"{$submissionTitle}\"</a></p><hr><p>This is an automatic email sent from <a href=\"{$contextUrl}\">{$contextName}</a>.</p>'),(63,'EDITORIAL_REMINDER','en','Editorial Reminder','Outstanding editorial tasks for {$contextName}','<p>Dear {$recipientName},</p><p>You are currently assigned to {$numberOfSubmissions} submissions in <a href=\"{$contextUrl}\">{$contextName}</a>. The following submissions are <b>waiting for your response</b>.</p>{$outstandingTasks}<p>View all of your assignments in your <a href=\"{$submissionsUrl}\">submission dashboard</a>.</p><p>If you have any questions about your assignments, please contact {$contactName} at {$contactEmail}.</p>'),(64,'SUBMISSION_SAVED_FOR_LATER','en','Submission Saved for Later','Resume your submission to {$contextName}','<p>Dear {$recipientName},</p><p>Your submission details have been saved in our system, but it has not yet been submitted for consideration. You can return to complete your submission at any time by following the link below.</p><p><a href=\"{$submissionWizardUrl}\">{$authorsShort} — \"{$submissionTitle}\"</a></p><hr><p>This is an automated email from <a href=\"{$contextUrl}\">{$contextName}</a>.</p>'),(65,'SUBMISSION_NEEDS_EDITOR','en','Submission Needs Editor','A new submission needs an editor to be assigned: \"{$submissionTitle}\"','<p>Dear {$recipientName},</p><p>The following submission has been submitted and there is no editor assigned.</p><p><a href=\"{$submissionUrl}\">\"{$submissionTitle}\"</a><br />{$authors}</p><p><b>Abstract</b></p>{$submissionAbstract}<p>Please assign an editor who will be responsible for the submission by clicking the title above and assigning an editor under the Participants section.</p><hr><p>This is an automated email from <a href=\"{$contextUrl}\">{$contextName}</a>.</p>'),(66,'PAYMENT_REQUEST_NOTIFICATION','en','Payment Request','Payment Request Notification','<p>Dear {$recipientName},</p><p>Congratulations on the acceptance of your submission, {$submissionTitle}, to {$contextName}. Now that your submission has been accepted, we would like to request payment of the publication fee.</p><p>This fee covers the production costs of bringing your submission to publication. To make the payment, please visit <a href=\"{$queuedPaymentUrl}\">{$queuedPaymentUrl}</a>.</p><p>If you have any questions, please see our <a href=\"{$submissionGuidelinesUrl}\">Submission Guidelines</a></p>'),(67,'CHANGE_EMAIL','en','Change Email Address Invitation','Confirm account contact email change request','<p>Dear {$recipientName},</p><p>You are receiving this email because someone has requested a change of your email to {$newEmail}.</p><p>If you have made this request please <a href=\"{$acceptInvitationUrl}\">confirm</a> the email change.</p><p>You can always <a href=\"{$declineInvitationUrl}\">reject</a> this email change.</p><p>Please feel free to contact me with any questions about the submission or the review process.</p><p>Kind regards,</p>{$siteContactName}'),(68,'ORCID_COLLECT_AUTHOR_ID','en','orcidCollectAuthorId','Submission ORCID','Dear {$recipientName},<br/>\n<br/>\nYou have been listed as an author on a manuscript submission to {$contextName}.<br/>\nTo confirm your authorship, please add your ORCID id to this submission by visiting the link provided below.<br/>\n<br/>\n<a href=\"{$authorOrcidUrl}\"><img id=\"orcid-id-logo\" src=\"https://info.orcid.org/wp-content/uploads/2020/12/ORCIDiD_icon16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Register or connect your ORCID iD</a><br/>\n<br/>\n<br>\n<a href=\"{$orcidAboutUrl}\">More information about ORCID at {$contextName}</a><br/>\n<br/>\nIf you have any questions, please contact me.<br/>\n<br/>\n{$principalContactSignature}<br/>\n'),(69,'ORCID_REQUEST_AUTHOR_AUTHORIZATION','en','orcidRequestAuthorAuthorization','Requesting ORCID record access','Dear {$recipientName},<br>\n<br>\nYou have been listed as an author on the manuscript submission \"{$submissionTitle}\" to {$contextName}.\n<br>\n<br>\nPlease allow us to add your ORCID id to this submission and also to add the submission to your ORCID profile on publication.<br>\nVisit the link to the official ORCID website, login with your profile and authorize the access by following the instructions.<br>\n<br>\n<a href=\"{$authorOrcidUrl}\" style=\"display: inline-flex; align-items: center; background-color: white; text-align: center; padding: 10px 20px; text-decoration: none; border-radius: 5px; border: 2px solid #d7d4d4;\"><img id=\"orcid-id-logo\" src=\"https://info.orcid.org/wp-content/uploads/2020/12/ORCIDiD_icon16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Register or Connect your ORCID iD</a><br/>\n<br>\n<br>\nClick here to verify your account with ORCID: <a href=\"{$authorOrcidUrl}\">{$authorOrcidUrl}.</a>\n<br>\n<br>\n<a href=\"{$orcidAboutUrl}\">More about ORCID at {$contextName}</a><br/>\n<br>\n<br>\nIf you have any questions, please contact me.<br>\n<br>\n{$principalContactSignature}<br>\n'),(70,'USER_ROLE_ASSIGNMENT_INVITATION','en','User Invited to Role Notification','You are invited to new roles','<div class=\'email-container\'>    <div class=\'email-header\'>        <h2>Invitation to New Role</h2>    </div>    <div class=\'email-content\'>        <p>Dear {$recipientName},</p>        <p>In light of your expertise, you have been invited by {$inviterName} to take on new roles at {$contextName}</p>        <p>At {$contextName}, we value your privacy. As such, we have taken steps to ensure that we are fully GDPR compliant. These steps include you being accountable to enter your own data and choosing who can see what information. For additional information on how we handled your data, please refer to our Privacy Policy.</p>        <div>{$existingRoles}</div>        <div>{$rolesAdded}</div>        <p>On accepting the invite, you will be redirected to {$contextName}.</p>        <p>Feel free to contact me with any questions about the process.</p>        <p><a href=\'{$acceptUrl}\' class=\'btn btn-accept\'>Accept Invitation</a></p>        <p><a href=\'{$declineUrl}\' class=\'btn btn-decline\'>Decline Invitation</a></p>        <p>Kind regards,</p>        <p>{$contextName}</p>    </div></div><style>{$emailTemplateStyle}</style>'),(71,'USER_ROLE_END','en','User Role Ended Notification','You have been removed from a role','<div class=\'email-container\'>    <div class=\'email-header\'>        <h2>Removed from a Role</h2>    </div>    <div class=\'email-content\'>        <p>Dear {$recipientName},</p>        <p>Thank you very much for your participation in the role of {$roleRemoved} at {$contextName}.</p>        <p>This is a notice to let you know that you have been removed from the following role at {$contextName}: <b>{$roleRemoved}</b>.</p>        <p>Your account with {$contextName} is still active and any other roles you previously held are still active.</p>        <p>Feel free to contact me with any questions about the process.</p>        <p>Kind regards,</p>        <p>{$contextName}</p>    </div></div><style>{$emailTemplateStyle}</style>'),(72,'ORCID_REQUEST_UPDATE_SCOPE','en','orcidRequestUpdateScope','Requesting updated ORCID record access','Dear {$recipientName},<br>\n<br>\nYou are listed as a contributor (author or reviewer) on the manuscript submission \"{$submissionTitle}\" to {$contextName}.\n<br>\n<br>\nYou have previously authorized {$contextName} to list your ORCID id on the site, and we require updateded permissions to add your contribution to your ORCID profile.<br>\nVisit the link to the official ORCID website, login with your profile and authorize the access by following the instructions.<br>\n<br>\n<a href=\"{$authorOrcidUrl}\" style=\"display: inline-flex; align-items: center; background-color: white; text-align: center; padding: 10px 20px; text-decoration: none; border-radius: 5px; border: 2px solid #d7d4d4;\"><img id=\"orcid-id-logo\" src=\"https://info.orcid.org/wp-content/uploads/2020/12/ORCIDiD_icon16x16.png\" width=\'16\' height=\'16\' alt=\"ORCID iD icon\" style=\"display: block; margin: 0 .5em 0 0; padding: 0; float: left;\"/>Register or Connect your ORCID iD</a><br/>\n<br>\n<br>\nClick here to update your account with ORCID: <a href=\"{$authorOrcidUrl}\">{$authorOrcidUrl}.</a>\n<br>\n<br>\n<a href=\"{$orcidAboutUrl}\">More about ORCID at {$contextName}</a><br/>\n<br>\n<br>\nIf you have any questions, please contact me.<br>\n<br>\n{$principalContactSignature}<br>\n'),(73,'MANUAL_PAYMENT_NOTIFICATION','en','Manual Payment Notify','Manual Payment Notification','A manual payment needs to be processed for the journal {$contextName} and the user &quot;{$senderUsername}&quot;.<br />\n<br />\nThe item being paid for is &quot;{$paymentName}&quot;.<br />\nThe cost is {$paymentAmount} ({$paymentCurrencyCode}).<br />\n<br />\nThis email was generated by Open Journal Systems\' Manual Payment plugin.'),(74,'USER_ROLE_MASTHEAD_UPDATE','en','User Role Masthead Visibility Update Notification','Your journal masthead visibility has been updated','<div class=\'email-container\'>    <div class=\'email-header\'>        <h2>Updated role masthead visibility</h2>    </div>    <div class=\'email-content\'>        <p>Dear {$recipientName},</p>        <p>Your journal masthead visibility for the role {$roleNameAndDates} in {$contextName} has been updated.</p>        <p>New setting: {$appearOnMasthead}</p>        <p>If you have questions about this change, please contact the journal manager.</p>        <p>Kind regards,</p>        <p>{$contextName}</p>    </div></div>'),(75,'EDITOR_DECISION_MARK_PUBLISHED','en','Article Published Notification (Post45)','[Post45] \"{$submissionTitle}\" is now live','Dear {$recipientName},<br /><br />We\'re delighted to share that &quot;{$submissionTitle}&quot; has been published in <em>Post45 Journal</em>. You can read it here:<br /><br />{$publicationUrl}<br /><br />Thank you so much for trusting <em>Post45</em> with this work. It\'s been a real pleasure working with you, and we hope to do so again.<br /><br />Best wishes,<br /><br />{$signature}');
/*!40000 ALTER TABLE `email_templates_default_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates_settings`
--

DROP TABLE IF EXISTS `email_templates_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates_settings` (
  `email_template_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`email_template_setting_id`),
  UNIQUE KEY `email_templates_settings_unique` (`email_id`,`locale`,`setting_name`),
  KEY `email_templates_settings_email_id` (`email_id`),
  CONSTRAINT `email_templates_settings_email_id` FOREIGN KEY (`email_id`) REFERENCES `email_templates` (`email_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3 COMMENT='More data about custom email templates, including localized properties such as the subject and body.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates_settings`
--

LOCK TABLES `email_templates_settings` WRITE;
/*!40000 ALTER TABLE `email_templates_settings` DISABLE KEYS */;
INSERT INTO `email_templates_settings` VALUES (1,7,'en','body','<p>Dear {$recipientName},</p>\n<p>A new message regarding <a href=\"{$submissionUrl}\">{$submissionTitle}</a> is available for you to review.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>\n<p> </p>\n<p> </p>'),(2,7,'en','name','Discussion (Review)'),(3,7,'en','subject','A message regarding {$contextName}'),(4,8,'en','body','<p>Dear {$recipientName},</p>\n<p>A new message regarding <a href=\"{$submissionUrl}\">{$submissionTitle}</a> is available for you to review.</p>\n<p>Kind regards,</p>\n<p>{$signature}</p>'),(5,8,'en','name','Discussion (Submission)'),(6,8,'en','subject','A message regarding {$contextName}'),(7,9,'en','body','<p>Dear {$recipientName},</p><p>The following submission has been assigned to you to see through the editorial process.</p><p><a href=\"{$submissionUrl}\">{$submissionTitle}</a><br />{$authors}</p><p><b>Abstract</b></p>{$submissionAbstract}<p>If you find the submission to be relevant for {$contextName}, please forward the submission to the review stage by selecting \"Send to Review\" and then assign reviewers by clicking \"Add Reviewer\".</p><p>If the submission is not appropriate for this journal, please decline the submission.</p><p>Thank you in advance.</p><p>Kind regards,</p>{$contextSignature}'),(8,9,'en','name','Editor Assigned'),(9,9,'en','subject','You have been assigned as an editor on a submission to {$contextName}'),(10,10,'en','body','<p>Dear {$recipientName},</p><p>You are currently assigned to {$numberOfSubmissions} submissions in <a href=\"{$contextUrl}\">{$contextName}</a>. The following submissions are <b>waiting for your response</b>.</p>{$outstandingTasks}<p>View all of your assignments in your <a href=\"{$submissionsUrl}\">submission dashboard</a>.</p><p>If you have any questions about your assignments, please contact {$contactName} at {$contactEmail}.</p>'),(11,10,'en','name','Editorial Reminder'),(12,10,'en','subject','Outstanding editorial tasks for {$contextName}'),(13,11,'en','body','<p class=\"MsoNormal\">Dear {$recipientName}</p>\n<p class=\"MsoNormal\"><br>On behalf of the editors and reviewers of {$contextName} I regret to inform you that the editors have decided against publishing your essay \"{$submissionTitle}\".<br><br>While the editors find your essay insightful, they are not convinced that its focus is suitable for our<span class=\"apple-converted-space\"> </span><span class=\"il\">journal</span>.<br><br>We want to thank you for giving<span class=\"apple-converted-space\"> </span>{$contextName} an opportunity to review your work, and we wish you every success in publishing your essay in another<span class=\"apple-converted-space\"> </span><span class=\"il\">journal</span>. <br><br></p>\n<p class=\"MsoNormal\">Sincerely,</p>\n<p class=\"MsoNormal\">{$contextSignature}</p>'),(14,11,'en','name','Editor Decision Template'),(15,11,'en','subject','Editor Decision on Post45 Submission'),(16,12,'en','body','<p class=\"MsoNormal\">Dear {$recipientName}<br><br></p>\n<p class=\"MsoNormal\">On behalf of the editors and reviewers of {$contextName} I regret to inform you that the editors have decided against publishing your essay \"{$submissionTitle}\".<br><br>While the editors and reviewers found your essay insightful, they are not convinced that its focus is suitable for our<span class=\"apple-converted-space\"> </span><span class=\"il\">journal</span>.<br><br>We want to thank you for giving<span class=\"apple-converted-space\"> </span>{$contextName} an opportunity to review your work, and we wish you every success in publishing your essay in another<span class=\"apple-converted-space\"> </span><span class=\"il\">journal</span>. <br> <br>For your interest, reviewers\' comments are provided below. We hope you find them constructive and helpful. <br> <br>Sincerely,</p>\n<p class=\"MsoNormal\">{$contextSignature}</p>\n<p class=\"MsoNormal\"> </p>\n<hr>\n<p>The following comments were received from reviewers.</p>\n<p>{$allReviewerComments}</p>'),(17,12,'en','name','Decision Template'),(18,12,'en','subject','Decision on Post45 Submission'),(19,13,'en','body','<p>Dear {$recipientName},</p>\n<p>Thank you for your submission to {$contextName}. We have received your submission, \"{$submissionTitle}\", and a member of our editorial team will see it soon. You will be sent an email when an initial decision is made, and we may contact you for further information.</p>\n<p>You can view your submission and track its progress through the editorial process at the following location:</p>\n<p>Submission URL: {$authorSubmissionUrl}</p>\n<p>If you have been logged out, you can login again with the username {$recipientUsername}.</p>\n<p>If you have any questions, please contact me from your <a href=\"{$authorSubmissionUrl}\">submission dashboard</a>.</p>\n<p>Thank you for considering {$contextName} as a venue for your work.</p>\n<p> </p>\n<p>{$authorCommentsForEditors}</p>\n<p> </p>\n<p>{$contextSignature}</p>\n<p> </p>\n<p> </p>'),(20,13,'en','name','Submission Confirmation'),(21,13,'en','subject','Thank you for your submission to {$contextName}');
/*!40000 ALTER TABLE `email_templates_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_log`
--

DROP TABLE IF EXISTS `event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_log` (
  `log_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL COMMENT 'NULL if it''s system or automated event',
  `date_logged` datetime NOT NULL,
  `event_type` bigint DEFAULT NULL,
  `message` text,
  `is_translated` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `event_log_user_id` (`user_id`),
  KEY `event_log_assoc` (`assoc_type`,`assoc_id`),
  CONSTRAINT `event_log_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='A log of all events related to an object like a submission.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_log`
--

LOCK TABLES `event_log` WRITE;
/*!40000 ALTER TABLE `event_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_log_settings`
--

DROP TABLE IF EXISTS `event_log_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_log_settings` (
  `event_log_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `log_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`event_log_setting_id`),
  UNIQUE KEY `event_log_settings_unique` (`log_id`,`setting_name`,`locale`),
  KEY `event_log_settings_log_id` (`log_id`),
  KEY `event_log_settings_name_value` (`setting_name`(50),`setting_value`(150)),
  CONSTRAINT `event_log_settings_log_id` FOREIGN KEY (`log_id`) REFERENCES `event_log` (`log_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Data about an event log entry. This data is commonly used to display information about an event to a user.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_log_settings`
--

LOCK TABLES `event_log_settings` WRITE;
/*!40000 ALTER TABLE `event_log_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_log_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='A log of all failed jobs.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `file_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(255) NOT NULL,
  `mimetype` varchar(255) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3 COMMENT='Records information in the database about files tracked by the system, linking them to the local filesystem.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES (2,'journals/1/articles/3/6920a5e9e9537.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(3,'journals/1/articles/3/6920a6041a0fd.pdf','application/pdf'),(4,'journals/1/articles/4/69459f801de1b.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(5,'journals/1/articles/5/6945a06e27268.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(7,'journals/1/articles/7/694643f9ac0df.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(8,'journals/1/articles/8/694644ba324f6.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(9,'journals/1/articles/9/6a4ecb3579d67.pdf','application/pdf'),(10,'journals/1/articles/17/6a57b8fe63fc6.pdf','application/pdf'),(11,'journals/1/articles/16/6a5d0dabcf312.pdf','application/pdf'),(12,'journals/1/articles/18/6a627282a7a7a.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(13,'journals/1/articles/25/6a62a34c1eeb3.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(14,'journals/1/articles/20/6a62a529e8dd1.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(15,'journals/1/articles/26/6a62a62995cf1.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(16,'journals/1/articles/27/6a62aa249b2fa.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(17,'journals/1/articles/28/6a62ab8228180.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(18,'journals/1/articles/30/6a63b947c3dac.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(19,'journals/1/articles/31/6a63c02770495.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(20,'journals/1/articles/32/6a63c167e17de.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(21,'journals/1/articles/33/6a63c509ab601.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document'),(22,'journals/1/articles/33/6a64f7d13411f.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document');
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter_groups`
--

DROP TABLE IF EXISTS `filter_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filter_groups` (
  `filter_group_id` bigint NOT NULL AUTO_INCREMENT,
  `symbolic` varchar(255) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `input_type` varchar(255) DEFAULT NULL,
  `output_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`filter_group_id`),
  UNIQUE KEY `filter_groups_symbolic` (`symbolic`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb3 COMMENT='Filter groups are used to organized filters into named sets, which can be retrieved by the application for invocation.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter_groups`
--

LOCK TABLES `filter_groups` WRITE;
/*!40000 ALTER TABLE `filter_groups` DISABLE KEYS */;
INSERT INTO `filter_groups` VALUES (1,'issue=>crossref-xml','plugins.importexport.crossref.displayName','plugins.importexport.crossref.description','class::classes.issue.Issue[]','xml::schema(https://www.crossref.org/schemas/crossref5.4.0.xsd)'),(2,'article=>crossref-xml','plugins.importexport.crossref.displayName','plugins.importexport.crossref.description','class::classes.submission.Submission[]','xml::schema(https://www.crossref.org/schemas/crossref5.4.0.xsd)'),(3,'issue=>datacite-xml','plugins.importexport.datacite.displayName','plugins.importexport.datacite.description','class::classes.issue.Issue','xml::schema(http://schema.datacite.org/meta/kernel-4/metadata.xsd)'),(4,'article=>datacite-xml','plugins.importexport.datacite.displayName','plugins.importexport.datacite.description','class::classes.submission.Submission','xml::schema(http://schema.datacite.org/meta/kernel-4/metadata.xsd)'),(5,'galley=>datacite-xml','plugins.importexport.datacite.displayName','plugins.importexport.datacite.description','class::lib.pkp.classes.galley.Galley','xml::schema(http://schema.datacite.org/meta/kernel-4/metadata.xsd)'),(6,'article=>dc11','plugins.metadata.dc11.articleAdapter.displayName','plugins.metadata.dc11.articleAdapter.description','class::classes.submission.Submission','metadata::APP\\plugins\\metadata\\dc11\\schema\\Dc11Schema(ARTICLE)'),(7,'user=>user-xml','plugins.importexport.users.displayName','plugins.importexport.users.description','class::PKP\\user\\User[]','xml::schema(lib/pkp/plugins/importexport/users/pkp-users.xsd)'),(8,'user-xml=>user','plugins.importexport.users.displayName','plugins.importexport.users.description','xml::schema(lib/pkp/plugins/importexport/users/pkp-users.xsd)','class::PKP\\user\\User[]'),(9,'usergroup=>user-xml','plugins.importexport.users.displayName','plugins.importexport.users.description','class::PKP\\userGroup\\UserGroup[]','xml::schema(lib/pkp/plugins/importexport/users/pkp-users.xsd)'),(10,'user-xml=>usergroup','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(lib/pkp/plugins/importexport/users/pkp-users.xsd)','class::PKP\\userGroup\\UserGroup[]'),(11,'article=>pubmed-xml','plugins.importexport.pubmed.displayName','plugins.importexport.pubmed.description','class::classes.submission.Submission[]','xml::dtd'),(12,'article=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::classes.submission.Submission[]','xml::schema(plugins/importexport/native/native.xsd)'),(13,'native-xml=>article','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::classes.submission.Submission[]'),(14,'issue=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::classes.issue.Issue[]','xml::schema(plugins/importexport/native/native.xsd)'),(15,'native-xml=>issue','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::classes.issue.Issue[]'),(16,'issuegalley=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::classes.issue.IssueGalley[]','xml::schema(plugins/importexport/native/native.xsd)'),(17,'native-xml=>issuegalley','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::classes.issue.IssueGalley[]'),(18,'author=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::classes.author.Author[]','xml::schema(plugins/importexport/native/native.xsd)'),(19,'native-xml=>author','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::classes.author.Author[]'),(20,'SubmissionFile=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::lib.pkp.classes.submissionFile.SubmissionFile','xml::schema(plugins/importexport/native/native.xsd)'),(21,'native-xml=>SubmissionFile','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::lib.pkp.classes.submissionFile.SubmissionFile[]'),(22,'article-galley=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::lib.pkp.classes.galley.Galley','xml::schema(plugins/importexport/native/native.xsd)'),(23,'native-xml=>ArticleGalley','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::lib.pkp.classes.galley.Galley[]'),(24,'publication=>native-xml','plugins.importexport.native.displayName','plugins.importexport.native.description','class::classes.publication.Publication','xml::schema(plugins/importexport/native/native.xsd)'),(25,'native-xml=>Publication','plugins.importexport.native.displayName','plugins.importexport.native.description','xml::schema(plugins/importexport/native/native.xsd)','class::classes.publication.Publication[]'),(26,'article=>doaj-xml','plugins.importexport.doaj.displayName','plugins.importexport.doaj.description','class::classes.submission.Submission[]','xml::schema(plugins/importexport/doaj/doajArticles.xsd)'),(27,'article=>doaj-json','plugins.importexport.doaj.displayName','plugins.importexport.doaj.description','class::classes.submission.Submission','primitive::string'),(28,'test-filter-group','some.test.filter.group.display','some.test.filter.group.description','primitive::string','primitive::string');
/*!40000 ALTER TABLE `filter_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filter_settings`
--

DROP TABLE IF EXISTS `filter_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filter_settings` (
  `filter_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `filter_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`filter_setting_id`),
  UNIQUE KEY `filter_settings_unique` (`filter_id`,`locale`,`setting_name`),
  KEY `filter_settings_id` (`filter_id`),
  CONSTRAINT `filter_settings_filter_id_foreign` FOREIGN KEY (`filter_id`) REFERENCES `filters` (`filter_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COMMENT='More data about filters, including localized content.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filter_settings`
--

LOCK TABLES `filter_settings` WRITE;
/*!40000 ALTER TABLE `filter_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `filter_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filters`
--

DROP TABLE IF EXISTS `filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filters` (
  `filter_id` bigint NOT NULL AUTO_INCREMENT,
  `filter_group_id` bigint NOT NULL,
  `context_id` bigint DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `class_name` varchar(255) DEFAULT NULL,
  `is_template` smallint NOT NULL DEFAULT '0',
  `parent_filter_id` bigint DEFAULT NULL,
  `seq` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`filter_id`),
  KEY `filters_filter_group_id` (`filter_group_id`),
  KEY `filters_context_id` (`context_id`),
  KEY `filters_parent_filter_id` (`parent_filter_id`),
  CONSTRAINT `filters_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `filters_filter_group_id_foreign` FOREIGN KEY (`filter_group_id`) REFERENCES `filter_groups` (`filter_group_id`) ON DELETE CASCADE,
  CONSTRAINT `filters_parent_filter_id_foreign` FOREIGN KEY (`parent_filter_id`) REFERENCES `filters` (`filter_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb3 COMMENT='Filters represent a transformation of a supported piece of data from one form to another, such as a PHP object into an XML document.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filters`
--

LOCK TABLES `filters` WRITE;
/*!40000 ALTER TABLE `filters` DISABLE KEYS */;
INSERT INTO `filters` VALUES (1,1,NULL,'Crossref XML issue export','APP\\plugins\\generic\\crossref\\filter\\IssueCrossrefXmlFilter',0,NULL,0),(2,2,NULL,'Crossref XML article export','APP\\plugins\\generic\\crossref\\filter\\ArticleCrossrefXmlFilter',0,NULL,0),(3,3,NULL,'DataCite XML export','APP\\plugins\\generic\\datacite\\filter\\DataciteXmlFilter',0,NULL,0),(4,4,NULL,'DataCite XML export','APP\\plugins\\generic\\datacite\\filter\\DataciteXmlFilter',0,NULL,0),(5,5,NULL,'DataCite XML export','APP\\plugins\\generic\\datacite\\filter\\DataciteXmlFilter',0,NULL,0),(6,6,NULL,'Extract metadata from a(n) Submission','APP\\plugins\\metadata\\dc11\\filter\\Dc11SchemaArticleAdapter',0,NULL,0),(7,7,NULL,'User XML user export','PKP\\plugins\\importexport\\users\\filter\\PKPUserUserXmlFilter',0,NULL,0),(8,8,NULL,'User XML user import','PKP\\plugins\\importexport\\users\\filter\\UserXmlPKPUserFilter',0,NULL,0),(9,9,NULL,'Native XML user group export','PKP\\plugins\\importexport\\users\\filter\\UserGroupNativeXmlFilter',0,NULL,0),(10,10,NULL,'Native XML user group import','PKP\\plugins\\importexport\\users\\filter\\NativeXmlUserGroupFilter',0,NULL,0),(11,11,NULL,'APP\\plugins\\importexport\\pubmed\\filter\\ArticlePubMedXmlFilter','APP\\plugins\\importexport\\pubmed\\filter\\ArticlePubMedXmlFilter',0,NULL,0),(12,12,NULL,'Native XML submission export','APP\\plugins\\importexport\\native\\filter\\ArticleNativeXmlFilter',0,NULL,0),(13,13,NULL,'Native XML submission import','APP\\plugins\\importexport\\native\\filter\\NativeXmlArticleFilter',0,NULL,0),(14,14,NULL,'Native XML issue export','APP\\plugins\\importexport\\native\\filter\\IssueNativeXmlFilter',0,NULL,0),(15,15,NULL,'Native XML issue import','APP\\plugins\\importexport\\native\\filter\\NativeXmlIssueFilter',0,NULL,0),(16,16,NULL,'Native XML issue galley export','APP\\plugins\\importexport\\native\\filter\\IssueGalleyNativeXmlFilter',0,NULL,0),(17,17,NULL,'Native XML issue galley import','APP\\plugins\\importexport\\native\\filter\\NativeXmlIssueGalleyFilter',0,NULL,0),(18,18,NULL,'Native XML author export','APP\\plugins\\importexport\\native\\filter\\AuthorNativeXmlFilter',0,NULL,0),(19,19,NULL,'Native XML author import','APP\\plugins\\importexport\\native\\filter\\NativeXmlAuthorFilter',0,NULL,0),(20,21,NULL,'Native XML submission file import','APP\\plugins\\importexport\\native\\filter\\NativeXmlArticleFileFilter',0,NULL,0),(21,20,NULL,'Native XML submission file export','PKP\\plugins\\importexport\\native\\filter\\SubmissionFileNativeXmlFilter',0,NULL,0),(22,22,NULL,'Native XML representation export','APP\\plugins\\importexport\\native\\filter\\ArticleGalleyNativeXmlFilter',0,NULL,0),(23,23,NULL,'Native XML representation import','APP\\plugins\\importexport\\native\\filter\\NativeXmlArticleGalleyFilter',0,NULL,0),(24,24,NULL,'Native XML Publication export','APP\\plugins\\importexport\\native\\filter\\PublicationNativeXmlFilter',0,NULL,0),(25,25,NULL,'Native XML publication import','APP\\plugins\\importexport\\native\\filter\\NativeXmlPublicationFilter',0,NULL,0),(26,26,NULL,'DOAJ XML export','APP\\plugins\\importexport\\doaj\\filter\\DOAJXmlFilter',0,NULL,0),(27,27,NULL,'DOAJ JSON export','APP\\plugins\\importexport\\doaj\\filter\\DOAJJsonFilter',0,NULL,0);
/*!40000 ALTER TABLE `filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genre_settings`
--

DROP TABLE IF EXISTS `genre_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `genre_settings` (
  `genre_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `genre_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`genre_setting_id`),
  UNIQUE KEY `genre_settings_unique` (`genre_id`,`locale`,`setting_name`),
  KEY `genre_settings_genre_id` (`genre_id`),
  CONSTRAINT `genre_settings_genre_id_foreign` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`genre_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COMMENT='More data about file genres, including localized properties such as the genre name.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genre_settings`
--

LOCK TABLES `genre_settings` WRITE;
/*!40000 ALTER TABLE `genre_settings` DISABLE KEYS */;
INSERT INTO `genre_settings` VALUES (1,1,'en','name','Article Text','string'),(2,2,'en','name','Research Instrument','string'),(3,3,'en','name','Research Materials','string'),(4,4,'en','name','Research Results','string'),(5,5,'en','name','Transcripts','string'),(6,6,'en','name','Data Analysis','string'),(7,7,'en','name','Data Set','string'),(8,8,'en','name','Source Texts','string'),(9,9,'en','name','Multimedia','string'),(10,10,'en','name','Image','string'),(11,11,'en','name','HTML Stylesheet','string'),(12,12,'en','name','Other','string'),(13,13,'en','name','Abstract','string');
/*!40000 ALTER TABLE `genre_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genres`
--

DROP TABLE IF EXISTS `genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `genres` (
  `genre_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `seq` bigint NOT NULL,
  `enabled` smallint NOT NULL DEFAULT '1',
  `category` bigint NOT NULL DEFAULT '1',
  `dependent` smallint NOT NULL DEFAULT '0',
  `supplementary` smallint NOT NULL DEFAULT '0',
  `required` smallint NOT NULL DEFAULT '0' COMMENT 'Whether or not at least one file of this genre is required for a new submission.',
  `entry_key` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`genre_id`),
  KEY `genres_context_id` (`context_id`),
  CONSTRAINT `genres_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COMMENT='The types of submission files configured for each context, such as Article Text, Data Set, Transcript, etc.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genres`
--

LOCK TABLES `genres` WRITE;
/*!40000 ALTER TABLE `genres` DISABLE KEYS */;
INSERT INTO `genres` VALUES (1,1,0,1,1,0,0,1,'SUBMISSION'),(2,1,1,0,3,0,1,0,'RESEARCHINSTRUMENT'),(3,1,2,0,3,0,1,0,'RESEARCHMATERIALS'),(4,1,3,0,3,0,1,0,'RESEARCHRESULTS'),(5,1,4,0,3,0,1,0,'TRANSCRIPTS'),(6,1,5,0,3,0,1,0,'DATAANALYSIS'),(7,1,6,0,3,0,1,0,'DATASET'),(8,1,7,0,3,0,1,0,'SOURCETEXTS'),(9,1,8,1,1,1,1,0,'MULTIMEDIA'),(10,1,9,1,2,1,0,0,'IMAGE'),(11,1,10,0,1,1,0,0,'STYLE'),(12,1,11,1,3,0,1,0,'OTHER'),(13,1,0,1,1,0,0,0,'abstract');
/*!40000 ALTER TABLE `genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `highlight_settings`
--

DROP TABLE IF EXISTS `highlight_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `highlight_settings` (
  `highlight_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `highlight_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`highlight_setting_id`),
  UNIQUE KEY `highlight_settings_unique` (`highlight_id`,`locale`,`setting_name`),
  KEY `highlight_settings_highlight_id` (`highlight_id`),
  CONSTRAINT `highlight_settings_highlight_id_foreign` FOREIGN KEY (`highlight_id`) REFERENCES `highlights` (`highlight_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about highlights, including localized properties like title and description.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `highlight_settings`
--

LOCK TABLES `highlight_settings` WRITE;
/*!40000 ALTER TABLE `highlight_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `highlight_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `highlights`
--

DROP TABLE IF EXISTS `highlights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `highlights` (
  `highlight_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint DEFAULT NULL,
  `sequence` bigint NOT NULL,
  `url` varchar(2047) NOT NULL,
  PRIMARY KEY (`highlight_id`),
  KEY `highlights_context_id` (`context_id`),
  CONSTRAINT `highlights_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Highlights are featured items that can be presented to users, for example on the homepage.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `highlights`
--

LOCK TABLES `highlights` WRITE;
/*!40000 ALTER TABLE `highlights` DISABLE KEYS */;
/*!40000 ALTER TABLE `highlights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `institution_ip`
--

DROP TABLE IF EXISTS `institution_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `institution_ip` (
  `institution_ip_id` bigint NOT NULL AUTO_INCREMENT,
  `institution_id` bigint NOT NULL,
  `ip_string` varchar(40) NOT NULL,
  `ip_start` bigint NOT NULL,
  `ip_end` bigint DEFAULT NULL,
  PRIMARY KEY (`institution_ip_id`),
  KEY `institution_ip_institution_id` (`institution_id`),
  KEY `institution_ip_start` (`ip_start`),
  KEY `institution_ip_end` (`ip_end`),
  CONSTRAINT `institution_ip_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`institution_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Records IP address ranges and associates them with institutions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institution_ip`
--

LOCK TABLES `institution_ip` WRITE;
/*!40000 ALTER TABLE `institution_ip` DISABLE KEYS */;
/*!40000 ALTER TABLE `institution_ip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `institution_settings`
--

DROP TABLE IF EXISTS `institution_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `institution_settings` (
  `institution_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `institution_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`institution_setting_id`),
  UNIQUE KEY `institution_settings_unique` (`institution_id`,`locale`,`setting_name`),
  KEY `institution_settings_institution_id` (`institution_id`),
  CONSTRAINT `institution_settings_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`institution_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about institutions, including localized properties like names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institution_settings`
--

LOCK TABLES `institution_settings` WRITE;
/*!40000 ALTER TABLE `institution_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `institution_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `institutional_subscriptions`
--

DROP TABLE IF EXISTS `institutional_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `institutional_subscriptions` (
  `institutional_subscription_id` bigint NOT NULL AUTO_INCREMENT,
  `subscription_id` bigint NOT NULL,
  `institution_id` bigint NOT NULL,
  `mailing_address` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`institutional_subscription_id`),
  KEY `institutional_subscriptions_subscription_id` (`subscription_id`),
  KEY `institutional_subscriptions_institution_id` (`institution_id`),
  KEY `institutional_subscriptions_domain` (`domain`),
  CONSTRAINT `institutional_subscriptions_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`institution_id`) ON DELETE CASCADE,
  CONSTRAINT `institutional_subscriptions_subscription_id` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`subscription_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='A list of institutional subscriptions, linking a subscription with an institution.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institutional_subscriptions`
--

LOCK TABLES `institutional_subscriptions` WRITE;
/*!40000 ALTER TABLE `institutional_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `institutional_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `institutions`
--

DROP TABLE IF EXISTS `institutions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `institutions` (
  `institution_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `ror` varchar(255) DEFAULT NULL COMMENT 'ROR (Research Organization Registry) ID',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`institution_id`),
  KEY `institutions_context_id` (`context_id`),
  CONSTRAINT `institutions_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Institutions for statistics and subscriptions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `institutions`
--

LOCK TABLES `institutions` WRITE;
/*!40000 ALTER TABLE `institutions` DISABLE KEYS */;
/*!40000 ALTER TABLE `institutions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invitations`
--

DROP TABLE IF EXISTS `invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invitations` (
  `invitation_id` bigint NOT NULL AUTO_INCREMENT,
  `key_hash` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `inviter_id` bigint DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `payload` json DEFAULT NULL,
  `status` enum('INITIALIZED','PENDING','ACCEPTED','DECLINED','CANCELLED') NOT NULL,
  `email` varchar(255) DEFAULT NULL COMMENT 'When present, the email address of the invitation recipient; when null, user_id must be set and the email can be fetched from the users table.',
  `context_id` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`invitation_id`),
  KEY `invitations_user_id` (`user_id`),
  KEY `invitations_inviter_id` (`inviter_id`),
  KEY `invitations_context_id` (`context_id`),
  KEY `invitations_status_context_id_user_id_type_index` (`status`,`context_id`,`user_id`,`type`),
  KEY `invitations_expiry_date_index` (`expiry_date`),
  CONSTRAINT `invitations_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `invitations_inviter_id_foreign` FOREIGN KEY (`inviter_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `invitations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb3 COMMENT='Invitations are sent to request a person (by email) to allow them to accept or reject an operation or position, such as a board membership or a submission peer review.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invitations`
--

LOCK TABLES `invitations` WRITE;
/*!40000 ALTER TABLE `invitations` DISABLE KEYS */;
INSERT INTO `invitations` VALUES (38,'$2y$10$iAJ/FalUnCTSCsynTO9AWuPgWJT/AxCMvTHqz4EvxiPCXGgnjRbt2','reviewerAccess',23,1,'2026-10-16 17:54:51','{\"reviewAssignmentId\": 8}','PENDING',NULL,1,'2026-07-24 17:54:51','2026-07-24 17:54:51'),(39,'$2y$10$wAr/rNp7NWN1p1V2lUFKRuWo8gTgBZZuknZRUxKP/ICzOJslDOtpC','reviewerAccess',3,1,'2026-10-16 19:45:07','{\"reviewAssignmentId\": 9}','PENDING',NULL,1,'2026-07-24 19:45:07','2026-07-24 19:45:07'),(41,'$2y$10$BP992.mcJrPqDOne8wdzluJ60brbHJlWlljWWI.5qIqNJCqWRiwse','reviewerAccess',17,1,'2026-10-16 20:17:42','{\"reviewAssignmentId\": 11}','PENDING',NULL,1,'2026-07-24 20:17:42','2026-07-24 20:17:42');
/*!40000 ALTER TABLE `invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_files`
--

DROP TABLE IF EXISTS `issue_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue_files` (
  `file_id` bigint NOT NULL AUTO_INCREMENT,
  `issue_id` bigint NOT NULL,
  `file_name` varchar(90) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` bigint NOT NULL,
  `content_type` bigint NOT NULL,
  `original_file_name` varchar(127) DEFAULT NULL,
  `date_uploaded` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`file_id`),
  KEY `issue_files_issue_id` (`issue_id`),
  CONSTRAINT `issue_files_issue_id` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Relationships between issues and issue files, such as cover images.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_files`
--

LOCK TABLES `issue_files` WRITE;
/*!40000 ALTER TABLE `issue_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_galley_settings`
--

DROP TABLE IF EXISTS `issue_galley_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue_galley_settings` (
  `issue_galley_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `galley_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`issue_galley_setting_id`),
  UNIQUE KEY `issue_galley_settings_unique` (`galley_id`,`locale`,`setting_name`),
  KEY `issue_galley_settings_galley_id` (`galley_id`),
  CONSTRAINT `issue_galleys_settings_galley_id` FOREIGN KEY (`galley_id`) REFERENCES `issue_galleys` (`galley_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about issue galleys, including localized content such as labels.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_galley_settings`
--

LOCK TABLES `issue_galley_settings` WRITE;
/*!40000 ALTER TABLE `issue_galley_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue_galley_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_galleys`
--

DROP TABLE IF EXISTS `issue_galleys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue_galleys` (
  `galley_id` bigint NOT NULL AUTO_INCREMENT,
  `locale` varchar(28) DEFAULT NULL,
  `issue_id` bigint NOT NULL,
  `file_id` bigint NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `url_path` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`galley_id`),
  KEY `issue_galleys_issue_id` (`issue_id`),
  KEY `issue_galleys_file_id` (`file_id`),
  KEY `issue_galleys_url_path` (`url_path`),
  CONSTRAINT `issue_galleys_file_id` FOREIGN KEY (`file_id`) REFERENCES `issue_files` (`file_id`) ON DELETE CASCADE,
  CONSTRAINT `issue_galleys_issue_id` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Issue galleys are representations of the entire issue in a single file, such as a complete issue PDF.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_galleys`
--

LOCK TABLES `issue_galleys` WRITE;
/*!40000 ALTER TABLE `issue_galleys` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue_galleys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issue_settings`
--

DROP TABLE IF EXISTS `issue_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issue_settings` (
  `issue_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `issue_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`issue_setting_id`),
  UNIQUE KEY `issue_settings_unique` (`issue_id`,`locale`,`setting_name`),
  KEY `issue_settings_issue_id` (`issue_id`),
  KEY `issue_settings_name_value` (`setting_name`(50),`setting_value`(150)),
  CONSTRAINT `issue_settings_issue_id` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about issues, including localized properties such as issue titles.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issue_settings`
--

LOCK TABLES `issue_settings` WRITE;
/*!40000 ALTER TABLE `issue_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `issue_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issues` (
  `issue_id` bigint NOT NULL AUTO_INCREMENT,
  `journal_id` bigint NOT NULL,
  `volume` smallint DEFAULT NULL,
  `number` varchar(40) DEFAULT NULL,
  `year` smallint DEFAULT NULL,
  `published` smallint NOT NULL DEFAULT '0',
  `date_published` datetime DEFAULT NULL,
  `date_notified` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `access_status` smallint NOT NULL DEFAULT '1',
  `open_access_date` datetime DEFAULT NULL,
  `show_volume` smallint NOT NULL DEFAULT '0',
  `show_number` smallint NOT NULL DEFAULT '0',
  `show_year` smallint NOT NULL DEFAULT '0',
  `show_title` smallint NOT NULL DEFAULT '0',
  `style_file_name` varchar(90) DEFAULT NULL,
  `original_style_file_name` varchar(255) DEFAULT NULL,
  `url_path` varchar(64) DEFAULT NULL,
  `doi_id` bigint DEFAULT NULL,
  PRIMARY KEY (`issue_id`),
  KEY `issues_journal_id` (`journal_id`),
  KEY `issues_doi_id` (`doi_id`),
  KEY `issues_url_path` (`url_path`),
  CONSTRAINT `issues_doi_id_foreign` FOREIGN KEY (`doi_id`) REFERENCES `dois` (`doi_id`) ON DELETE SET NULL,
  CONSTRAINT `issues_journal_id` FOREIGN KEY (`journal_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='A list of all journal issues, with identifying information like year, number, volume, etc.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` text NOT NULL,
  `options` mediumtext,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Job batches allow jobs to be collected into groups for managed processing.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
INSERT INTO `job_batches` VALUES ('9fe73464-44a4-425d-ad10-b1e6c84724d1','',0,0,0,'[]','a:0:{}',NULL,1758153652,NULL),('9ff54912-8f4a-4032-9cff-adde7b7f67b9','',0,0,0,'[]','a:0:{}',NULL,1758758417,NULL),('9fff57ef-6ceb-4a24-9856-ed4fbc76c5d8','',0,0,0,'[]','a:0:{}',NULL,1759190407,NULL),('a02b99a9-95ac-43c8-bbdb-3bd4bc7944ac','',0,0,0,'[]','a:0:{}',NULL,1761091220,NULL),('a02d9cd1-422d-4466-a5f5-acb604544cbe','',0,0,0,'[]','a:0:{}',NULL,1761177649,NULL),('a037ab81-f5bb-4c59-afe3-6202d587af10','',0,0,0,'[]','a:0:{}',NULL,1761609610,NULL),('a043bd86-5ee2-45cc-8804-60c0b6fe9601','',0,0,0,'[]','a:0:{}',NULL,1762128029,NULL),('a047c3a2-e983-4cd8-8675-a25bd1390ed9','',0,0,0,'[]','a:0:{}',NULL,1762300853,NULL),('a04bc996-50e6-436d-bb5c-154785749833','',0,0,0,'[]','a:0:{}',NULL,1762473650,NULL),('a074052c-2af1-47b3-b0bc-52c39518ebe9','',0,0,0,'[]','a:0:{}',NULL,1764201634,NULL),('a0ae5b89-57ca-4614-b701-7235e133513b','',0,0,0,'[]','a:0:{}',NULL,1766707204,NULL),('a0b46485-0f72-4529-99c0-0be8296c5795','',0,0,0,'[]','a:0:{}',NULL,1766966410,NULL),('a0fcd023-10bf-47bd-8ad7-170b37cc5daa','',0,0,0,'[]','a:0:{}',NULL,1770076841,NULL),('a0fed2fe-8994-48d4-8eff-028e6fe77427','',0,0,0,'[]','a:0:{}',NULL,1770163220,NULL),('a11cffd8-2127-45c5-8e26-c6e0ad91b885','',0,0,0,'[]','a:0:{}',NULL,1771459235,NULL),('a12911c8-cc12-4128-bda0-0105a3d5d0f6','',0,0,0,'[]','a:0:{}',NULL,1771977641,NULL),('a139296c-241d-4e35-9353-5385db98bcae','',0,0,0,'[]','a:0:{}',NULL,1772668801,NULL),('a1738047-d03f-45ea-b50a-cafdab1cfadc','',0,0,0,'[]','a:0:{}',NULL,1775174455,NULL),('a1879ddb-d2f6-42fb-8b6c-393f37022da3','',0,0,0,'[]','a:0:{}',NULL,1776038410,NULL),('a199b8d6-289a-4743-b060-0e8aae3b58ba','',0,0,0,'[]','a:0:{}',NULL,1776816031,NULL),('a1c5fa6d-79ad-4aef-9adf-22fd4b7cf8c5','',0,0,0,'[]','a:0:{}',NULL,1778716821,NULL),('a1d20c50-696a-4825-bc98-974c8ef3c421','',0,0,0,'[]','a:0:{}',NULL,1779235218,NULL),('a1ec3324-2229-4516-8529-7035e6a5e7a0','',0,0,0,'[]','a:0:{}',NULL,1780358423,NULL),('a2025409-c7be-4649-bb60-10f74112ccde','',0,0,0,'[]','a:0:{}',NULL,1781308835,NULL),('a2085d13-9116-40d2-aa15-a6136b1e75e6','',0,0,0,'[]','a:0:{}',NULL,1781568050,NULL);
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_index` (`queue`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='All pending or in-progress jobs.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journal_settings`
--

DROP TABLE IF EXISTS `journal_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journal_settings` (
  `journal_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `journal_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`journal_setting_id`),
  UNIQUE KEY `journal_settings_unique` (`journal_id`,`locale`,`setting_name`),
  KEY `journal_settings_journal_id` (`journal_id`),
  CONSTRAINT `journal_settings_journal_id` FOREIGN KEY (`journal_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb3 COMMENT='More data about journals, including localized properties like policies.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal_settings`
--

LOCK TABLES `journal_settings` WRITE;
/*!40000 ALTER TABLE `journal_settings` DISABLE KEYS */;
INSERT INTO `journal_settings` VALUES (1,1,'en','acronym','TJ1'),(2,1,'en','authorGuidelines',''),(3,1,'en','authorInformation',''),(4,1,'en','beginSubmissionHelp',''),(5,1,'','contactEmail','contact@example.test'),(6,1,'','contactName','Test Contact'),(7,1,'en','contributorsHelp',''),(8,1,'','country','US'),(9,1,'','defaultReviewMode','2'),(10,1,'en','description','<p>Test journal fixture.</p>'),(11,1,'en','detailsHelp',''),(12,1,'','copySubmissionAckPrimaryContact','1'),(14,1,'','emailSignature',''),(15,1,'','enableDois','1'),(16,1,'','doiSuffixType','default'),(17,1,'','registrationAgency',''),(18,1,'','disableSubmissions','0'),(19,1,'','editorialStatsEmail','0'),(20,1,'en','forTheEditorsHelp',''),(21,1,'','itemsPerPage','25'),(22,1,'','keywords','request'),(23,1,'en','librarianInformation',''),(24,1,'en','name','Test Journal 1'),(25,1,'','notifyAllAuthors','1'),(26,1,'','numPageLinks','10'),(27,1,'','numWeeksPerResponse','2'),(28,1,'','numWeeksPerReview','8'),(29,1,'','numReviewsPerSubmission','1'),(30,1,'en','openAccessPolicy',''),(31,1,'','orcidCity',''),(32,1,'','orcidClientId',''),(33,1,'','orcidClientSecret',''),(34,1,'','orcidEnabled','0'),(35,1,'','orcidLogLevel','ERROR'),(36,1,'','orcidSendMailToAuthorsOnPublication','0'),(37,1,'en','privacyStatement',''),(38,1,'en','readerInformation',''),(39,1,'en','reviewHelp',''),(40,1,'','submissionAcknowledgement','allAuthors'),(41,1,'en','submissionChecklist',''),(42,1,'','submitWithCategories','0'),(43,1,'','supportedAddedSubmissionLocales','[\"en\"]'),(44,1,'','supportedDefaultSubmissionLocale','en'),(45,1,'','supportedFormLocales','[\"en\"]'),(46,1,'','supportedLocales','[\"en\"]'),(47,1,'','supportedSubmissionLocales','[\"en\"]'),(48,1,'','supportedSubmissionMetadataLocales','[\"en\"]'),(49,1,'','themePluginPath','pragmaSubmissions'),(50,1,'en','uploadFilesHelp',''),(51,1,'','enableGeoUsageStats','disabled'),(52,1,'','enableInstitutionUsageStats','0'),(53,1,'','isSushiApiPublic','1'),(55,1,'en','clockssLicense','This journal utilizes the CLOCKSS system to create a distributed archiving system among participating libraries and permits those libraries to create permanent archives of the journal for purposes of preservation and restoration. <a href=\"https://clockss.org\">More...</a>'),(56,1,'','copyrightYearBasis','issue'),(57,1,'','enabledDoiTypes','[\"publication\"]'),(58,1,'','doiCreationTime','copyEditCreationTime'),(59,1,'','enableOai','0'),(60,1,'en','lockssLicense','This journal utilizes the LOCKSS system to create a distributed archiving system among participating libraries and permits those libraries to create permanent archives of the journal for purposes of preservation and restoration. <a href=\"https://www.lockss.org\">More...</a>'),(61,1,'','membershipFee','0'),(62,1,'','publicationFee','0'),(63,1,'','purchaseArticleFee','0'),(64,1,'','doiVersioning','0'),(67,1,'','sidebar','[]'),(68,1,'','publishingMode','2'),(69,1,'','copyrightHolderType','author'),(70,1,'','licenseUrl','https://creativecommons.org/licenses/by-nc/4.0'),(71,1,'','agencies','0'),(72,1,'','citations','0'),(73,1,'','coverage','0'),(74,1,'','disciplines','0'),(75,1,'','requireAuthorCompetingInterests','0'),(76,1,'','rights','0'),(77,1,'','source','0'),(78,1,'','subjects','0'),(79,1,'','type','0'),(80,1,'','dataAvailability','0'),(81,1,'','enablePublisherId','[]'),(82,1,'','supportEmail','support@example.test'),(83,1,'','supportName','Test Support'),(84,1,'','onlineIssn',''),(85,1,'','publisherInstitution','Example Publisher'),(86,1,'','publisherUrl','https://example.test'),(87,1,'','numDaysBeforeReviewResponseReminderDue','7'),(88,1,'','numDaysAfterReviewSubmitReminderDue','7'),(89,1,'','numDaysBeforeReviewSubmitReminderDue','7'),(90,1,'','restrictReviewerFileAccess','1'),(91,1,'','reviewerAccessKeysEnabled','1'),(92,1,'','showEnsuringLink','1'),(93,1,'en','dateFormatLong','F j, Y'),(94,1,'en','dateFormatShort','Y-m-d'),(95,1,'en','datetimeFormatLong','F j, Y - g:ia'),(96,1,'en','datetimeFormatShort','Y-m-d g:ia'),(97,1,'en','timeFormat','g:ia'),(98,1,'en','favicon','{\"name\":\"favicon110.png\",\"uploadName\":\"favicon_en.png\",\"width\":110,\"height\":110,\"dateUploaded\":\"2025-08-30 00:46:43\",\"altText\":\"P45\"}'),(99,1,'','envelopeSender','noreply@example.test'),(101,1,'en','copyrightNotice',''),(102,1,'en','reviewGuidelines',''),(103,1,'en','about','');
/*!40000 ALTER TABLE `journal_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `journals`
--

DROP TABLE IF EXISTS `journals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `journals` (
  `journal_id` bigint NOT NULL AUTO_INCREMENT,
  `path` varchar(32) NOT NULL,
  `seq` double NOT NULL DEFAULT '0' COMMENT 'Used to order lists of journals',
  `primary_locale` varchar(28) NOT NULL,
  `enabled` smallint NOT NULL DEFAULT '1' COMMENT 'Controls whether or not the journal is considered "live" and will appear on the website. (Note that disabled journals may still be accessible, but only if the user knows the URL.)',
  `current_issue_id` bigint DEFAULT NULL,
  PRIMARY KEY (`journal_id`),
  UNIQUE KEY `journals_path` (`path`),
  KEY `journals_issue_id` (`current_issue_id`),
  CONSTRAINT `journals_current_issue_id_foreign` FOREIGN KEY (`current_issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COMMENT='A list of all journals in the installation of OJS.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journals`
--

LOCK TABLES `journals` WRITE;
/*!40000 ALTER TABLE `journals` DISABLE KEYS */;
INSERT INTO `journals` VALUES (1,'journal',1,'en',1,NULL);
/*!40000 ALTER TABLE `journals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_file_settings`
--

DROP TABLE IF EXISTS `library_file_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_file_settings` (
  `library_file_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `file_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object|date)',
  PRIMARY KEY (`library_file_setting_id`),
  UNIQUE KEY `library_file_settings_unique` (`file_id`,`locale`,`setting_name`),
  KEY `library_file_settings_file_id` (`file_id`),
  CONSTRAINT `library_file_settings_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `library_files` (`file_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about library files, including localized content such as names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_file_settings`
--

LOCK TABLES `library_file_settings` WRITE;
/*!40000 ALTER TABLE `library_file_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_file_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library_files`
--

DROP TABLE IF EXISTS `library_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `library_files` (
  `file_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `original_file_name` varchar(255) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` bigint NOT NULL,
  `type` smallint NOT NULL,
  `date_uploaded` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `submission_id` bigint DEFAULT NULL,
  `public_access` smallint DEFAULT '0',
  PRIMARY KEY (`file_id`),
  KEY `library_files_context_id` (`context_id`),
  KEY `library_files_submission_id` (`submission_id`),
  CONSTRAINT `library_files_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `library_files_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Library files can be associated with the context (press/server/journal) or with individual submissions, and are typically forms, agreements, and other administrative documents that are not part of the scholarly content.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library_files`
--

LOCK TABLES `library_files` WRITE;
/*!40000 ALTER TABLE `library_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `library_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_context`
--

DROP TABLE IF EXISTS `metrics_context`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_context` (
  `metrics_context_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `context_id` bigint NOT NULL,
  `date` date NOT NULL,
  `metric` int NOT NULL,
  PRIMARY KEY (`metrics_context_id`),
  KEY `metrics_context_load_id` (`load_id`),
  KEY `metrics_context_context_id` (`context_id`),
  CONSTRAINT `metrics_context_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=327 DEFAULT CHARSET=utf8mb3 COMMENT='Daily statistics for views of the homepage.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_context`
--

LOCK TABLES `metrics_context` WRITE;
/*!40000 ALTER TABLE `metrics_context` DISABLE KEYS */;
INSERT INTO `metrics_context` VALUES (1,'usage_events_20250902.log',1,'2025-09-02',6),(2,'usage_events_20250904.log',1,'2025-09-04',9),(3,'usage_events_20250917.log',1,'2025-09-17',4),(4,'usage_events_20250819.log',1,'2025-08-19',13),(5,'usage_events_20250903.log',1,'2025-09-03',4),(6,'usage_events_20250910.log',1,'2025-09-10',11),(7,'usage_events_20250824.log',1,'2025-08-24',6),(8,'usage_events_20250831.log',1,'2025-08-31',3),(9,'usage_events_20250905.log',1,'2025-09-05',9),(10,'usage_events_20250822.log',1,'2025-08-22',13),(12,'usage_events_20250908.log',1,'2025-09-08',6),(13,'usage_events_20250830.log',1,'2025-08-30',16),(15,'usage_events_20250907.log',1,'2025-09-07',8),(16,'usage_events_20250828.log',1,'2025-08-28',5),(17,'usage_events_20250911.log',1,'2025-09-11',10),(18,'usage_events_20250825.log',1,'2025-08-25',3),(19,'usage_events_20250916.log',1,'2025-09-16',5),(20,'usage_events_20250826.log',1,'2025-08-26',7),(21,'usage_events_20250906.log',1,'2025-09-06',11),(22,'usage_events_20250829.log',1,'2025-08-29',6),(23,'usage_events_20250827.log',1,'2025-08-27',5),(24,'usage_events_20250901.log',1,'2025-09-01',8),(25,'usage_events_20250823.log',1,'2025-08-23',6),(26,'usage_events_20250820.log',1,'2025-08-20',18),(28,'usage_events_20250915.log',1,'2025-09-15',7),(29,'usage_events_20250909.log',1,'2025-09-09',9),(30,'usage_events_20250821.log',1,'2025-08-21',46),(31,'usage_events_20250918.log',1,'2025-09-18',8),(32,'usage_events_20250924.log',1,'2025-09-24',5),(34,'usage_events_20250923.log',1,'2025-09-23',3),(35,'usage_events_20250919.log',1,'2025-09-19',6),(36,'usage_events_20250920.log',1,'2025-09-20',5),(38,'usage_events_20250926.log',1,'2025-09-26',9),(39,'usage_events_20250928.log',1,'2025-09-28',5),(40,'usage_events_20250925.log',1,'2025-09-25',6),(41,'usage_events_20250927.log',1,'2025-09-27',5),(43,'usage_events_20251008.log',1,'2025-10-08',5),(45,'usage_events_20251012.log',1,'2025-10-12',6),(46,'usage_events_20251001.log',1,'2025-10-01',3),(47,'usage_events_20250930.log',1,'2025-09-30',7),(50,'usage_events_20251016.log',1,'2025-10-16',8),(52,'usage_events_20251021.log',1,'2025-10-21',17),(53,'usage_events_20251014.log',1,'2025-10-14',6),(54,'usage_events_20251002.log',1,'2025-10-02',12),(56,'usage_events_20251017.log',1,'2025-10-17',7),(57,'usage_events_20251009.log',1,'2025-10-09',6),(58,'usage_events_20251015.log',1,'2025-10-15',12),(59,'usage_events_20251018.log',1,'2025-10-18',7),(60,'usage_events_20251019.log',1,'2025-10-19',62),(61,'usage_events_20251013.log',1,'2025-10-13',5),(64,'usage_events_20251004.log',1,'2025-10-04',3),(65,'usage_events_20251022.log',1,'2025-10-22',17),(67,'usage_events_20251026.log',1,'2025-10-26',11),(69,'usage_events_20251023.log',1,'2025-10-23',12),(70,'usage_events_20251027.log',1,'2025-10-27',8),(71,'usage_events_20251102.log',1,'2025-11-02',7),(72,'usage_events_20251029.log',1,'2025-10-29',4),(73,'usage_events_20251031.log',1,'2025-10-31',13),(74,'usage_events_20251101.log',1,'2025-11-01',6),(75,'usage_events_20251030.log',1,'2025-10-30',4),(76,'usage_events_20251028.log',1,'2025-10-28',9),(77,'usage_events_20251104.log',1,'2025-11-04',6),(78,'usage_events_20251103.log',1,'2025-11-03',4),(79,'usage_events_20251106.log',1,'2025-11-06',5),(80,'usage_events_20251105.log',1,'2025-11-05',5),(81,'usage_events_20251119.log',1,'2025-11-19',4),(82,'usage_events_20251120.log',1,'2025-11-20',6),(83,'usage_events_20251114.log',1,'2025-11-14',11),(84,'usage_events_20251109.log',1,'2025-11-09',10),(85,'usage_events_20251111.log',1,'2025-11-11',4),(86,'usage_events_20251110.log',1,'2025-11-10',9),(87,'usage_events_20251125.log',1,'2025-11-25',10),(88,'usage_events_20251121.log',1,'2025-11-21',14),(89,'usage_events_20251118.log',1,'2025-11-18',5),(91,'usage_events_20251124.log',1,'2025-11-24',10),(92,'usage_events_20251126.log',1,'2025-11-26',5),(93,'usage_events_20251112.log',1,'2025-11-12',4),(94,'usage_events_20251116.log',1,'2025-11-16',7),(95,'usage_events_20251107.log',1,'2025-11-07',7),(96,'usage_events_20251117.log',1,'2025-11-17',7),(97,'usage_events_20251108.log',1,'2025-11-08',5),(98,'usage_events_20251122.log',1,'2025-11-22',5),(101,'usage_events_20251129.log',1,'2025-11-29',9),(102,'usage_events_20251206.log',1,'2025-12-06',6),(103,'usage_events_20251221.log',1,'2025-12-21',7),(104,'usage_events_20251216.log',1,'2025-12-16',9),(105,'usage_events_20251209.log',1,'2025-12-09',9),(106,'usage_events_20251211.log',1,'2025-12-11',4),(107,'usage_events_20251203.log',1,'2025-12-03',10),(108,'usage_events_20251207.log',1,'2025-12-07',7),(109,'usage_events_20251219.log',1,'2025-12-19',34),(110,'usage_events_20251225.log',1,'2025-12-25',7),(111,'usage_events_20251222.log',1,'2025-12-22',13),(112,'usage_events_20251224.log',1,'2025-12-24',10),(113,'usage_events_20251223.log',1,'2025-12-23',7),(114,'usage_events_20251210.log',1,'2025-12-10',4),(115,'usage_events_20251127.log',1,'2025-11-27',3),(116,'usage_events_20251218.log',1,'2025-12-18',44),(117,'usage_events_20251202.log',1,'2025-12-02',8),(118,'usage_events_20251205.log',1,'2025-12-05',6),(119,'usage_events_20251208.log',1,'2025-12-08',4),(120,'usage_events_20251204.log',1,'2025-12-04',12),(121,'usage_events_20251220.log',1,'2025-12-20',26),(122,'usage_events_20251130.log',1,'2025-11-30',5),(123,'usage_events_20251215.log',1,'2025-12-15',8),(124,'usage_events_20251128.log',1,'2025-11-28',5),(125,'usage_events_20251213.log',1,'2025-12-13',8),(126,'usage_events_20251217.log',1,'2025-12-17',6),(127,'usage_events_20251201.log',1,'2025-12-01',10),(128,'usage_events_20251214.log',1,'2025-12-14',10),(129,'usage_events_20251212.log',1,'2025-12-12',10),(130,'usage_events_20251226.log',1,'2025-12-26',7),(131,'usage_events_20251228.log',1,'2025-12-28',7),(132,'usage_events_20251227.log',1,'2025-12-27',8),(133,'usage_events_20260131.log',1,'2026-01-31',4),(134,'usage_events_20260107.log',1,'2026-01-07',10),(135,'usage_events_20260113.log',1,'2026-01-13',7),(136,'usage_events_20260119.log',1,'2026-01-19',7),(137,'usage_events_20260105.log',1,'2026-01-05',6),(138,'usage_events_20260116.log',1,'2026-01-16',10),(139,'usage_events_20260120.log',1,'2026-01-20',7),(140,'usage_events_20260112.log',1,'2026-01-12',9),(141,'usage_events_20260129.log',1,'2026-01-29',10),(142,'usage_events_20260121.log',1,'2026-01-21',5),(143,'usage_events_20260118.log',1,'2026-01-18',7),(144,'usage_events_20260128.log',1,'2026-01-28',6),(145,'usage_events_20251229.log',1,'2025-12-29',8),(146,'usage_events_20260201.log',1,'2026-02-01',6),(147,'usage_events_20260103.log',1,'2026-01-03',9),(148,'usage_events_20260102.log',1,'2026-01-02',10),(149,'usage_events_20260124.log',1,'2026-01-24',5),(150,'usage_events_20260111.log',1,'2026-01-11',8),(151,'usage_events_20260110.log',1,'2026-01-10',16),(152,'usage_events_20260125.log',1,'2026-01-25',10),(153,'usage_events_20260115.log',1,'2026-01-15',5),(154,'usage_events_20260101.log',1,'2026-01-01',4),(155,'usage_events_20260202.log',1,'2026-02-02',9),(156,'usage_events_20251230.log',1,'2025-12-30',4),(157,'usage_events_20260122.log',1,'2026-01-22',6),(158,'usage_events_20260109.log',1,'2026-01-09',9),(159,'usage_events_20260114.log',1,'2026-01-14',6),(160,'usage_events_20260127.log',1,'2026-01-27',7),(161,'usage_events_20251231.log',1,'2025-12-31',9),(162,'usage_events_20260130.log',1,'2026-01-30',6),(163,'usage_events_20260104.log',1,'2026-01-04',9),(164,'usage_events_20260117.log',1,'2026-01-17',6),(165,'usage_events_20260108.log',1,'2026-01-08',9),(166,'usage_events_20260126.log',1,'2026-01-26',5),(167,'usage_events_20260123.log',1,'2026-01-23',10),(168,'usage_events_20260106.log',1,'2026-01-06',6),(169,'usage_events_20260203.log',1,'2026-02-03',19),(170,'usage_events_20260205.log',1,'2026-02-05',7),(171,'usage_events_20260217.log',1,'2026-02-17',20),(172,'usage_events_20260207.log',1,'2026-02-07',9),(173,'usage_events_20260208.log',1,'2026-02-08',6),(174,'usage_events_20260204.log',1,'2026-02-04',12),(175,'usage_events_20260210.log',1,'2026-02-10',13),(176,'usage_events_20260214.log',1,'2026-02-14',4),(177,'usage_events_20260212.log',1,'2026-02-12',12),(178,'usage_events_20260213.log',1,'2026-02-13',9),(179,'usage_events_20260216.log',1,'2026-02-16',30),(180,'usage_events_20260218.log',1,'2026-02-18',7),(181,'usage_events_20260215.log',1,'2026-02-15',9),(182,'usage_events_20260206.log',1,'2026-02-06',7),(183,'usage_events_20260209.log',1,'2026-02-09',11),(184,'usage_events_20260211.log',1,'2026-02-11',7),(185,'usage_events_20260222.log',1,'2026-02-22',17),(186,'usage_events_20260223.log',1,'2026-02-23',10),(187,'usage_events_20260221.log',1,'2026-02-21',13),(188,'usage_events_20260220.log',1,'2026-02-20',8),(189,'usage_events_20260219.log',1,'2026-02-19',14),(190,'usage_events_20260224.log',1,'2026-02-24',9),(191,'usage_events_20260304.log',1,'2026-03-04',20),(192,'usage_events_20260228.log',1,'2026-02-28',8),(193,'usage_events_20260226.log',1,'2026-02-26',8),(194,'usage_events_20260302.log',1,'2026-03-02',12),(195,'usage_events_20260227.log',1,'2026-02-27',15),(196,'usage_events_20260303.log',1,'2026-03-03',11),(197,'usage_events_20260301.log',1,'2026-03-01',8),(198,'usage_events_20260225.log',1,'2026-02-25',9),(199,'usage_events_20260306.log',1,'2026-03-06',12),(200,'usage_events_20260309.log',1,'2026-03-09',2),(201,'usage_events_20260330.log',1,'2026-03-30',10),(202,'usage_events_20260402.log',1,'2026-04-02',7),(203,'usage_events_20260331.log',1,'2026-03-31',14),(204,'usage_events_20260307.log',1,'2026-03-07',9),(205,'usage_events_20260308.log',1,'2026-03-08',12),(206,'usage_events_20260401.log',1,'2026-04-01',5),(207,'usage_events_20260305.log',1,'2026-03-05',17),(208,'usage_events_20260404.log',1,'2026-04-04',14),(209,'usage_events_20260403.log',1,'2026-04-03',8),(210,'usage_events_20260411.log',1,'2026-04-11',5),(211,'usage_events_20260405.log',1,'2026-04-05',13),(212,'usage_events_20260410.log',1,'2026-04-10',11),(213,'usage_events_20260407.log',1,'2026-04-07',8),(214,'usage_events_20260406.log',1,'2026-04-06',14),(215,'usage_events_20260408.log',1,'2026-04-08',16),(216,'usage_events_20260409.log',1,'2026-04-09',13),(217,'usage_events_20260412.log',1,'2026-04-12',11),(218,'usage_events_20260420.log',1,'2026-04-20',17),(219,'usage_events_20260413.log',1,'2026-04-13',14),(220,'usage_events_20260417.log',1,'2026-04-17',50),(221,'usage_events_20260416.log',1,'2026-04-16',16),(222,'usage_events_20260418.log',1,'2026-04-18',25),(223,'usage_events_20260414.log',1,'2026-04-14',11),(224,'usage_events_20260415.log',1,'2026-04-15',10),(225,'usage_events_20260421.log',1,'2026-04-21',15),(226,'usage_events_20260419.log',1,'2026-04-19',13),(227,'usage_events_20260430.log',1,'2026-04-30',13),(228,'usage_events_20260501.log',1,'2026-05-01',7),(229,'usage_events_20260425.log',1,'2026-04-25',9),(230,'usage_events_20260512.log',1,'2026-05-12',22),(231,'usage_events_20260505.log',1,'2026-05-05',11),(232,'usage_events_20260422.log',1,'2026-04-22',9),(233,'usage_events_20260507.log',1,'2026-05-07',8),(234,'usage_events_20260506.log',1,'2026-05-06',6),(235,'usage_events_20260423.log',1,'2026-04-23',25),(236,'usage_events_20260427.log',1,'2026-04-27',11),(237,'usage_events_20260513.log',1,'2026-05-13',15),(238,'usage_events_20260510.log',1,'2026-05-10',4),(239,'usage_events_20260428.log',1,'2026-04-28',7),(240,'usage_events_20260509.log',1,'2026-05-09',5),(241,'usage_events_20260424.log',1,'2026-04-24',9),(242,'usage_events_20260504.log',1,'2026-05-04',12),(243,'usage_events_20260503.log',1,'2026-05-03',10),(244,'usage_events_20260502.log',1,'2026-05-02',16),(245,'usage_events_20260508.log',1,'2026-05-08',7),(246,'usage_events_20260511.log',1,'2026-05-11',11),(247,'usage_events_20260426.log',1,'2026-04-26',8),(248,'usage_events_20260429.log',1,'2026-04-29',24),(249,'usage_events_20260518.log',1,'2026-05-18',11),(250,'usage_events_20260515.log',1,'2026-05-15',16),(251,'usage_events_20260519.log',1,'2026-05-19',17),(252,'usage_events_20260517.log',1,'2026-05-17',9),(253,'usage_events_20260514.log',1,'2026-05-14',16),(254,'usage_events_20260516.log',1,'2026-05-16',10),(255,'usage_events_20260521.log',1,'2026-05-21',22),(256,'usage_events_20260522.log',1,'2026-05-22',12),(257,'usage_events_20260528.log',1,'2026-05-28',6),(258,'usage_events_20260526.log',1,'2026-05-26',6),(259,'usage_events_20260524.log',1,'2026-05-24',6),(260,'usage_events_20260520.log',1,'2026-05-20',17),(261,'usage_events_20260601.log',1,'2026-06-01',12),(262,'usage_events_20260523.log',1,'2026-05-23',8),(263,'usage_events_20260529.log',1,'2026-05-29',7),(264,'usage_events_20260525.log',1,'2026-05-25',8),(265,'usage_events_20260531.log',1,'2026-05-31',6),(266,'usage_events_20260527.log',1,'2026-05-27',14),(267,'usage_events_20260530.log',1,'2026-05-30',5),(268,'usage_events_20260608.log',1,'2026-06-08',5),(269,'usage_events_20260605.log',1,'2026-06-05',6),(270,'usage_events_20260609.log',1,'2026-06-09',4),(271,'usage_events_20260612.log',1,'2026-06-12',7),(272,'usage_events_20260603.log',1,'2026-06-03',7),(273,'usage_events_20260602.log',1,'2026-06-02',8),(274,'usage_events_20260611.log',1,'2026-06-11',6),(275,'usage_events_20260604.log',1,'2026-06-04',5),(276,'usage_events_20260610.log',1,'2026-06-10',13),(277,'usage_events_20260607.log',1,'2026-06-07',11),(278,'usage_events_20260606.log',1,'2026-06-06',4),(279,'usage_events_20260614.log',1,'2026-06-14',10),(280,'usage_events_20260615.log',1,'2026-06-15',19),(281,'usage_events_20260613.log',1,'2026-06-13',12),(283,'usage_events_20260622.log',1,'2026-06-22',19),(284,'usage_events_20260617.log',1,'2026-06-17',59),(285,'usage_events_20260621.log',1,'2026-06-21',12),(286,'usage_events_20260619.log',1,'2026-06-19',12),(288,'usage_events_20260620.log',1,'2026-06-20',7),(289,'usage_events_20260625.log',1,'2026-06-25',19),(290,'usage_events_20260626.log',1,'2026-06-26',13),(291,'usage_events_20260623.log',1,'2026-06-23',16),(292,'usage_events_20260624.log',1,'2026-06-24',14),(293,'usage_events_20250912.log',1,'2025-09-12',23),(294,'usage_events_20260710.log',1,'2026-07-10',37),(295,'usage_events_20251006.log',1,'2025-10-06',17),(296,'usage_events_20260714.log',1,'2026-07-14',9),(297,'usage_events_20260720.log',1,'2026-07-20',8),(298,'usage_events_20260628.log',1,'2026-06-28',1),(299,'usage_events_20260708.log',1,'2026-07-08',18),(300,'usage_events_20250913.log',1,'2025-09-13',31),(301,'usage_events_20250922.log',1,'2025-09-22',1),(302,'usage_events_20251113.log',1,'2025-11-13',1),(303,'usage_events_20251010.log',1,'2025-10-10',2),(304,'usage_events_20251011.log',1,'2025-10-11',4),(305,'usage_events_20260616.log',1,'2026-06-16',4),(306,'usage_events_20260711.log',1,'2026-07-11',2),(307,'usage_events_20251007.log',1,'2025-10-07',11),(308,'usage_events_20260709.log',1,'2026-07-09',35),(309,'usage_events_20251115.log',1,'2025-11-15',1),(310,'usage_events_20260713.log',1,'2026-07-13',7),(311,'usage_events_20251123.log',1,'2025-11-23',1),(312,'usage_events_20260716.log',1,'2026-07-16',1),(313,'usage_events_20260719.log',1,'2026-07-19',2),(314,'usage_events_20250921.log',1,'2025-09-21',1),(315,'usage_events_20260627.log',1,'2026-06-27',1),(316,'usage_events_20250929.log',1,'2025-09-29',35),(317,'usage_events_20251025.log',1,'2025-10-25',4),(318,'usage_events_20260722.log',1,'2026-07-22',1),(319,'usage_events_20251005.log',1,'2025-10-05',9),(320,'usage_events_20251020.log',1,'2025-10-20',6),(321,'usage_events_20251003.log',1,'2025-10-03',49),(322,'usage_events_20260723.log',1,'2026-07-23',8),(323,'usage_events_20260715.log',1,'2026-07-15',24),(324,'usage_events_20260618.log',1,'2026-06-18',1),(325,'usage_events_20250914.log',1,'2025-09-14',1),(326,'usage_events_20251024.log',1,'2025-10-24',7);
/*!40000 ALTER TABLE `metrics_context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_counter_submission_daily`
--

DROP TABLE IF EXISTS `metrics_counter_submission_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_counter_submission_daily` (
  `metrics_counter_submission_daily_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `context_id` bigint NOT NULL,
  `submission_id` bigint NOT NULL,
  `date` date NOT NULL,
  `metric_investigations` int NOT NULL,
  `metric_investigations_unique` int NOT NULL,
  `metric_requests` int NOT NULL,
  `metric_requests_unique` int NOT NULL,
  PRIMARY KEY (`metrics_counter_submission_daily_id`),
  UNIQUE KEY `msd_uc_load_id_context_id_submission_id_date` (`load_id`,`context_id`,`submission_id`,`date`),
  KEY `msd_load_id` (`load_id`),
  KEY `metrics_counter_submission_daily_context_id` (`context_id`),
  KEY `metrics_counter_submission_daily_submission_id` (`submission_id`),
  KEY `msd_context_id_submission_id` (`context_id`,`submission_id`),
  CONSTRAINT `msd_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `msd_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Daily statistics matching the COUNTER R5 protocol for views and downloads of published submissions and galleys.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_counter_submission_daily`
--

LOCK TABLES `metrics_counter_submission_daily` WRITE;
/*!40000 ALTER TABLE `metrics_counter_submission_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_counter_submission_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_counter_submission_institution_daily`
--

DROP TABLE IF EXISTS `metrics_counter_submission_institution_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_counter_submission_institution_daily` (
  `metrics_counter_submission_institution_daily_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `context_id` bigint NOT NULL,
  `submission_id` bigint NOT NULL,
  `institution_id` bigint NOT NULL,
  `date` date NOT NULL,
  `metric_investigations` int NOT NULL,
  `metric_investigations_unique` int NOT NULL,
  `metric_requests` int NOT NULL,
  `metric_requests_unique` int NOT NULL,
  PRIMARY KEY (`metrics_counter_submission_institution_daily_id`),
  UNIQUE KEY `msid_uc_load_id_context_id_submission_id_institution_id_date` (`load_id`,`context_id`,`submission_id`,`institution_id`,`date`),
  KEY `msid_load_id` (`load_id`),
  KEY `metrics_counter_submission_institution_daily_context_id` (`context_id`),
  KEY `metrics_counter_submission_institution_daily_submission_id` (`submission_id`),
  KEY `metrics_counter_submission_institution_daily_institution_id` (`institution_id`),
  KEY `msid_context_id_submission_id` (`context_id`,`submission_id`),
  CONSTRAINT `msid_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `msid_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`institution_id`) ON DELETE CASCADE,
  CONSTRAINT `msid_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Daily statistics matching the COUNTER R5 protocol for views and downloads from institutions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_counter_submission_institution_daily`
--

LOCK TABLES `metrics_counter_submission_institution_daily` WRITE;
/*!40000 ALTER TABLE `metrics_counter_submission_institution_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_counter_submission_institution_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_counter_submission_institution_monthly`
--

DROP TABLE IF EXISTS `metrics_counter_submission_institution_monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_counter_submission_institution_monthly` (
  `metrics_counter_submission_institution_monthly_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `submission_id` bigint NOT NULL,
  `institution_id` bigint NOT NULL,
  `month` int NOT NULL,
  `metric_investigations` int NOT NULL,
  `metric_investigations_unique` int NOT NULL,
  `metric_requests` int NOT NULL,
  `metric_requests_unique` int NOT NULL,
  PRIMARY KEY (`metrics_counter_submission_institution_monthly_id`),
  UNIQUE KEY `msim_uc_context_id_submission_id_institution_id_month` (`context_id`,`submission_id`,`institution_id`,`month`),
  KEY `metrics_counter_submission_institution_monthly_context_id` (`context_id`),
  KEY `metrics_counter_submission_institution_monthly_submission_id` (`submission_id`),
  KEY `metrics_counter_submission_institution_monthly_institution_id` (`institution_id`),
  KEY `msim_context_id_submission_id` (`context_id`,`submission_id`),
  CONSTRAINT `msim_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `msim_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`institution_id`) ON DELETE CASCADE,
  CONSTRAINT `msim_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Monthly statistics matching the COUNTER R5 protocol for views and downloads from institutions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_counter_submission_institution_monthly`
--

LOCK TABLES `metrics_counter_submission_institution_monthly` WRITE;
/*!40000 ALTER TABLE `metrics_counter_submission_institution_monthly` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_counter_submission_institution_monthly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_counter_submission_monthly`
--

DROP TABLE IF EXISTS `metrics_counter_submission_monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_counter_submission_monthly` (
  `metrics_counter_submission_monthly_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `submission_id` bigint NOT NULL,
  `month` int NOT NULL,
  `metric_investigations` int NOT NULL,
  `metric_investigations_unique` int NOT NULL,
  `metric_requests` int NOT NULL,
  `metric_requests_unique` int NOT NULL,
  PRIMARY KEY (`metrics_counter_submission_monthly_id`),
  UNIQUE KEY `msm_uc_context_id_submission_id_month` (`context_id`,`submission_id`,`month`),
  KEY `metrics_counter_submission_monthly_context_id` (`context_id`),
  KEY `metrics_counter_submission_monthly_submission_id` (`submission_id`),
  KEY `msm_context_id_submission_id` (`context_id`,`submission_id`),
  CONSTRAINT `msm_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `msm_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Monthly statistics matching the COUNTER R5 protocol for views and downloads of published submissions and galleys.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_counter_submission_monthly`
--

LOCK TABLES `metrics_counter_submission_monthly` WRITE;
/*!40000 ALTER TABLE `metrics_counter_submission_monthly` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_counter_submission_monthly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_issue`
--

DROP TABLE IF EXISTS `metrics_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_issue` (
  `metrics_issue_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `context_id` bigint NOT NULL,
  `issue_id` bigint NOT NULL,
  `issue_galley_id` bigint DEFAULT NULL,
  `date` date NOT NULL,
  `metric` int NOT NULL,
  PRIMARY KEY (`metrics_issue_id`),
  KEY `metrics_issue_load_id` (`load_id`),
  KEY `metrics_issue_context_id` (`context_id`),
  KEY `metrics_issue_issue_id` (`issue_id`),
  KEY `metrics_issue_issue_galley_id` (`issue_galley_id`),
  KEY `metrics_issue_context_id_issue_id` (`context_id`,`issue_id`),
  CONSTRAINT `metrics_issue_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `metrics_issue_issue_galley_id_foreign` FOREIGN KEY (`issue_galley_id`) REFERENCES `issue_galleys` (`galley_id`) ON DELETE CASCADE,
  CONSTRAINT `metrics_issue_issue_id_foreign` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Daily statistics for views and downloads of published issues.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_issue`
--

LOCK TABLES `metrics_issue` WRITE;
/*!40000 ALTER TABLE `metrics_issue` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_submission`
--

DROP TABLE IF EXISTS `metrics_submission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_submission` (
  `metrics_submission_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `context_id` bigint NOT NULL,
  `submission_id` bigint NOT NULL,
  `representation_id` bigint DEFAULT NULL,
  `submission_file_id` bigint unsigned DEFAULT NULL,
  `file_type` bigint DEFAULT NULL,
  `assoc_type` bigint NOT NULL,
  `date` date NOT NULL,
  `metric` int NOT NULL,
  PRIMARY KEY (`metrics_submission_id`),
  KEY `ms_load_id` (`load_id`),
  KEY `metrics_submission_context_id` (`context_id`),
  KEY `metrics_submission_submission_id` (`submission_id`),
  KEY `metrics_submission_representation_id` (`representation_id`),
  KEY `metrics_submission_submission_file_id` (`submission_file_id`),
  KEY `ms_context_id_submission_id_assoc_type_file_type` (`context_id`,`submission_id`,`assoc_type`,`file_type`),
  CONSTRAINT `metrics_submission_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `metrics_submission_representation_id_foreign` FOREIGN KEY (`representation_id`) REFERENCES `publication_galleys` (`galley_id`) ON DELETE CASCADE,
  CONSTRAINT `metrics_submission_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE,
  CONSTRAINT `metrics_submission_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Daily statistics for views and downloads of published submissions and galleys.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_submission`
--

LOCK TABLES `metrics_submission` WRITE;
/*!40000 ALTER TABLE `metrics_submission` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_submission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_submission_geo_daily`
--

DROP TABLE IF EXISTS `metrics_submission_geo_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_submission_geo_daily` (
  `metrics_submission_geo_daily_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `context_id` bigint NOT NULL,
  `submission_id` bigint NOT NULL,
  `country` varchar(2) NOT NULL DEFAULT '',
  `region` varchar(3) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `date` date NOT NULL,
  `metric` int NOT NULL,
  `metric_unique` int NOT NULL,
  PRIMARY KEY (`metrics_submission_geo_daily_id`),
  UNIQUE KEY `msgd_uc_load_context_submission_c_r_c_date` (`load_id`,`context_id`,`submission_id`,`country`,`region`,`city`(80),`date`),
  KEY `msgd_load_id` (`load_id`),
  KEY `metrics_submission_geo_daily_context_id` (`context_id`),
  KEY `metrics_submission_geo_daily_submission_id` (`submission_id`),
  KEY `msgd_context_id_submission_id` (`context_id`,`submission_id`),
  CONSTRAINT `msgd_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `msgd_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Daily statistics by country, region and city for views and downloads of published submissions and galleys.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_submission_geo_daily`
--

LOCK TABLES `metrics_submission_geo_daily` WRITE;
/*!40000 ALTER TABLE `metrics_submission_geo_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_submission_geo_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics_submission_geo_monthly`
--

DROP TABLE IF EXISTS `metrics_submission_geo_monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics_submission_geo_monthly` (
  `metrics_submission_geo_monthly_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `submission_id` bigint NOT NULL,
  `country` varchar(2) NOT NULL DEFAULT '',
  `region` varchar(3) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `month` int NOT NULL,
  `metric` int NOT NULL,
  `metric_unique` int NOT NULL,
  PRIMARY KEY (`metrics_submission_geo_monthly_id`),
  UNIQUE KEY `msgm_uc_context_submission_c_r_c_month` (`context_id`,`submission_id`,`country`,`region`,`city`(80),`month`),
  KEY `metrics_submission_geo_monthly_context_id` (`context_id`),
  KEY `metrics_submission_geo_monthly_submission_id` (`submission_id`),
  KEY `msgm_context_id_submission_id` (`context_id`,`submission_id`),
  CONSTRAINT `msgm_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `msgm_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Monthly statistics by country, region and city for views and downloads of published submissions and galleys.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics_submission_geo_monthly`
--

LOCK TABLES `metrics_submission_geo_monthly` WRITE;
/*!40000 ALTER TABLE `metrics_submission_geo_monthly` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics_submission_geo_monthly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menu_item_assignment_settings`
--

DROP TABLE IF EXISTS `navigation_menu_item_assignment_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menu_item_assignment_settings` (
  `navigation_menu_item_assignment_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `navigation_menu_item_assignment_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`navigation_menu_item_assignment_setting_id`),
  UNIQUE KEY `navigation_menu_item_assignment_settings_unique` (`navigation_menu_item_assignment_id`,`locale`,`setting_name`),
  KEY `navigation_menu_item_assignment_settings_n_m_i_a_id` (`navigation_menu_item_assignment_id`),
  CONSTRAINT `assignment_settings_navigation_menu_item_assignment_id` FOREIGN KEY (`navigation_menu_item_assignment_id`) REFERENCES `navigation_menu_item_assignments` (`navigation_menu_item_assignment_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COMMENT='More data about navigation menu item assignments to navigation menus, including localized content.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menu_item_assignment_settings`
--

LOCK TABLES `navigation_menu_item_assignment_settings` WRITE;
/*!40000 ALTER TABLE `navigation_menu_item_assignment_settings` DISABLE KEYS */;
INSERT INTO `navigation_menu_item_assignment_settings` VALUES (10,37,'en','title','Submission Guidelines','string'),(11,38,'en','title','Special Issue Proposal Guidelines','string'),(12,39,'en','title','CFPs','string'),(13,41,'en','title','Return to <i>Post45 Journal</i>','string');
/*!40000 ALTER TABLE `navigation_menu_item_assignment_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menu_item_assignments`
--

DROP TABLE IF EXISTS `navigation_menu_item_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menu_item_assignments` (
  `navigation_menu_item_assignment_id` bigint NOT NULL AUTO_INCREMENT,
  `navigation_menu_id` bigint NOT NULL,
  `navigation_menu_item_id` bigint NOT NULL,
  `parent_id` bigint DEFAULT NULL,
  `seq` bigint DEFAULT '0',
  PRIMARY KEY (`navigation_menu_item_assignment_id`),
  KEY `navigation_menu_item_assignments_navigation_menu_id` (`navigation_menu_id`),
  KEY `navigation_menu_item_assignments_navigation_menu_item_id` (`navigation_menu_item_id`),
  KEY `navigation_menu_item_assignments_parent_id` (`parent_id`),
  CONSTRAINT `navigation_menu_item_assignments_navigation_menu_id_foreign` FOREIGN KEY (`navigation_menu_id`) REFERENCES `navigation_menus` (`navigation_menu_id`) ON DELETE CASCADE,
  CONSTRAINT `navigation_menu_item_assignments_navigation_menu_item_id_foreign` FOREIGN KEY (`navigation_menu_item_id`) REFERENCES `navigation_menu_items` (`navigation_menu_item_id`) ON DELETE CASCADE,
  CONSTRAINT `navigation_menu_item_assignments_parent_id` FOREIGN KEY (`parent_id`) REFERENCES `navigation_menu_items` (`navigation_menu_item_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb3 COMMENT='Links navigation menu items to navigation menus.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menu_item_assignments`
--

LOCK TABLES `navigation_menu_item_assignments` WRITE;
/*!40000 ALTER TABLE `navigation_menu_item_assignments` DISABLE KEYS */;
INSERT INTO `navigation_menu_item_assignments` VALUES (1,1,1,NULL,0),(2,1,2,NULL,1),(3,1,3,NULL,2),(4,1,4,3,0),(5,1,5,3,1),(6,1,6,3,2),(7,1,7,3,3),(8,2,8,NULL,0),(9,2,9,NULL,1),(10,2,10,NULL,2),(11,2,11,10,0),(12,2,12,10,1),(13,2,13,10,2),(14,2,14,10,3),(37,3,18,NULL,0),(38,3,26,NULL,1),(39,3,27,NULL,2),(40,3,19,NULL,3),(41,3,25,NULL,4);
/*!40000 ALTER TABLE `navigation_menu_item_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menu_item_settings`
--

DROP TABLE IF EXISTS `navigation_menu_item_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menu_item_settings` (
  `navigation_menu_item_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `navigation_menu_item_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` longtext,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`navigation_menu_item_setting_id`),
  UNIQUE KEY `navigation_menu_item_settings_unique` (`navigation_menu_item_id`,`locale`,`setting_name`),
  KEY `navigation_menu_item_settings_navigation_menu_item_id` (`navigation_menu_item_id`),
  CONSTRAINT `navigation_menu_item_settings_navigation_menu_id` FOREIGN KEY (`navigation_menu_item_id`) REFERENCES `navigation_menu_items` (`navigation_menu_item_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb3 COMMENT='More data about navigation menu items, including localized content such as names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menu_item_settings`
--

LOCK TABLES `navigation_menu_item_settings` WRITE;
/*!40000 ALTER TABLE `navigation_menu_item_settings` DISABLE KEYS */;
INSERT INTO `navigation_menu_item_settings` VALUES (1,1,'','titleLocaleKey','navigation.register','string'),(2,2,'','titleLocaleKey','navigation.login','string'),(3,3,'','titleLocaleKey','{$loggedInUsername}','string'),(4,4,'','titleLocaleKey','navigation.dashboard','string'),(5,5,'','titleLocaleKey','common.viewProfile','string'),(6,6,'','titleLocaleKey','navigation.admin','string'),(7,7,'','titleLocaleKey','user.logOut','string'),(8,8,'','titleLocaleKey','navigation.register','string'),(9,9,'','titleLocaleKey','navigation.login','string'),(10,10,'','titleLocaleKey','{$loggedInUsername}','string'),(11,11,'','titleLocaleKey','navigation.dashboard','string'),(12,12,'','titleLocaleKey','common.viewProfile','string'),(13,13,'','titleLocaleKey','navigation.admin','string'),(14,14,'','titleLocaleKey','user.logOut','string'),(15,15,'','titleLocaleKey','navigation.current','string'),(16,16,'','titleLocaleKey','navigation.archives','string'),(17,17,'','titleLocaleKey','manager.announcements','string'),(18,18,'','titleLocaleKey','navigation.about','string'),(19,19,'','titleLocaleKey','about.aboutContext','string'),(20,20,'','titleLocaleKey','about.submissions','string'),(21,21,'','titleLocaleKey','common.editorialMasthead','string'),(22,22,'','titleLocaleKey','manager.setup.privacyStatement','string'),(23,23,'','titleLocaleKey','about.contact','string'),(24,24,'','titleLocaleKey','common.search','string'),(25,18,'en','title','Test Menu 18','string'),(26,18,'en','content','','string'),(27,18,'en','remoteUrl','','string'),(28,25,'en','title','Test Menu 25','string'),(29,25,'en','content','','string'),(30,25,'en','remoteUrl','','string'),(31,26,'en','title','Test Menu 26','string'),(32,26,'en','content','','string'),(33,26,'en','remoteUrl','','string'),(34,27,'en','title','Test Menu 27','string'),(35,27,'en','content','','string'),(36,27,'en','remoteUrl','','string'),(37,19,'en','title','Test Menu 19','string'),(38,19,'en','content','','string'),(39,19,'en','remoteUrl','','string');
/*!40000 ALTER TABLE `navigation_menu_item_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menu_items`
--

DROP TABLE IF EXISTS `navigation_menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menu_items` (
  `navigation_menu_item_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint DEFAULT NULL,
  `path` varchar(255) DEFAULT '',
  `type` varchar(255) DEFAULT '',
  PRIMARY KEY (`navigation_menu_item_id`),
  KEY `navigation_menu_items_context_id` (`context_id`),
  CONSTRAINT `navigation_menu_items_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3 COMMENT='Navigation menu items are single elements within a navigation menu.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menu_items`
--

LOCK TABLES `navigation_menu_items` WRITE;
/*!40000 ALTER TABLE `navigation_menu_items` DISABLE KEYS */;
INSERT INTO `navigation_menu_items` VALUES (1,NULL,NULL,'NMI_TYPE_USER_REGISTER'),(2,NULL,NULL,'NMI_TYPE_USER_LOGIN'),(3,NULL,NULL,'NMI_TYPE_USER_DASHBOARD'),(4,NULL,NULL,'NMI_TYPE_USER_DASHBOARD'),(5,NULL,NULL,'NMI_TYPE_USER_PROFILE'),(6,NULL,NULL,'NMI_TYPE_ADMINISTRATION'),(7,NULL,NULL,'NMI_TYPE_USER_LOGOUT'),(8,1,NULL,'NMI_TYPE_USER_REGISTER'),(9,1,NULL,'NMI_TYPE_USER_LOGIN'),(10,1,NULL,'NMI_TYPE_USER_DASHBOARD'),(11,1,NULL,'NMI_TYPE_USER_DASHBOARD'),(12,1,NULL,'NMI_TYPE_USER_PROFILE'),(13,1,NULL,'NMI_TYPE_ADMINISTRATION'),(14,1,NULL,'NMI_TYPE_USER_LOGOUT'),(15,1,NULL,'NMI_TYPE_CURRENT'),(16,1,NULL,'NMI_TYPE_ARCHIVES'),(17,1,NULL,'NMI_TYPE_ANNOUNCEMENTS'),(18,1,'','NMI_TYPE_PRAGMASUBMISSIONS_GUIDELINES'),(19,1,'','NMI_TYPE_ABOUT'),(20,1,NULL,'NMI_TYPE_SUBMISSIONS'),(21,1,NULL,'NMI_TYPE_MASTHEAD'),(22,1,NULL,'NMI_TYPE_PRIVACY'),(23,1,NULL,'NMI_TYPE_CONTACT'),(24,1,NULL,'NMI_TYPE_SEARCH'),(25,1,'','NMI_TYPE_REMOTE_URL'),(26,1,'special-issue-proposals','NMI_TYPE_CUSTOM'),(27,1,'','NMI_TYPE_POST45_CFPS');
/*!40000 ALTER TABLE `navigation_menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation_menus`
--

DROP TABLE IF EXISTS `navigation_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `navigation_menus` (
  `navigation_menu_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint DEFAULT NULL,
  `area_name` varchar(255) DEFAULT '',
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`navigation_menu_id`),
  KEY `navigation_menus_context_id` (`context_id`),
  CONSTRAINT `navigation_menus_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COMMENT='Navigation menus on the website are installed with the software as a default set, and can be customized.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation_menus`
--

LOCK TABLES `navigation_menus` WRITE;
/*!40000 ALTER TABLE `navigation_menus` DISABLE KEYS */;
INSERT INTO `navigation_menus` VALUES (1,NULL,'user','User Navigation Menu'),(2,1,'user','User Navigation Menu'),(3,1,'primary','Primary Navigation Menu');
/*!40000 ALTER TABLE `navigation_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `note_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `date_created` datetime NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `contents` text,
  PRIMARY KEY (`note_id`),
  KEY `notes_user_id` (`user_id`),
  KEY `notes_assoc` (`assoc_type`,`assoc_id`),
  CONSTRAINT `notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Notes allow users to annotate associated entities, such as submissions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_settings`
--

DROP TABLE IF EXISTS `notification_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_settings` (
  `notification_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `notification_id` bigint NOT NULL,
  `locale` varchar(28) DEFAULT NULL,
  `setting_name` varchar(64) NOT NULL,
  `setting_value` mediumtext NOT NULL,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`notification_setting_id`),
  UNIQUE KEY `notification_settings_unique` (`notification_id`,`locale`,`setting_name`),
  KEY `notification_settings_notification_id` (`notification_id`),
  CONSTRAINT `notification_settings_notification_id_foreign` FOREIGN KEY (`notification_id`) REFERENCES `notifications` (`notification_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about notifications, including localized properties.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_settings`
--

LOCK TABLES `notification_settings` WRITE;
/*!40000 ALTER TABLE `notification_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_subscription_settings`
--

DROP TABLE IF EXISTS `notification_subscription_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_subscription_settings` (
  `setting_id` bigint NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(64) NOT NULL,
  `setting_value` mediumtext NOT NULL,
  `user_id` bigint NOT NULL,
  `context_id` bigint DEFAULT NULL,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`setting_id`),
  KEY `notification_subscription_settings_user_id` (`user_id`),
  KEY `notification_subscription_settings_context` (`context_id`),
  CONSTRAINT `notification_subscription_settings_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `notification_subscription_settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Which email notifications a user has chosen to unsubscribe from.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_subscription_settings`
--

LOCK TABLES `notification_subscription_settings` WRITE;
/*!40000 ALTER TABLE `notification_subscription_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification_subscription_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `notification_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `level` bigint NOT NULL,
  `type` bigint NOT NULL,
  `date_created` datetime NOT NULL,
  `date_read` datetime DEFAULT NULL,
  `assoc_type` bigint DEFAULT NULL,
  `assoc_id` bigint DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `notifications_context_id` (`context_id`),
  KEY `notifications_user_id` (`user_id`),
  KEY `notifications_context_id_user_id` (`context_id`,`user_id`,`level`),
  KEY `notifications_context_id_level` (`context_id`,`level`),
  KEY `notifications_assoc` (`assoc_type`,`assoc_id`),
  KEY `notifications_user_id_level` (`user_id`,`level`),
  CONSTRAINT `notifications_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='User notifications created during certain operations.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oai_resumption_tokens`
--

DROP TABLE IF EXISTS `oai_resumption_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oai_resumption_tokens` (
  `oai_resumption_token_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(32) NOT NULL,
  `expire` bigint NOT NULL,
  `record_offset` int NOT NULL,
  `params` text,
  PRIMARY KEY (`oai_resumption_token_id`),
  UNIQUE KEY `oai_resumption_tokens_unique` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='OAI resumption tokens are used to allow for pagination of large result sets into manageable pieces.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oai_resumption_tokens`
--

LOCK TABLES `oai_resumption_tokens` WRITE;
/*!40000 ALTER TABLE `oai_resumption_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oai_resumption_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugin_settings`
--

DROP TABLE IF EXISTS `plugin_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugin_settings` (
  `plugin_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `plugin_name` varchar(80) NOT NULL,
  `context_id` bigint DEFAULT NULL,
  `setting_name` varchar(80) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`plugin_setting_id`),
  UNIQUE KEY `plugin_settings_unique` (`plugin_name`,`context_id`,`setting_name`),
  KEY `plugin_settings_context_id` (`context_id`),
  KEY `plugin_settings_plugin_name` (`plugin_name`),
  CONSTRAINT `plugin_settings_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3 COMMENT='More data about plugins, including localized properties. This table is frequently used to store plugin-specific configuration.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugin_settings`
--

LOCK TABLES `plugin_settings` WRITE;
/*!40000 ALTER TABLE `plugin_settings` DISABLE KEYS */;
INSERT INTO `plugin_settings` VALUES (1,'defaultthemeplugin',NULL,'enabled','1','bool'),(2,'tinymceplugin',NULL,'enabled','1','bool'),(3,'usageeventplugin',NULL,'enabled','1','bool'),(4,'languagetoggleblockplugin',NULL,'enabled','1','bool'),(5,'languagetoggleblockplugin',NULL,'seq','4','int'),(6,'developedbyblockplugin',NULL,'enabled','0','bool'),(7,'developedbyblockplugin',NULL,'seq','0','int'),(8,'post45themeplugin',1,'enabled','0','bool'),(9,'classicthemeplugin',1,'enabled','1','bool'),(10,'defaultthemeplugin',1,'enabled','1','bool'),(11,'pragmathemeplugin',1,'enabled','1','bool'),(12,'pragmathemeplugin',1,'baseColour','#FFFCF0','string'),(13,'pragmathemeplugin',1,'displayStats','none','string'),(14,'citationstylelanguageplugin',1,'enabled','1','bool'),(15,'mailgunplugin',NULL,'enabled','1','bool'),(16,'pragmasubmissionsthemeplugin',1,'enabled','1','bool'),(17,'submissionsonlyplugin',1,'enabled','0','bool'),(18,'colorpalettesplugin',1,'enabled','1','bool'),(19,'pragmasubmissionsthemeplugin',1,'primaryColour','#D64D1F','string'),(20,'pragmasubmissionsthemeplugin',1,'secondaryColour','#E7AF5B','string'),(21,'pragmasubmissionsthemeplugin',1,'textColour','#333333','string'),(22,'pragmasubmissionsthemeplugin',1,'textAccentColour','#3D2B6C','string'),(23,'pragmasubmissionsthemeplugin',1,'backgroundColour','#FFFCF0','string'),(24,'pragmasubmissionsthemeplugin',1,'backgroundAccentColour','#F6F6F6','string'),(25,'pragmasubmissionsthemeplugin',1,'primarySectionId','1','string'),(26,'tinymceplugin',1,'enabled','1','bool'),(27,'staticpagesplugin',1,'enabled','1','bool'),(28,'post45editorialplugin',1,'enabled','1','bool'),(29,'mailgunplugin',NULL,'archiveBcc','','string'),(31,'post45editorialplugin',1,'primarySectionId','1','int'),(32,'post45editorialplugin',1,'primarySectionIdMigrated','1','int'),(33,'post45cfpplugin',1,'enabled','1','bool'),(34,'post45editorialplugin',1,'showEnsuringLinkForced','1','int'),(35,'post45editorialplugin',1,'announcementsDisabledForced','1','int');
/*!40000 ALTER TABLE `plugin_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post45_cfp_pages`
--

DROP TABLE IF EXISTS `post45_cfp_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post45_cfp_pages` (
  `cfp_page_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `path` varchar(40) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `display_order` int NOT NULL DEFAULT '0',
  `section_id` bigint DEFAULT NULL,
  PRIMARY KEY (`cfp_page_id`),
  UNIQUE KEY `post45_cfp_pages_context_path` (`context_id`,`path`),
  KEY `post45_cfp_pages_section_id` (`section_id`),
  KEY `post45_cfp_pages_active_order` (`is_active`,`display_order`),
  CONSTRAINT `post45_cfp_pages_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `post45_cfp_pages_section_id` FOREIGN KEY (`section_id`) REFERENCES `sections` (`section_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post45_cfp_pages`
--

LOCK TABLES `post45_cfp_pages` WRITE;
/*!40000 ALTER TABLE `post45_cfp_pages` DISABLE KEYS */;
INSERT INTO `post45_cfp_pages` VALUES (1,1,'why45','Why45? A Test CFP','<p>This is a test CFP for the standalone refactor. Please submit essays exploring the periodization question.</p>\r\n<p>Deadline: December 2026.</p>',0,0,4),(2,1,'my-test','Another CFP','<p>This is a test CFP!</p>',1,0,5),(3,1,'YACFP','Yet another CFP','<p>testing 1234</p>',1,0,NULL);
/*!40000 ALTER TABLE `post45_cfp_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_categories`
--

DROP TABLE IF EXISTS `publication_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_categories` (
  `publication_category_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `publication_id` bigint NOT NULL,
  `category_id` bigint NOT NULL,
  PRIMARY KEY (`publication_category_id`),
  UNIQUE KEY `publication_categories_id` (`publication_id`,`category_id`),
  KEY `publication_categories_publication_id` (`publication_id`),
  KEY `publication_categories_category_id` (`category_id`),
  CONSTRAINT `publication_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE,
  CONSTRAINT `publication_categories_publication_id_foreign` FOREIGN KEY (`publication_id`) REFERENCES `publications` (`publication_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Associates publications (and thus submissions) with categories.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_categories`
--

LOCK TABLES `publication_categories` WRITE;
/*!40000 ALTER TABLE `publication_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `publication_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_galley_settings`
--

DROP TABLE IF EXISTS `publication_galley_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_galley_settings` (
  `publication_galley_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `galley_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`publication_galley_setting_id`),
  UNIQUE KEY `publication_galley_settings_unique` (`galley_id`,`locale`,`setting_name`),
  KEY `publication_galley_settings_galley_id` (`galley_id`),
  KEY `publication_galley_settings_name_value` (`setting_name`(50),`setting_value`(150)),
  CONSTRAINT `publication_galley_settings_galley_id` FOREIGN KEY (`galley_id`) REFERENCES `publication_galleys` (`galley_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about publication galleys, including localized content such as labels.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_galley_settings`
--

LOCK TABLES `publication_galley_settings` WRITE;
/*!40000 ALTER TABLE `publication_galley_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `publication_galley_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_galleys`
--

DROP TABLE IF EXISTS `publication_galleys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_galleys` (
  `galley_id` bigint NOT NULL AUTO_INCREMENT,
  `locale` varchar(28) DEFAULT NULL,
  `publication_id` bigint NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `submission_file_id` bigint unsigned DEFAULT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `remote_url` varchar(2047) DEFAULT NULL,
  `is_approved` smallint NOT NULL DEFAULT '0',
  `url_path` varchar(64) DEFAULT NULL,
  `doi_id` bigint DEFAULT NULL,
  PRIMARY KEY (`galley_id`),
  KEY `publication_galleys_publication_id` (`publication_id`),
  KEY `publication_galleys_submission_file_id` (`submission_file_id`),
  KEY `publication_galleys_doi_id` (`doi_id`),
  KEY `publication_galleys_url_path` (`url_path`),
  CONSTRAINT `publication_galleys_doi_id_foreign` FOREIGN KEY (`doi_id`) REFERENCES `dois` (`doi_id`) ON DELETE SET NULL,
  CONSTRAINT `publication_galleys_publication_id` FOREIGN KEY (`publication_id`) REFERENCES `publications` (`publication_id`) ON DELETE CASCADE,
  CONSTRAINT `publication_galleys_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Publication galleys are representations of a publication in a specific format, e.g. a PDF.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_galleys`
--

LOCK TABLES `publication_galleys` WRITE;
/*!40000 ALTER TABLE `publication_galleys` DISABLE KEYS */;
/*!40000 ALTER TABLE `publication_galleys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publication_settings`
--

DROP TABLE IF EXISTS `publication_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publication_settings` (
  `publication_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `publication_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`publication_setting_id`),
  UNIQUE KEY `publication_settings_unique` (`publication_id`,`locale`,`setting_name`),
  KEY `publication_settings_name_value` (`setting_name`(50),`setting_value`(150)),
  KEY `publication_settings_publication_id` (`publication_id`),
  CONSTRAINT `publication_settings_publication_id` FOREIGN KEY (`publication_id`) REFERENCES `publications` (`publication_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb3 COMMENT='More data about publications, including localized properties such as the title and abstract.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publication_settings`
--

LOCK TABLES `publication_settings` WRITE;
/*!40000 ALTER TABLE `publication_settings` DISABLE KEYS */;
INSERT INTO `publication_settings` VALUES (4,3,'en','title','Test Publication 3'),(5,3,'en','abstract','<p>Placeholder abstract for publication 3.</p>'),(6,4,'en','title','Test Publication 4'),(7,4,'en','abstract','<p>Placeholder abstract for publication 4.</p>'),(8,5,'en','title','Test Publication 5'),(9,5,'en','abstract','<p>Placeholder abstract for publication 5.</p>'),(12,7,'en','title','Test Publication 7'),(13,7,'en','abstract','<p>Placeholder abstract for publication 7.</p>'),(14,8,'en','title','Test Publication 8'),(15,8,'en','abstract','<p>Placeholder abstract for publication 8.</p>'),(16,9,'en','title','Test Publication 9'),(23,8,'','publicationUrl','https://example.test/publication/8'),(25,3,'','publicationUrl','https://example.test/publication/3'),(26,4,'','publicationUrl','https://example.test/publication/4'),(38,15,'en','abstract','<p>Placeholder abstract for publication 15.</p>'),(39,15,'en','title','Test Publication 15'),(40,15,'','publicationUrl','https://example.test/publication/15'),(41,16,'en','title','Test Publication 16'),(42,17,'en','title','Test Publication 17'),(43,18,'en','title','Test Publication 18'),(48,25,'en','title','Test Publication 25'),(49,20,'en','title','Test Publication 20'),(50,26,'en','title','Test Publication 26'),(51,27,'en','title','Test Publication 27'),(52,28,'en','title','Test Publication 28'),(53,29,'en','title','Test Publication 29'),(54,30,'en','title','Test Publication 30'),(55,31,'en','title','Test Publication 31'),(56,32,'en','title','Test Publication 32'),(57,32,'en','abstract','<p>Placeholder abstract for publication 32.</p>'),(58,33,'en','title','Test Publication 33'),(59,33,'en','abstract','<p>Placeholder abstract for publication 33.</p>');
/*!40000 ALTER TABLE `publication_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publications`
--

DROP TABLE IF EXISTS `publications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publications` (
  `publication_id` bigint NOT NULL AUTO_INCREMENT,
  `access_status` bigint DEFAULT '0',
  `date_published` date DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `primary_contact_id` bigint DEFAULT NULL,
  `section_id` bigint DEFAULT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `submission_id` bigint NOT NULL,
  `status` smallint NOT NULL DEFAULT '1',
  `url_path` varchar(64) DEFAULT NULL,
  `version` bigint DEFAULT NULL,
  `doi_id` bigint DEFAULT NULL,
  `issue_id` bigint DEFAULT NULL,
  PRIMARY KEY (`publication_id`),
  KEY `publications_primary_contact_id` (`primary_contact_id`),
  KEY `publications_section_id` (`section_id`),
  KEY `publications_submission_id` (`submission_id`),
  KEY `publications_doi_id` (`doi_id`),
  KEY `publications_issue_id_index` (`issue_id`),
  KEY `publications_url_path` (`url_path`),
  CONSTRAINT `publications_doi_id_foreign` FOREIGN KEY (`doi_id`) REFERENCES `dois` (`doi_id`) ON DELETE SET NULL,
  CONSTRAINT `publications_issue_id_foreign` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE SET NULL,
  CONSTRAINT `publications_primary_contact_id` FOREIGN KEY (`primary_contact_id`) REFERENCES `authors` (`author_id`) ON DELETE SET NULL,
  CONSTRAINT `publications_section_id` FOREIGN KEY (`section_id`) REFERENCES `sections` (`section_id`) ON DELETE SET NULL,
  CONSTRAINT `publications_submission_id` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3 COMMENT='Each publication is one version of a submission.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publications`
--

LOCK TABLES `publications` WRITE;
/*!40000 ALTER TABLE `publications` DISABLE KEYS */;
INSERT INTO `publications` VALUES (3,0,'2026-07-06','2026-07-06 19:53:42',1,1,0,3,3,NULL,1,NULL,NULL),(4,0,'2026-07-08','2026-07-08 21:27:49',2,1,0,4,3,NULL,1,NULL,NULL),(5,0,NULL,'2025-12-19 18:58:36',3,1,0,5,1,NULL,1,NULL,NULL),(7,0,NULL,'2025-12-20 06:36:22',5,1,0,7,1,NULL,1,NULL,NULL),(8,0,'2026-07-06','2026-07-06 15:53:38',6,1,0,8,3,NULL,1,NULL,NULL),(9,0,NULL,'2026-07-09 17:33:23',NULL,1,0,9,1,NULL,1,NULL,NULL),(15,0,'2026-07-08','2026-07-09 17:34:35',11,1,0,15,3,NULL,1,NULL,NULL),(16,0,NULL,'2026-07-08 22:20:33',NULL,1,0,16,1,NULL,1,NULL,NULL),(17,0,NULL,'2026-07-15 16:44:26',NULL,1,0,17,1,NULL,1,NULL,NULL),(18,0,NULL,'2026-07-23 19:58:47',13,1,0,18,1,NULL,1,NULL,NULL),(20,0,NULL,'2026-07-23 23:35:03',15,1,0,20,1,NULL,1,NULL,NULL),(25,0,NULL,'2026-07-25 19:02:48',20,1,0,25,1,NULL,1,NULL,NULL),(26,0,NULL,'2026-07-23 23:39:16',21,1,0,26,1,NULL,1,NULL,NULL),(27,0,NULL,'2026-07-23 23:56:15',22,1,0,27,1,NULL,1,NULL,NULL),(28,0,NULL,'2026-07-24 00:01:45',23,1,0,28,1,NULL,1,NULL,NULL),(29,0,NULL,'2026-07-24 17:57:30',NULL,1,0,29,1,NULL,1,NULL,NULL),(30,0,NULL,'2026-07-24 19:41:08',24,1,0,30,1,NULL,1,NULL,NULL),(31,0,NULL,'2026-07-24 19:42:29',25,1,0,31,1,NULL,1,NULL,NULL),(32,0,NULL,'2026-07-24 19:50:42',26,1,0,32,1,NULL,1,NULL,NULL),(33,0,NULL,'2026-07-24 20:03:18',27,1,0,33,1,NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `publications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queries`
--

DROP TABLE IF EXISTS `queries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queries` (
  `query_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  `stage_id` smallint NOT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `date_posted` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `closed` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`query_id`),
  KEY `queries_assoc_id` (`assoc_type`,`assoc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb3 COMMENT='Discussions, usually related to a submission, created by editors, authors and other editorial staff.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queries`
--

LOCK TABLES `queries` WRITE;
/*!40000 ALTER TABLE `queries` DISABLE KEYS */;
INSERT INTO `queries` VALUES (1,1048585,3,1,0,'2025-11-21 17:49:25','2025-11-23 18:04:08',0),(3,1048585,4,1,0,'2025-12-19 18:56:33','2026-07-08 20:19:43',0),(4,1048585,5,1,1,'2025-12-19 18:59:25','2025-12-19 18:59:25',0),(5,1048585,7,1,0,'2025-12-20 06:37:18','2025-12-20 06:47:30',0),(6,1048585,8,1,0,'2025-12-20 06:40:31','2025-12-20 06:46:51',0),(7,1048585,8,1,1,'2025-12-20 06:46:51','2025-12-20 06:46:51',0),(8,1048585,7,1,1,'2025-12-20 06:47:30','2025-12-20 06:47:30',0),(16,1048585,9,1,0,'2026-07-08 22:14:51','2026-07-08 22:35:28',1),(23,1048585,9,3,1,'2026-07-13 16:51:28','2026-07-13 16:51:28',0),(25,1048585,9,3,2,'2026-07-13 17:15:22','2026-07-13 17:15:22',0),(32,1048585,9,3,3,'2026-07-13 17:34:01','2026-07-13 17:34:01',0),(44,1048585,18,1,1,'2026-07-23 19:59:56','2026-07-23 19:59:56',0),(45,1048585,25,1,1,'2026-07-23 23:27:28','2026-07-23 23:27:28',0),(46,1048585,26,1,1,'2026-07-23 23:39:41','2026-07-23 23:39:41',0),(47,1048585,27,1,1,'2026-07-23 23:56:57','2026-07-23 23:56:57',0),(48,1048585,28,1,1,'2026-07-24 00:02:41','2026-07-24 00:02:41',0),(49,1048585,31,1,1,'2026-07-24 19:42:52','2026-07-24 19:42:52',0),(51,1048585,32,3,0,'2026-07-24 19:51:37','2026-07-24 19:53:07',1),(53,1048585,33,1,1,'2026-07-24 20:03:43','2026-07-24 20:03:43',0);
/*!40000 ALTER TABLE `queries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `query_participants`
--

DROP TABLE IF EXISTS `query_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `query_participants` (
  `query_participant_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `query_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`query_participant_id`),
  UNIQUE KEY `query_participants_unique` (`query_id`,`user_id`),
  KEY `query_participants_query_id` (`query_id`),
  KEY `query_participants_user_id` (`user_id`),
  CONSTRAINT `query_participants_query_id_foreign` FOREIGN KEY (`query_id`) REFERENCES `queries` (`query_id`) ON DELETE CASCADE,
  CONSTRAINT `query_participants_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb3 COMMENT='The users assigned to a discussion.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `query_participants`
--

LOCK TABLES `query_participants` WRITE;
/*!40000 ALTER TABLE `query_participants` DISABLE KEYS */;
INSERT INTO `query_participants` VALUES (2,1,1),(3,1,2),(1,1,16),(5,3,22),(6,4,22),(7,5,24),(8,6,24),(9,7,13),(10,8,13),(21,16,1),(22,16,2),(29,23,1),(32,25,1),(33,25,3),(40,32,1),(53,44,1),(52,44,35),(55,45,1),(54,45,6),(57,46,1),(56,46,7),(59,47,1),(58,47,7),(61,48,1),(60,48,7),(63,49,1),(62,49,7),(66,51,1),(67,51,7),(70,53,1),(69,53,18);
/*!40000 ALTER TABLE `query_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queued_payments`
--

DROP TABLE IF EXISTS `queued_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queued_payments` (
  `queued_payment_id` bigint NOT NULL AUTO_INCREMENT,
  `date_created` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `payment_data` text,
  PRIMARY KEY (`queued_payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Unfulfilled (queued) payments, i.e. payments that have not yet been completed via an online payment system.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queued_payments`
--

LOCK TABLES `queued_payments` WRITE;
/*!40000 ALTER TABLE `queued_payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `queued_payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_assignment_settings`
--

DROP TABLE IF EXISTS `review_assignment_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_assignment_settings` (
  `review_assignment_settings_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary key.',
  `review_id` bigint NOT NULL COMMENT 'Foreign key referencing record in review_assignments table',
  `locale` varchar(28) DEFAULT NULL COMMENT 'Locale key.',
  `setting_name` varchar(255) NOT NULL COMMENT 'Name of settings record.',
  `setting_value` mediumtext COMMENT 'Settings value.',
  PRIMARY KEY (`review_assignment_settings_id`),
  UNIQUE KEY `review_assignment_settings_unique` (`review_id`,`locale`,`setting_name`),
  KEY `review_assignment_settings_review_id` (`review_id`),
  CONSTRAINT `review_assignment_settings_review_id_foreign` FOREIGN KEY (`review_id`) REFERENCES `review_assignments` (`review_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_assignment_settings`
--

LOCK TABLES `review_assignment_settings` WRITE;
/*!40000 ALTER TABLE `review_assignment_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_assignment_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_assignments`
--

DROP TABLE IF EXISTS `review_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_assignments` (
  `review_id` bigint NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `reviewer_id` bigint NOT NULL,
  `competing_interests` text,
  `recommendation` smallint DEFAULT NULL,
  `date_assigned` datetime DEFAULT NULL,
  `date_notified` datetime DEFAULT NULL,
  `date_confirmed` datetime DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  `date_considered` datetime DEFAULT NULL,
  `date_acknowledged` datetime DEFAULT NULL,
  `date_due` datetime DEFAULT NULL,
  `date_response_due` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `reminder_was_automatic` smallint NOT NULL DEFAULT '0',
  `declined` smallint NOT NULL DEFAULT '0',
  `cancelled` smallint NOT NULL DEFAULT '0',
  `date_cancelled` datetime DEFAULT NULL,
  `date_rated` datetime DEFAULT NULL,
  `date_reminded` datetime DEFAULT NULL,
  `quality` smallint DEFAULT NULL,
  `review_round_id` bigint NOT NULL,
  `stage_id` smallint NOT NULL,
  `review_method` smallint NOT NULL DEFAULT '1',
  `round` smallint NOT NULL DEFAULT '1',
  `step` smallint NOT NULL DEFAULT '1',
  `review_form_id` bigint DEFAULT NULL,
  `considered` smallint DEFAULT NULL,
  `request_resent` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`review_id`),
  KEY `review_assignments_submission_id` (`submission_id`),
  KEY `review_assignments_reviewer_id` (`reviewer_id`),
  KEY `review_assignment_reviewer_round` (`review_round_id`,`reviewer_id`),
  KEY `review_assignments_form_id` (`review_form_id`),
  KEY `review_assignments_reviewer_review` (`reviewer_id`,`review_id`),
  CONSTRAINT `review_assignments_review_form_id_foreign` FOREIGN KEY (`review_form_id`) REFERENCES `review_forms` (`review_form_id`),
  CONSTRAINT `review_assignments_review_round_id_foreign` FOREIGN KEY (`review_round_id`) REFERENCES `review_rounds` (`review_round_id`),
  CONSTRAINT `review_assignments_reviewer_id_foreign` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `review_assignments_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 COMMENT='Data about peer review assignments for all submissions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_assignments`
--

LOCK TABLES `review_assignments` WRITE;
/*!40000 ALTER TABLE `review_assignments` DISABLE KEYS */;
INSERT INTO `review_assignments` VALUES (1,3,17,NULL,3,'2025-11-21 18:15:13','2025-11-21 18:15:14','2025-11-23 18:04:59','2025-11-23 18:12:50','2025-11-23 18:14:59','2025-11-23 19:15:34','2026-01-16 00:00:00','2025-12-05 00:00:00','2025-11-23 19:15:34',0,0,0,NULL,NULL,NULL,NULL,1,3,2,1,4,NULL,3,0),(3,3,20,NULL,2,'2025-11-23 17:19:07','2025-11-23 17:19:08','2025-11-23 17:21:44','2025-11-23 18:03:11','2025-11-23 18:15:06','2025-11-23 19:15:34','2026-01-18 00:00:00','2025-12-07 00:00:00','2025-11-23 19:15:34',0,0,0,NULL,NULL,NULL,NULL,1,3,2,1,4,NULL,3,0),(4,4,23,NULL,1,'2025-12-20 01:00:31','2025-12-20 01:00:31','2025-12-20 01:03:58','2025-12-20 01:04:43','2025-12-20 01:06:50','2025-12-20 01:07:41','2026-02-14 00:00:00','2026-01-03 00:00:00','2025-12-20 01:07:41',0,0,0,NULL,'2025-12-20 01:06:50',NULL,5,2,3,2,1,4,NULL,3,0),(5,8,25,NULL,NULL,'2025-12-20 06:56:29','2025-12-20 06:56:29','2025-12-20 07:30:05','2025-12-20 07:30:05','2025-12-20 07:30:05','2025-12-20 07:30:40','2026-02-14 00:00:00','2026-01-03 00:00:00','2025-12-20 07:30:40',0,0,0,NULL,NULL,NULL,NULL,3,3,2,1,1,NULL,3,0),(6,8,26,NULL,1,'2025-12-20 07:36:28','2025-12-20 07:36:28','2025-12-20 07:37:36','2025-12-20 07:37:52','2025-12-20 07:39:20','2025-12-20 07:39:20','2026-02-14 00:00:00','2026-01-03 00:00:00','2025-12-20 07:39:20',0,0,0,NULL,NULL,NULL,NULL,5,3,2,2,4,NULL,3,0),(7,9,17,NULL,NULL,'2026-07-11 16:48:25','2026-07-11 16:48:25','2026-07-11 16:49:58',NULL,NULL,NULL,'2026-09-05 00:00:00','2026-07-25 00:00:00','2026-07-11 16:52:44',0,0,0,NULL,NULL,NULL,NULL,8,3,2,1,3,NULL,4,0),(8,25,23,NULL,NULL,'2026-07-24 17:54:51','2026-07-24 17:54:51','2026-07-24 17:55:32',NULL,NULL,NULL,'2026-09-18 00:00:00','2026-08-07 00:00:00','2026-07-24 17:55:34',0,0,0,NULL,NULL,NULL,NULL,11,3,2,1,3,NULL,0,0),(9,31,3,NULL,NULL,'2026-07-24 19:45:07','2026-07-24 19:45:07',NULL,NULL,NULL,NULL,'2026-09-18 00:00:00','2026-08-07 00:00:00','2026-07-24 19:45:07',0,0,0,NULL,NULL,NULL,NULL,12,3,2,1,1,NULL,0,0),(10,32,17,NULL,NULL,'2026-07-24 19:49:15','2026-07-24 19:49:15',NULL,NULL,NULL,NULL,'2026-09-18 00:00:00','2026-08-07 00:00:00','2026-07-24 19:49:42',0,0,0,NULL,NULL,NULL,NULL,13,3,2,1,1,NULL,4,0),(11,33,17,NULL,NULL,'2026-07-24 20:17:42','2026-07-24 20:17:42',NULL,NULL,NULL,NULL,'2026-09-18 00:00:00','2026-08-07 00:00:00','2026-07-24 20:17:42',0,0,0,NULL,NULL,NULL,NULL,14,3,2,1,1,NULL,0,0);
/*!40000 ALTER TABLE `review_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_files`
--

DROP TABLE IF EXISTS `review_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_files` (
  `review_file_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `review_id` bigint NOT NULL,
  `submission_file_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`review_file_id`),
  UNIQUE KEY `review_files_unique` (`review_id`,`submission_file_id`),
  KEY `review_files_review_id` (`review_id`),
  KEY `review_files_submission_file_id` (`submission_file_id`),
  CONSTRAINT `review_files_review_id_foreign` FOREIGN KEY (`review_id`) REFERENCES `review_assignments` (`review_id`) ON DELETE CASCADE,
  CONSTRAINT `review_files_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COMMENT='A list of the submission files made available to each assigned reviewer.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_files`
--

LOCK TABLES `review_files` WRITE;
/*!40000 ALTER TABLE `review_files` DISABLE KEYS */;
INSERT INTO `review_files` VALUES (2,1,4),(1,1,5),(6,3,4),(5,3,5),(7,4,8),(8,5,12),(9,7,17),(10,8,24),(11,9,31),(12,10,33),(13,11,35);
/*!40000 ALTER TABLE `review_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_form_element_settings`
--

DROP TABLE IF EXISTS `review_form_element_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_form_element_settings` (
  `review_form_element_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `review_form_element_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`review_form_element_setting_id`),
  UNIQUE KEY `review_form_element_settings_unique` (`review_form_element_id`,`locale`,`setting_name`),
  KEY `review_form_element_settings_review_form_element_id` (`review_form_element_id`),
  CONSTRAINT `review_form_element_settings_review_form_element_id` FOREIGN KEY (`review_form_element_id`) REFERENCES `review_form_elements` (`review_form_element_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about review form elements, including localized content such as question text.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_form_element_settings`
--

LOCK TABLES `review_form_element_settings` WRITE;
/*!40000 ALTER TABLE `review_form_element_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_form_element_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_form_elements`
--

DROP TABLE IF EXISTS `review_form_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_form_elements` (
  `review_form_element_id` bigint NOT NULL AUTO_INCREMENT,
  `review_form_id` bigint NOT NULL,
  `seq` double DEFAULT NULL,
  `element_type` bigint DEFAULT NULL,
  `required` smallint DEFAULT NULL,
  `included` smallint DEFAULT NULL,
  PRIMARY KEY (`review_form_element_id`),
  KEY `review_form_elements_review_form_id` (`review_form_id`),
  CONSTRAINT `review_form_elements_review_form_id` FOREIGN KEY (`review_form_id`) REFERENCES `review_forms` (`review_form_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Each review form element represents a single question on a review form.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_form_elements`
--

LOCK TABLES `review_form_elements` WRITE;
/*!40000 ALTER TABLE `review_form_elements` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_form_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_form_responses`
--

DROP TABLE IF EXISTS `review_form_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_form_responses` (
  `review_form_response_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `review_form_element_id` bigint NOT NULL,
  `review_id` bigint NOT NULL,
  `response_type` varchar(6) DEFAULT NULL,
  `response_value` text,
  PRIMARY KEY (`review_form_response_id`),
  KEY `review_form_responses_review_form_element_id` (`review_form_element_id`),
  KEY `review_form_responses_review_id` (`review_id`),
  KEY `review_form_responses_unique` (`review_form_element_id`,`review_id`),
  CONSTRAINT `review_form_responses_review_form_element_id_foreign` FOREIGN KEY (`review_form_element_id`) REFERENCES `review_form_elements` (`review_form_element_id`) ON DELETE CASCADE,
  CONSTRAINT `review_form_responses_review_id_foreign` FOREIGN KEY (`review_id`) REFERENCES `review_assignments` (`review_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Each review form response records a reviewer''s answer to a review form element associated with a peer review.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_form_responses`
--

LOCK TABLES `review_form_responses` WRITE;
/*!40000 ALTER TABLE `review_form_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_form_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_form_settings`
--

DROP TABLE IF EXISTS `review_form_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_form_settings` (
  `review_form_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `review_form_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`review_form_setting_id`),
  UNIQUE KEY `review_form_settings_unique` (`review_form_id`,`locale`,`setting_name`),
  KEY `review_form_settings_review_form_id` (`review_form_id`),
  CONSTRAINT `review_form_settings_review_form_id` FOREIGN KEY (`review_form_id`) REFERENCES `review_forms` (`review_form_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about review forms, including localized content such as names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_form_settings`
--

LOCK TABLES `review_form_settings` WRITE;
/*!40000 ALTER TABLE `review_form_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_form_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_forms`
--

DROP TABLE IF EXISTS `review_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_forms` (
  `review_form_id` bigint NOT NULL AUTO_INCREMENT,
  `assoc_type` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  `seq` double DEFAULT NULL,
  `is_active` smallint DEFAULT NULL,
  PRIMARY KEY (`review_form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Review forms provide custom templates for peer reviews with several types of questions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_forms`
--

LOCK TABLES `review_forms` WRITE;
/*!40000 ALTER TABLE `review_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_round_files`
--

DROP TABLE IF EXISTS `review_round_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_round_files` (
  `review_round_file_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `review_round_id` bigint NOT NULL,
  `stage_id` smallint NOT NULL,
  `submission_file_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`review_round_file_id`),
  UNIQUE KEY `review_round_files_unique` (`submission_id`,`review_round_id`,`submission_file_id`),
  KEY `review_round_files_submission_id` (`submission_id`),
  KEY `review_round_files_review_round_id` (`review_round_id`),
  KEY `review_round_files_submission_file_id` (`submission_file_id`),
  CONSTRAINT `review_round_files_review_round_id_foreign` FOREIGN KEY (`review_round_id`) REFERENCES `review_rounds` (`review_round_id`) ON DELETE CASCADE,
  CONSTRAINT `review_round_files_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE,
  CONSTRAINT `review_round_files_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COMMENT='Records the files made available to reviewers for a round of reviews. These can be further customized on a per review basis with review_files.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_round_files`
--

LOCK TABLES `review_round_files` WRITE;
/*!40000 ALTER TABLE `review_round_files` DISABLE KEYS */;
INSERT INTO `review_round_files` VALUES (1,3,1,3,4),(2,3,1,3,5),(3,4,2,3,8),(4,8,3,3,12),(5,7,4,3,13),(8,9,8,3,17),(10,16,10,3,21),(11,25,11,3,24),(12,31,12,3,31),(13,32,13,3,33),(14,33,14,3,35);
/*!40000 ALTER TABLE `review_round_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_rounds`
--

DROP TABLE IF EXISTS `review_rounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_rounds` (
  `review_round_id` bigint NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `stage_id` bigint DEFAULT NULL,
  `round` smallint NOT NULL,
  `review_revision` bigint DEFAULT NULL,
  `status` bigint DEFAULT NULL,
  PRIMARY KEY (`review_round_id`),
  UNIQUE KEY `review_rounds_submission_id_stage_id_round_pkey` (`submission_id`,`stage_id`,`round`),
  KEY `review_rounds_submission_id` (`submission_id`),
  CONSTRAINT `review_rounds_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COMMENT='Peer review assignments are organized into multiple rounds on a submission.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_rounds`
--

LOCK TABLES `review_rounds` WRITE;
/*!40000 ALTER TABLE `review_rounds` DISABLE KEYS */;
INSERT INTO `review_rounds` VALUES (1,3,3,1,NULL,4),(2,4,3,1,NULL,4),(3,8,3,1,NULL,6),(4,7,3,1,NULL,5),(5,8,3,2,NULL,4),(8,9,3,1,NULL,1),(10,16,3,1,NULL,6),(11,25,3,1,NULL,7),(12,31,3,1,NULL,7),(13,32,3,1,NULL,7),(14,33,3,1,NULL,4);
/*!40000 ALTER TABLE `review_rounds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviewer_suggestion_settings`
--

DROP TABLE IF EXISTS `reviewer_suggestion_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviewer_suggestion_settings` (
  `reviewer_suggestion_id` bigint NOT NULL COMMENT 'The foreign key mapping of this setting to reviewer_suggestions table',
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  UNIQUE KEY `reviewer_suggestion_settings_unique` (`reviewer_suggestion_id`,`locale`,`setting_name`),
  KEY `reviewer_suggestion_settings_reviewer_suggestion_id` (`reviewer_suggestion_id`),
  KEY `reviewer_suggestion_settings_locale_setting_name_index` (`setting_name`,`locale`),
  CONSTRAINT `reviewer_suggestion_settings_reviewer_suggestion_id_foreign` FOREIGN KEY (`reviewer_suggestion_id`) REFERENCES `reviewer_suggestions` (`reviewer_suggestion_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Reviewer suggestion settings table to contain multilingual or extra information';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviewer_suggestion_settings`
--

LOCK TABLES `reviewer_suggestion_settings` WRITE;
/*!40000 ALTER TABLE `reviewer_suggestion_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviewer_suggestion_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviewer_suggestions`
--

DROP TABLE IF EXISTS `reviewer_suggestions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviewer_suggestions` (
  `reviewer_suggestion_id` bigint NOT NULL AUTO_INCREMENT,
  `suggesting_user_id` bigint DEFAULT NULL COMMENT 'The user/author who has made the suggestion',
  `submission_id` bigint NOT NULL COMMENT 'Submission at which the suggestion was made',
  `email` varchar(255) NOT NULL COMMENT 'Suggested reviewer email address',
  `orcid_id` varchar(255) DEFAULT NULL COMMENT 'Suggested reviewer optional Orcid Id',
  `approved_at` timestamp NULL DEFAULT NULL COMMENT 'If and when the suggestion approved to add/invite suggested_reviewer',
  `approver_id` bigint DEFAULT NULL COMMENT 'The user who has approved the suggestion',
  `reviewer_id` bigint DEFAULT NULL COMMENT 'The reviewer who has been added/invited through this suggestion',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`reviewer_suggestion_id`),
  KEY `reviewer_suggestions_suggesting_user_id` (`suggesting_user_id`),
  KEY `reviewer_suggestions_submission_id` (`submission_id`),
  KEY `reviewer_suggestions_approver_id_foreign` (`approver_id`),
  KEY `reviewer_suggestions_reviewer_id_foreign` (`reviewer_id`),
  CONSTRAINT `reviewer_suggestions_approver_id_foreign` FOREIGN KEY (`approver_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `reviewer_suggestions_reviewer_id_foreign` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `reviewer_suggestions_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE,
  CONSTRAINT `reviewer_suggestions_suggesting_user_id_foreign` FOREIGN KEY (`suggesting_user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Author suggested reviewers at the submission time';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviewer_suggestions`
--

LOCK TABLES `reviewer_suggestions` WRITE;
/*!40000 ALTER TABLE `reviewer_suggestions` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviewer_suggestions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `section_settings`
--

DROP TABLE IF EXISTS `section_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `section_settings` (
  `section_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `section_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`section_setting_id`),
  UNIQUE KEY `section_settings_unique` (`section_id`,`locale`,`setting_name`),
  KEY `section_settings_section_id` (`section_id`),
  CONSTRAINT `section_settings_section_id` FOREIGN KEY (`section_id`) REFERENCES `sections` (`section_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3 COMMENT='More data about sections, including localized properties like section titles.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `section_settings`
--

LOCK TABLES `section_settings` WRITE;
/*!40000 ALTER TABLE `section_settings` DISABLE KEYS */;
INSERT INTO `section_settings` VALUES (1,1,'en','title','Test Section 1'),(2,1,'en','abbrev','S1'),(3,1,'en','identifyType',''),(4,1,'en','policy',''),(13,4,'en','title','Test Section 4'),(14,4,'en','abbrev','S4'),(15,4,'en','identifyType',''),(16,4,'en','policy',''),(17,5,'en','title','Test Section 5'),(18,5,'en','abbrev','S5'),(19,5,'en','identifyType',''),(20,5,'en','policy','');
/*!40000 ALTER TABLE `section_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `section_id` bigint NOT NULL AUTO_INCREMENT,
  `journal_id` bigint NOT NULL,
  `review_form_id` bigint DEFAULT NULL,
  `seq` double NOT NULL DEFAULT '0',
  `editor_restricted` smallint NOT NULL DEFAULT '0',
  `meta_indexed` smallint NOT NULL DEFAULT '0',
  `meta_reviewed` smallint NOT NULL DEFAULT '1',
  `abstracts_not_required` smallint NOT NULL DEFAULT '0',
  `hide_title` smallint NOT NULL DEFAULT '0',
  `hide_author` smallint NOT NULL DEFAULT '0',
  `is_inactive` smallint NOT NULL DEFAULT '0',
  `abstract_word_count` bigint DEFAULT NULL,
  PRIMARY KEY (`section_id`),
  KEY `sections_journal_id` (`journal_id`),
  KEY `sections_review_form_id` (`review_form_id`),
  CONSTRAINT `sections_journal_id` FOREIGN KEY (`journal_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `sections_review_form_id` FOREIGN KEY (`review_form_id`) REFERENCES `review_forms` (`review_form_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COMMENT='A list of all sections into which submissions can be organized, forming the table of contents.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,1,NULL,0,0,1,1,1,0,0,0,0),(4,1,NULL,1,0,1,1,1,0,0,0,0),(5,1,NULL,2,0,1,1,0,0,0,0,0);
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `last_activity` int NOT NULL,
  `payload` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`),
  CONSTRAINT `sessions_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Session data for logged-in users.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site`
--

DROP TABLE IF EXISTS `site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site` (
  `site_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `redirect_context_id` bigint DEFAULT NULL COMMENT 'If not null, redirect to the specified journal/conference/... site.',
  `primary_locale` varchar(28) NOT NULL COMMENT 'Primary locale for the site.',
  `min_password_length` smallint NOT NULL DEFAULT '6',
  `installed_locales` varchar(1024) NOT NULL DEFAULT 'en' COMMENT 'Locales for which support has been installed.',
  `supported_locales` varchar(1024) DEFAULT NULL COMMENT 'Locales supported by the site (for hosted journals/conferences/...).',
  `original_style_file_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`site_id`),
  KEY `site_context_id` (`redirect_context_id`),
  CONSTRAINT `site_redirect_context_id_foreign` FOREIGN KEY (`redirect_context_id`) REFERENCES `journals` (`journal_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COMMENT='A singleton table describing basic information about the site.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site`
--

LOCK TABLES `site` WRITE;
/*!40000 ALTER TABLE `site` DISABLE KEYS */;
INSERT INTO `site` VALUES (1,NULL,'en',6,'[\"en\"]','[\"en\"]',NULL);
/*!40000 ALTER TABLE `site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_settings` (
  `site_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `setting_name` varchar(255) NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_value` mediumtext,
  PRIMARY KEY (`site_setting_id`),
  UNIQUE KEY `site_settings_unique` (`setting_name`,`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3 COMMENT='More data about the site, including localized properties such as its name.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_settings`
--

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES (1,'contactEmail','en','contact@example.test'),(2,'contactName','en','Test Contact'),(3,'compressStatsLogs','','1'),(4,'enableGeoUsageStats','','disabled'),(5,'enableInstitutionUsageStats','','0'),(6,'keepDailyUsageStats','','0'),(7,'isSiteSushiPlatform','','0'),(8,'isSushiApiPublic','','0'),(9,'disableSharedReviewerStatistics','','0'),(10,'orcidClientId','',''),(11,'orcidClientSecret','',''),(12,'orcidEnabled','','0'),(13,'themePluginPath','','default'),(14,'uniqueSiteId','','E0A8B1A8-8B8A-4494-BA6D-F7DC6DE77FAD');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stage_assignments`
--

DROP TABLE IF EXISTS `stage_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stage_assignments` (
  `stage_assignment_id` bigint NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `user_group_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `date_assigned` datetime NOT NULL,
  `recommend_only` smallint NOT NULL DEFAULT '0',
  `can_change_metadata` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`stage_assignment_id`),
  UNIQUE KEY `stage_assignment` (`submission_id`,`user_group_id`,`user_id`),
  KEY `stage_assignments_user_group_id` (`user_group_id`),
  KEY `stage_assignments_user_id` (`user_id`),
  KEY `stage_assignments_submission_id` (`submission_id`),
  CONSTRAINT `stage_assignments_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE,
  CONSTRAINT `stage_assignments_user_group_id` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`user_group_id`) ON DELETE CASCADE,
  CONSTRAINT `stage_assignments_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb3 COMMENT='Who can access a submission while it is in the editorial workflow. Includes all editorial and author assignments. For reviewers, see review_assignments.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stage_assignments`
--

LOCK TABLES `stage_assignments` WRITE;
/*!40000 ALTER TABLE `stage_assignments` DISABLE KEYS */;
INSERT INTO `stage_assignments` VALUES (3,3,14,16,'2025-11-21 17:47:34',0,0),(6,3,20,1,'2025-11-21 18:01:08',0,1),(7,4,14,22,'2025-12-19 18:52:15',0,0),(8,5,14,22,'2025-12-19 18:57:49',0,0),(9,5,3,12,'2025-12-19 19:05:15',0,1),(10,4,3,12,'2025-12-19 19:06:05',0,1),(12,7,14,24,'2025-12-20 06:35:56',0,0),(13,8,14,24,'2025-12-20 06:37:47',0,0),(14,8,20,13,'2025-12-20 06:46:51',0,1),(15,7,20,13,'2025-12-20 06:47:30',0,1),(16,9,20,1,'2026-01-02 18:22:23',0,1),(17,15,14,22,'2026-07-08 22:05:08',0,0),(18,9,21,2,'2026-07-08 22:14:40',0,1),(19,16,20,1,'2026-07-08 22:20:33',0,1),(20,9,14,3,'2026-07-09 17:55:23',0,0),(21,17,20,1,'2026-07-15 16:44:26',0,1),(22,18,14,35,'2026-07-23 19:58:47',0,0),(23,18,20,1,'2026-07-23 19:59:56',0,1),(25,20,14,6,'2026-07-23 23:05:08',0,0),(30,25,14,6,'2026-07-23 23:14:21',0,0),(31,25,20,1,'2026-07-23 23:27:28',0,1),(32,20,20,1,'2026-07-23 23:35:24',0,1),(33,26,14,7,'2026-07-23 23:39:15',0,0),(34,26,20,1,'2026-07-23 23:39:40',0,1),(35,27,14,7,'2026-07-23 23:56:15',0,0),(36,27,20,1,'2026-07-23 23:56:57',0,1),(37,28,14,7,'2026-07-24 00:01:44',0,0),(38,28,20,1,'2026-07-24 00:02:41',0,1),(39,29,20,1,'2026-07-24 17:57:30',0,1),(40,30,14,7,'2026-07-24 19:12:14',0,0),(41,30,20,1,'2026-07-24 19:41:26',0,1),(42,31,14,7,'2026-07-24 19:42:21',0,0),(43,31,20,1,'2026-07-24 19:42:51',0,1),(44,32,14,7,'2026-07-24 19:47:30',0,0),(45,32,20,1,'2026-07-24 19:48:07',0,1),(46,33,14,18,'2026-07-24 20:03:06',0,0),(47,33,20,1,'2026-07-24 20:03:43',0,1);
/*!40000 ALTER TABLE `stage_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `static_page_settings`
--

DROP TABLE IF EXISTS `static_page_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `static_page_settings` (
  `static_page_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `static_page_id` bigint NOT NULL,
  `locale` varchar(14) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` longtext,
  `setting_type` varchar(6) NOT NULL COMMENT '(bool|int|float|string|object)',
  PRIMARY KEY (`static_page_setting_id`),
  UNIQUE KEY `static_page_settings_unique` (`static_page_id`,`locale`,`setting_name`),
  KEY `static_page_settings_static_page_id` (`static_page_id`),
  CONSTRAINT `static_page_settings_static_page_id` FOREIGN KEY (`static_page_id`) REFERENCES `static_pages` (`static_page_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `static_page_settings`
--

LOCK TABLES `static_page_settings` WRITE;
/*!40000 ALTER TABLE `static_page_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `static_page_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `static_pages`
--

DROP TABLE IF EXISTS `static_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `static_pages` (
  `static_page_id` bigint NOT NULL AUTO_INCREMENT,
  `path` varchar(255) NOT NULL,
  `context_id` bigint NOT NULL,
  PRIMARY KEY (`static_page_id`),
  KEY `static_pages_context_id` (`context_id`),
  CONSTRAINT `static_pages_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `static_pages`
--

LOCK TABLES `static_pages` WRITE;
/*!40000 ALTER TABLE `static_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `static_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subeditor_submission_group`
--

DROP TABLE IF EXISTS `subeditor_submission_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subeditor_submission_group` (
  `subeditor_submission_group_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  `assoc_type` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `user_group_id` bigint NOT NULL,
  PRIMARY KEY (`subeditor_submission_group_id`),
  UNIQUE KEY `section_editors_unique` (`context_id`,`assoc_id`,`assoc_type`,`user_id`,`user_group_id`),
  KEY `subeditor_submission_group_context_id` (`context_id`),
  KEY `subeditor_submission_group_user_id` (`user_id`),
  KEY `subeditor_submission_group_user_group_id` (`user_group_id`),
  KEY `subeditor_submission_group_assoc_id` (`assoc_id`,`assoc_type`),
  CONSTRAINT `section_editors_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `subeditor_submission_group_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`user_group_id`) ON DELETE CASCADE,
  CONSTRAINT `subeditor_submission_group_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 COMMENT='Subeditor assignments to e.g. sections and categories';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subeditor_submission_group`
--

LOCK TABLES `subeditor_submission_group` WRITE;
/*!40000 ALTER TABLE `subeditor_submission_group` DISABLE KEYS */;
INSERT INTO `subeditor_submission_group` VALUES (13,1,1,530,1,20),(14,1,4,530,1,20),(15,1,4,530,13,20),(12,1,5,530,12,6);
/*!40000 ALTER TABLE `subeditor_submission_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_comments`
--

DROP TABLE IF EXISTS `submission_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_comments` (
  `comment_id` bigint NOT NULL AUTO_INCREMENT,
  `comment_type` bigint DEFAULT NULL,
  `role_id` bigint NOT NULL,
  `submission_id` bigint NOT NULL,
  `assoc_id` bigint NOT NULL,
  `author_id` bigint NOT NULL,
  `comment_title` text NOT NULL,
  `comments` text,
  `date_posted` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `viewable` smallint DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `submission_comments_submission_id` (`submission_id`),
  KEY `submission_comments_author_id` (`author_id`),
  CONSTRAINT `submission_comments_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `submission_comments_submission_id` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Comments on a submission, e.g. peer review comments';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_comments`
--

LOCK TABLES `submission_comments` WRITE;
/*!40000 ALTER TABLE `submission_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `submission_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_file_revisions`
--

DROP TABLE IF EXISTS `submission_file_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_file_revisions` (
  `revision_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `submission_file_id` bigint unsigned NOT NULL,
  `file_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`revision_id`),
  KEY `submission_file_revisions_submission_file_id` (`submission_file_id`),
  KEY `submission_file_revisions_file_id` (`file_id`),
  CONSTRAINT `submission_file_revisions_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`file_id`) ON DELETE CASCADE,
  CONSTRAINT `submission_file_revisions_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3 COMMENT='Revisions map submission_file entries to files on the data store.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_file_revisions`
--

LOCK TABLES `submission_file_revisions` WRITE;
/*!40000 ALTER TABLE `submission_file_revisions` DISABLE KEYS */;
INSERT INTO `submission_file_revisions` VALUES (2,2,2),(3,3,3),(4,4,3),(5,5,2),(6,6,4),(7,7,5),(8,8,4),(10,10,7),(11,11,8),(12,12,8),(13,13,7),(14,14,9),(15,15,9),(16,16,9),(17,17,9),(18,18,10),(19,19,11),(20,20,11),(21,21,11),(22,22,12),(23,23,13),(24,24,13),(25,25,14),(26,26,15),(27,27,16),(28,28,17),(29,29,18),(30,30,19),(31,31,19),(32,32,20),(33,33,20),(34,34,21),(35,35,21),(36,36,22);
/*!40000 ALTER TABLE `submission_file_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_file_settings`
--

DROP TABLE IF EXISTS `submission_file_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_file_settings` (
  `submission_file_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `submission_file_id` bigint unsigned NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`submission_file_setting_id`),
  UNIQUE KEY `submission_file_settings_unique` (`submission_file_id`,`locale`,`setting_name`),
  KEY `submission_file_settings_submission_file_id` (`submission_file_id`),
  CONSTRAINT `submission_file_settings_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3 COMMENT='Localized data about submission files like published metadata.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_file_settings`
--

LOCK TABLES `submission_file_settings` WRITE;
/*!40000 ALTER TABLE `submission_file_settings` DISABLE KEYS */;
INSERT INTO `submission_file_settings` VALUES (2,2,'en','name','test-file-2.docx'),(3,3,'en','name','test-file-3.docx'),(4,4,'en','name','test-file-4.docx'),(5,5,'en','name','test-file-5.docx'),(6,6,'en','name','test-file-6.docx'),(7,7,'en','name','test-file-7.docx'),(8,8,'en','name','test-file-8.docx'),(10,10,'en','name','test-file-10.docx'),(11,11,'en','name','test-file-11.docx'),(12,12,'en','name','test-file-12.docx'),(13,13,'en','name','test-file-13.docx'),(14,14,'en','name','test-file-14.docx'),(15,15,'en','name','test-file-15.docx'),(16,16,'en','name','test-file-16.docx'),(17,17,'en','name','test-file-17.docx'),(18,18,'en','name','test-file-18.docx'),(19,19,'en','name','test-file-19.docx'),(20,20,'en','name','test-file-20.docx'),(21,21,'en','name','test-file-21.docx'),(22,22,'en','name','test-file-22.docx'),(23,23,'en','name','test-file-23.docx'),(24,24,'en','name','test-file-24.docx'),(25,25,'en','name','test-file-25.docx'),(26,26,'en','name','test-file-26.docx'),(27,27,'en','name','test-file-27.docx'),(28,28,'en','name','test-file-28.docx'),(29,29,'en','name','test-file-29.docx'),(30,30,'en','name','test-file-30.docx'),(31,31,'en','name','test-file-31.docx'),(32,32,'en','name','test-file-32.docx'),(33,33,'en','name','test-file-33.docx'),(34,34,'en','name','test-file-34.docx'),(35,35,'en','name','test-file-35.docx'),(36,36,'en','name','test-file-36.docx');
/*!40000 ALTER TABLE `submission_file_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_files`
--

DROP TABLE IF EXISTS `submission_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_files` (
  `submission_file_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `file_id` bigint unsigned NOT NULL,
  `source_submission_file_id` bigint unsigned DEFAULT NULL,
  `genre_id` bigint DEFAULT NULL,
  `file_stage` bigint NOT NULL,
  `direct_sales_price` varchar(255) DEFAULT NULL,
  `sales_type` varchar(255) DEFAULT NULL,
  `viewable` smallint DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `uploader_user_id` bigint DEFAULT NULL,
  `assoc_type` bigint DEFAULT NULL,
  `assoc_id` bigint DEFAULT NULL,
  PRIMARY KEY (`submission_file_id`),
  KEY `submission_files_submission_id` (`submission_id`),
  KEY `submission_files_file_id` (`file_id`),
  KEY `submission_files_genre_id` (`genre_id`),
  KEY `submission_files_uploader_user_id` (`uploader_user_id`),
  KEY `submission_files_stage_assoc` (`file_stage`,`assoc_type`,`assoc_id`),
  KEY `submission_files_source_submission_file_id` (`source_submission_file_id`),
  CONSTRAINT `submission_files_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`file_id`) ON DELETE CASCADE,
  CONSTRAINT `submission_files_genre_id_foreign` FOREIGN KEY (`genre_id`) REFERENCES `genres` (`genre_id`) ON DELETE SET NULL,
  CONSTRAINT `submission_files_source_submission_file_id_foreign` FOREIGN KEY (`source_submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE,
  CONSTRAINT `submission_files_submission_id` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE,
  CONSTRAINT `submission_files_uploader_user_id_foreign` FOREIGN KEY (`uploader_user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3 COMMENT='All files associated with a submission, such as those uploaded during submission, as revisions, or by copyeditors or layout editors for production.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_files`
--

LOCK TABLES `submission_files` WRITE;
/*!40000 ALTER TABLE `submission_files` DISABLE KEYS */;
INSERT INTO `submission_files` VALUES (2,3,2,NULL,1,2,NULL,NULL,NULL,'2025-11-21 17:48:26','2025-11-21 17:48:30',16,NULL,NULL),(3,3,3,NULL,1,2,NULL,NULL,NULL,'2025-11-21 17:48:52','2025-11-21 17:48:53',16,NULL,NULL),(4,3,3,3,1,4,NULL,NULL,NULL,'2025-11-21 18:12:07','2025-11-21 18:12:07',16,523,1),(5,3,2,2,1,4,NULL,NULL,NULL,'2025-11-21 18:12:07','2025-11-21 18:12:07',16,523,1),(6,4,4,NULL,1,2,NULL,NULL,NULL,'2025-12-19 18:54:56','2025-12-19 18:55:38',22,NULL,NULL),(7,5,5,NULL,1,2,NULL,NULL,NULL,'2025-12-19 18:58:54','2025-12-19 18:58:55',22,NULL,NULL),(8,4,4,6,1,4,NULL,NULL,NULL,'2025-12-19 19:14:23','2025-12-19 19:14:23',22,523,2),(10,7,7,NULL,1,2,NULL,NULL,NULL,'2025-12-20 06:36:41','2025-12-20 06:36:44',24,NULL,NULL),(11,8,8,NULL,1,2,NULL,NULL,NULL,'2025-12-20 06:39:54','2025-12-20 06:39:57',24,NULL,NULL),(12,8,8,11,1,4,NULL,NULL,NULL,'2025-12-20 06:49:30','2025-12-20 06:49:30',24,523,3),(13,7,7,10,1,4,NULL,NULL,NULL,'2025-12-20 06:49:57','2025-12-20 06:49:57',24,523,4),(14,9,9,NULL,1,2,NULL,NULL,NULL,'2026-07-08 22:12:05','2026-07-08 22:12:08',1,NULL,NULL),(15,9,9,14,1,4,NULL,NULL,NULL,'2026-07-08 23:29:24','2026-07-08 23:29:24',1,523,6),(16,9,9,14,1,4,NULL,NULL,NULL,'2026-07-08 23:30:35','2026-07-08 23:30:35',1,523,7),(17,9,9,14,1,4,NULL,NULL,NULL,'2026-07-09 17:56:00','2026-07-09 17:56:00',1,523,8),(18,17,10,NULL,1,2,NULL,NULL,NULL,'2026-07-15 16:44:46','2026-07-15 16:44:47',1,NULL,NULL),(19,16,11,NULL,1,2,NULL,NULL,NULL,'2026-07-19 17:47:23','2026-07-19 17:47:37',1,NULL,NULL),(20,16,11,19,1,4,NULL,NULL,NULL,'2026-07-20 15:41:34','2026-07-20 15:41:34',1,523,9),(21,16,11,19,1,4,NULL,NULL,NULL,'2026-07-20 15:42:33','2026-07-20 15:42:33',1,523,10),(22,18,12,NULL,1,2,NULL,NULL,NULL,'2026-07-23 19:58:58','2026-07-23 19:59:02',35,NULL,NULL),(23,25,13,NULL,1,2,NULL,NULL,NULL,'2026-07-23 23:27:08','2026-07-23 23:27:09',6,NULL,NULL),(24,25,13,23,1,4,NULL,NULL,NULL,'2026-07-23 23:32:20','2026-07-23 23:32:20',6,523,11),(25,20,14,NULL,1,2,NULL,NULL,NULL,'2026-07-23 23:35:05','2026-07-23 23:35:10',6,NULL,NULL),(26,26,15,NULL,1,2,NULL,NULL,NULL,'2026-07-23 23:39:21','2026-07-23 23:39:24',7,NULL,NULL),(27,27,16,NULL,1,2,NULL,NULL,NULL,'2026-07-23 23:56:20','2026-07-23 23:56:21',7,NULL,NULL),(28,28,17,NULL,1,2,NULL,NULL,NULL,'2026-07-24 00:02:10','2026-07-24 00:02:16',7,NULL,NULL),(29,30,18,NULL,1,2,NULL,NULL,NULL,'2026-07-24 19:13:11','2026-07-24 19:13:13',7,NULL,NULL),(30,31,19,NULL,1,2,NULL,NULL,NULL,'2026-07-24 19:42:31','2026-07-24 19:42:42',7,NULL,NULL),(31,31,19,30,1,4,NULL,NULL,NULL,'2026-07-24 19:43:41','2026-07-24 19:43:41',7,523,12),(32,32,20,NULL,1,2,NULL,NULL,NULL,'2026-07-24 19:47:51','2026-07-24 19:47:55',7,NULL,NULL),(33,32,20,32,1,4,NULL,NULL,NULL,'2026-07-24 19:48:53','2026-07-24 19:48:53',7,523,13),(34,33,21,NULL,1,2,NULL,NULL,NULL,'2026-07-24 20:03:21','2026-07-24 20:03:23',18,NULL,NULL),(35,33,21,34,1,4,NULL,NULL,NULL,'2026-07-24 20:16:37','2026-07-24 20:16:37',18,523,14),(36,33,22,NULL,1,6,NULL,NULL,NULL,'2026-07-25 17:52:17','2026-07-25 17:52:20',18,NULL,NULL);
/*!40000 ALTER TABLE `submission_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_search_keyword_list`
--

DROP TABLE IF EXISTS `submission_search_keyword_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_search_keyword_list` (
  `keyword_id` bigint NOT NULL AUTO_INCREMENT,
  `keyword_text` varchar(60) NOT NULL,
  PRIMARY KEY (`keyword_id`),
  UNIQUE KEY `submission_search_keyword_text` (`keyword_text`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb3 COMMENT='A list of all keywords used in the search index';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_search_keyword_list`
--

LOCK TABLES `submission_search_keyword_list` WRITE;
/*!40000 ALTER TABLE `submission_search_keyword_list` DISABLE KEYS */;
INSERT INTO `submission_search_keyword_list` VALUES (9,'aaron'),(4,'abstract'),(97,'accept'),(21,'affect'),(34,'ago'),(46,'ahead'),(2,'arthur'),(8,'article'),(23,'author'),(6,'authortest'),(51,'banality'),(99,'barbara'),(96,'blah'),(88,'blank'),(76,'bold'),(112,'boundary'),(11,'brilliant'),(109,'character'),(31,'cheese'),(30,'chocolate'),(70,'comment'),(84,'comments'),(24,'connor'),(49,'dare'),(35,'decided'),(26,'desk'),(95,'dolar'),(71,'editor'),(89,'empty'),(74,'esttest'),(64,'fabulated'),(41,'fake'),(108,'fifty'),(66,'foreclosure'),(67,'form'),(50,'formatted'),(85,'formatting'),(48,'fucking'),(65,'futures'),(62,'global'),(63,'gothic'),(60,'grammars'),(61,'grief'),(104,'guess'),(94,'ipsum'),(18,'isn'),(77,'italic'),(80,'italics'),(73,'jackson'),(83,'johnson'),(82,'kevin'),(37,'keyword'),(87,'line'),(102,'llines'),(38,'long'),(93,'lorem'),(106,'lots'),(36,'make'),(110,'mark'),(14,'marxism'),(16,'materialism'),(20,'modernism'),(86,'multi'),(101,'multiple'),(28,'nonsense'),(54,'numb3rzzz'),(10,'obedkoff'),(12,'paper'),(92,'paragraph'),(19,'poetics'),(43,'post45'),(90,'present'),(15,'psychoanalysis'),(98,'publications'),(17,'publish'),(42,'real'),(29,'refer'),(47,'reject'),(27,'rejected'),(40,'resemblance'),(58,'resubmit'),(57,'revise'),(59,'revolt'),(55,'ride'),(56,'rise'),(32,'score'),(52,'scum'),(91,'single'),(69,'submission'),(44,'submissions'),(78,'superscript'),(39,'system'),(3,'test'),(81,'test123'),(5,'testing'),(75,'testinkg'),(68,'theeauthor'),(22,'theory'),(105,'title'),(107,'truncate'),(79,'ttest'),(103,'typos'),(45,'unintentional'),(53,'villainy'),(1,'whatyever'),(72,'william'),(100,'wilson'),(7,'wong'),(111,'word'),(25,'words'),(13,'written'),(33,'years');
/*!40000 ALTER TABLE `submission_search_keyword_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_search_object_keywords`
--

DROP TABLE IF EXISTS `submission_search_object_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_search_object_keywords` (
  `submission_search_object_keyword_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `object_id` bigint NOT NULL,
  `keyword_id` bigint NOT NULL,
  `pos` int NOT NULL COMMENT 'Word position of the keyword in the object.',
  PRIMARY KEY (`submission_search_object_keyword_id`),
  UNIQUE KEY `submission_search_object_keywords_unique` (`object_id`,`pos`),
  KEY `submission_search_object_keywords_object_id` (`object_id`),
  KEY `submission_search_object_keywords_keyword_id` (`keyword_id`),
  CONSTRAINT `submission_search_object_keywords_keyword_id` FOREIGN KEY (`keyword_id`) REFERENCES `submission_search_keyword_list` (`keyword_id`) ON DELETE CASCADE,
  CONSTRAINT `submission_search_object_keywords_object_id_foreign` FOREIGN KEY (`object_id`) REFERENCES `submission_search_objects` (`object_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=454 DEFAULT CHARSET=utf8mb3 COMMENT='Relationships between search objects and keywords in the search index';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_search_object_keywords`
--

LOCK TABLES `submission_search_object_keywords` WRITE;
/*!40000 ALTER TABLE `submission_search_object_keywords` DISABLE KEYS */;
INSERT INTO `submission_search_object_keywords` VALUES (48,33,9,0),(49,33,10,1),(50,34,11,0),(51,34,12,1),(52,35,12,0),(53,35,18,1),(54,35,11,2),(55,35,12,3),(56,37,19,0),(57,37,20,1),(58,37,21,2),(59,37,22,3),(115,49,23,0),(116,49,24,1),(117,50,25,0),(118,50,26,1),(119,50,27,2),(120,50,28,3),(121,51,46,0),(122,51,47,1),(123,51,48,2),(124,51,49,3),(125,53,28,0),(126,53,30,1),(127,53,31,2),(128,53,32,3),(129,53,33,4),(130,53,34,5),(131,53,35,6),(132,53,36,7),(133,53,37,8),(134,53,38,9),(135,53,39,10),(166,57,23,0),(167,57,24,1),(168,58,25,0),(169,58,50,1),(170,58,51,2),(171,59,55,0),(172,59,56,1),(173,59,57,2),(174,59,58,3),(175,59,59,4),(176,61,51,0),(177,61,52,1),(178,61,53,2),(179,61,54,3),(198,17,6,0),(199,17,7,1),(200,18,2,0),(201,18,3,1),(202,18,8,2),(203,21,5,0),(204,25,9,0),(205,25,10,1),(206,26,11,0),(207,26,12,1),(208,27,11,0),(209,27,12,1),(210,27,13,2),(211,27,17,3),(212,29,14,0),(213,29,15,1),(214,29,16,2),(237,90,3,0),(248,66,5,0),(249,66,5,1),(261,81,6,0),(262,81,7,1),(263,82,64,0),(264,82,65,1),(265,82,66,2),(266,82,67,3),(267,83,55,0),(268,83,56,1),(269,83,57,2),(270,83,58,3),(271,83,59,4),(272,98,5,0),(273,98,5,1),(274,105,2,0),(275,105,68,1),(276,106,5,0),(277,106,69,1),(278,106,70,2),(279,106,71,3),(317,153,72,0),(318,153,73,1),(319,154,81,0),(320,161,82,0),(321,161,83,1),(322,162,5,0),(323,162,84,1),(324,162,71,2),(325,169,82,0),(326,169,83,1),(327,170,5,0),(328,170,84,1),(329,170,71,2),(330,170,85,3),(331,177,82,0),(332,177,83,1),(333,178,5,0),(334,178,86,1),(335,178,87,2),(336,178,70,3),(337,186,3,0),(343,193,82,0),(344,193,83,1),(345,194,5,0),(346,194,88,1),(347,194,4,2),(351,201,82,0),(352,201,83,1),(353,202,5,0),(354,202,89,1),(355,202,4,2),(356,202,70,3),(357,202,71,4),(358,202,90,5),(380,209,82,0),(381,209,83,1),(382,210,8,0),(383,210,86,1),(384,210,92,2),(385,210,4,3),(386,211,4,0),(387,211,93,1),(388,211,94,2),(389,211,95,3),(390,211,96,4),(391,211,96,5),(392,211,96,6),(393,211,97,7),(394,211,98,8),(395,211,86,9),(396,211,92,10),(397,211,4,11),(413,217,99,0),(414,217,100,1),(415,218,5,0),(416,218,4,1),(417,218,70,2),(418,219,4,0),(419,219,101,1),(420,219,102,2),(421,219,103,3),(422,219,104,4),(442,145,72,0),(443,145,73,1),(444,146,38,0),(445,146,105,1),(446,146,106,2),(447,146,25,3),(448,146,107,4),(449,146,108,5),(450,146,109,6),(451,146,110,7),(452,146,111,8),(453,146,112,9);
/*!40000 ALTER TABLE `submission_search_object_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_search_objects`
--

DROP TABLE IF EXISTS `submission_search_objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_search_objects` (
  `object_id` bigint NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `type` int NOT NULL COMMENT 'Type of item. E.g., abstract, fulltext, etc.',
  `assoc_id` bigint DEFAULT NULL COMMENT 'Optional ID of an associated record (e.g., a file_id)',
  PRIMARY KEY (`object_id`),
  KEY `submission_search_objects_submission_id` (`submission_id`),
  CONSTRAINT `submission_search_object_submission` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=utf8mb3 COMMENT='A list of all search objects indexed in the search index';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_search_objects`
--

LOCK TABLES `submission_search_objects` WRITE;
/*!40000 ALTER TABLE `submission_search_objects` DISABLE KEYS */;
INSERT INTO `submission_search_objects` VALUES (17,3,1,NULL),(18,3,2,NULL),(19,3,4,NULL),(20,3,16,NULL),(21,3,17,NULL),(22,3,8,NULL),(23,3,32,NULL),(24,3,64,NULL),(25,4,1,NULL),(26,4,2,NULL),(27,4,4,NULL),(28,4,16,NULL),(29,4,17,NULL),(30,4,8,NULL),(31,4,32,NULL),(32,4,64,NULL),(33,5,1,NULL),(34,5,2,NULL),(35,5,4,NULL),(36,5,16,NULL),(37,5,17,NULL),(38,5,8,NULL),(39,5,32,NULL),(40,5,64,NULL),(49,7,1,NULL),(50,7,2,NULL),(51,7,4,NULL),(52,7,16,NULL),(53,7,17,NULL),(54,7,8,NULL),(55,7,32,NULL),(56,7,64,NULL),(57,8,1,NULL),(58,8,2,NULL),(59,8,4,NULL),(60,8,16,NULL),(61,8,17,NULL),(62,8,8,NULL),(63,8,32,NULL),(64,8,64,NULL),(65,9,1,NULL),(66,9,2,NULL),(67,9,4,NULL),(68,9,16,NULL),(69,9,17,NULL),(70,9,8,NULL),(71,9,32,NULL),(72,9,64,NULL),(81,15,1,NULL),(82,15,2,NULL),(83,15,4,NULL),(84,15,16,NULL),(85,15,17,NULL),(86,15,8,NULL),(87,15,32,NULL),(88,15,64,NULL),(89,16,1,NULL),(90,16,2,NULL),(91,16,4,NULL),(92,16,16,NULL),(93,16,17,NULL),(94,16,8,NULL),(95,16,32,NULL),(96,16,64,NULL),(97,17,1,NULL),(98,17,2,NULL),(99,17,4,NULL),(100,17,16,NULL),(101,17,17,NULL),(102,17,8,NULL),(103,17,32,NULL),(104,17,64,NULL),(105,18,1,NULL),(106,18,2,NULL),(107,18,4,NULL),(108,18,16,NULL),(109,18,17,NULL),(110,18,8,NULL),(111,18,32,NULL),(112,18,64,NULL),(145,25,1,NULL),(146,25,2,NULL),(147,25,4,NULL),(148,25,16,NULL),(149,25,17,NULL),(150,25,8,NULL),(151,25,32,NULL),(152,25,64,NULL),(153,20,1,NULL),(154,20,2,NULL),(155,20,4,NULL),(156,20,16,NULL),(157,20,17,NULL),(158,20,8,NULL),(159,20,32,NULL),(160,20,64,NULL),(161,26,1,NULL),(162,26,2,NULL),(163,26,4,NULL),(164,26,16,NULL),(165,26,17,NULL),(166,26,8,NULL),(167,26,32,NULL),(168,26,64,NULL),(169,27,1,NULL),(170,27,2,NULL),(171,27,4,NULL),(172,27,16,NULL),(173,27,17,NULL),(174,27,8,NULL),(175,27,32,NULL),(176,27,64,NULL),(177,28,1,NULL),(178,28,2,NULL),(179,28,4,NULL),(180,28,16,NULL),(181,28,17,NULL),(182,28,8,NULL),(183,28,32,NULL),(184,28,64,NULL),(185,29,1,NULL),(186,29,2,NULL),(187,29,4,NULL),(188,29,16,NULL),(189,29,17,NULL),(190,29,8,NULL),(191,29,32,NULL),(192,29,64,NULL),(193,30,1,NULL),(194,30,2,NULL),(195,30,4,NULL),(196,30,16,NULL),(197,30,17,NULL),(198,30,8,NULL),(199,30,32,NULL),(200,30,64,NULL),(201,31,1,NULL),(202,31,2,NULL),(203,31,4,NULL),(204,31,16,NULL),(205,31,17,NULL),(206,31,8,NULL),(207,31,32,NULL),(208,31,64,NULL),(209,32,1,NULL),(210,32,2,NULL),(211,32,4,NULL),(212,32,16,NULL),(213,32,17,NULL),(214,32,8,NULL),(215,32,32,NULL),(216,32,64,NULL),(217,33,1,NULL),(218,33,2,NULL),(219,33,4,NULL),(220,33,16,NULL),(221,33,17,NULL),(222,33,8,NULL),(223,33,32,NULL),(224,33,64,NULL);
/*!40000 ALTER TABLE `submission_search_objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submission_settings`
--

DROP TABLE IF EXISTS `submission_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submission_settings` (
  `submission_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `submission_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`submission_setting_id`),
  UNIQUE KEY `submission_settings_unique` (`submission_id`,`locale`,`setting_name`),
  KEY `submission_settings_submission_id` (`submission_id`),
  CONSTRAINT `submission_settings_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 COMMENT='Localized data about submissions';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submission_settings`
--

LOCK TABLES `submission_settings` WRITE;
/*!40000 ALTER TABLE `submission_settings` DISABLE KEYS */;
INSERT INTO `submission_settings` VALUES (1,3,'','commentsForTheEditors','<p>None</p>'),(2,4,'','commentsForTheEditors','<p>Thanks :) </p>'),(3,5,'','commentsForTheEditors','<p>Hope you like it :) </p>'),(4,7,'','commentsForTheEditors','<p>You are too chicken to reject this. I know you.</p>'),(5,8,'','commentsForTheEditors','<p>The funds have been deposited in your Swiss account, as agreed</p>'),(7,18,'','commentsForTheEditors','<p>Here\'s some additional info! I\'m testing right now.</p>'),(8,25,'','commentsForTheEditors','<p>testing comments for editor</p>'),(9,26,'','commentsForTheEditors','<p>Testing comments for editor</p>'),(10,27,'','commentsForTheEditors','<p>this is a single line comment.</p>'),(11,28,'','commentsForTheEditors','<p>Testing</p>\n<p> </p>\n<p>multi-line comments (preceded by double line break)</p>\n<p>another line!</p>'),(12,31,'','commentsForTheEditors','<p>This is my comment</p>\n<p>for</p>\n<p>the</p>\n<p>editor!</p>'),(13,33,'','commentsForTheEditors','<p>I have a lot of comments for the editor</p>\n<p> </p>\n<p>Like THIS ONE</p>');
/*!40000 ALTER TABLE `submission_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submissions`
--

DROP TABLE IF EXISTS `submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `submissions` (
  `submission_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `current_publication_id` bigint DEFAULT NULL,
  `date_last_activity` datetime DEFAULT NULL,
  `date_submitted` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `stage_id` bigint NOT NULL DEFAULT '1',
  `locale` varchar(28) DEFAULT NULL,
  `status` smallint NOT NULL DEFAULT '1',
  `submission_progress` varchar(50) NOT NULL DEFAULT 'start',
  `work_type` smallint DEFAULT '0',
  PRIMARY KEY (`submission_id`),
  KEY `submissions_context_id` (`context_id`),
  KEY `submissions_publication_id` (`current_publication_id`),
  CONSTRAINT `submissions_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `submissions_publication_id` FOREIGN KEY (`current_publication_id`) REFERENCES `publications` (`publication_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3 COMMENT='All submissions submitted to the context, including incomplete, declined and unpublished submissions.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submissions`
--

LOCK TABLES `submissions` WRITE;
/*!40000 ALTER TABLE `submissions` DISABLE KEYS */;
INSERT INTO `submissions` VALUES (3,1,3,'2026-07-06 19:53:42','2025-11-21 17:49:24','2025-11-23 17:01:52',5,'en',3,'',0),(4,1,4,'2026-07-08 21:27:49','2025-12-19 18:56:31','2025-12-19 18:56:31',5,'en',3,'',0),(5,1,5,'2025-12-19 19:05:16','2025-12-19 18:59:24','2025-12-19 18:59:24',1,'en',4,'',0),(7,1,7,'2025-12-20 06:49:58','2025-12-20 06:37:17','2025-12-20 06:37:17',3,'en',4,'',0),(8,1,8,'2026-07-06 15:53:39','2025-12-20 06:40:29','2026-07-06 00:34:19',5,'en',3,'',0),(9,1,9,'2026-07-20 15:39:42','2026-07-08 22:12:31','2026-07-08 22:12:31',3,'en',1,'',0),(15,1,15,'2026-07-09 17:34:35','2026-07-08 22:05:08','2026-07-08 22:05:08',5,'en',3,'',0),(16,1,16,'2026-07-20 15:42:33','2026-07-19 17:48:30','2026-07-19 17:48:30',3,'en',1,'',0),(17,1,17,'2026-07-15 17:36:00','2026-07-15 16:44:26','2026-07-15 17:36:00',1,'en',1,'files',0),(18,1,18,'2026-07-23 19:59:56','2026-07-23 19:59:56','2026-07-23 19:59:56',1,'en',1,'',0),(20,1,20,'2026-07-23 23:35:24','2026-07-23 23:35:24','2026-07-23 23:35:24',1,'en',1,'',0),(25,1,25,'2026-07-25 18:59:55','2026-07-23 23:27:28','2026-07-23 23:27:28',3,'en',1,'',0),(26,1,26,'2026-07-23 23:39:41','2026-07-23 23:39:40','2026-07-23 23:39:40',1,'en',1,'',0),(27,1,27,'2026-07-23 23:56:57','2026-07-23 23:56:57','2026-07-23 23:56:57',1,'en',1,'',0),(28,1,28,'2026-07-24 00:02:41','2026-07-24 00:02:41','2026-07-24 00:02:41',1,'en',1,'',0),(29,1,29,'2026-07-24 17:57:30','2026-07-24 17:57:30','2026-07-24 17:57:30',1,'en',1,'start',0),(30,1,30,'2026-07-24 19:41:26','2026-07-24 19:41:26','2026-07-24 19:41:26',1,'en',1,'',0),(31,1,31,'2026-07-24 19:45:07','2026-07-24 19:42:51','2026-07-24 19:42:51',3,'en',1,'',0),(32,1,32,'2026-07-24 19:52:36','2026-07-24 19:48:07','2026-07-24 19:48:07',3,'en',1,'',0),(33,1,33,'2026-07-25 17:52:17','2026-07-24 20:03:43','2026-07-24 20:03:43',4,'en',1,'',0);
/*!40000 ALTER TABLE `submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_type_settings`
--

DROP TABLE IF EXISTS `subscription_type_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_type_settings` (
  `subscription_type_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  `setting_type` varchar(6) NOT NULL,
  PRIMARY KEY (`subscription_type_setting_id`),
  UNIQUE KEY `subscription_type_settings_unique` (`type_id`,`locale`,`setting_name`),
  KEY `subscription_type_settings_type_id` (`type_id`),
  CONSTRAINT `subscription_type_settings_type_id` FOREIGN KEY (`type_id`) REFERENCES `subscription_types` (`type_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='More data about subscription types, including localized properties such as names.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_type_settings`
--

LOCK TABLES `subscription_type_settings` WRITE;
/*!40000 ALTER TABLE `subscription_type_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_type_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscription_types`
--

DROP TABLE IF EXISTS `subscription_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription_types` (
  `type_id` bigint NOT NULL AUTO_INCREMENT,
  `journal_id` bigint NOT NULL,
  `cost` decimal(8,2) unsigned NOT NULL,
  `currency_code_alpha` varchar(3) NOT NULL,
  `duration` smallint DEFAULT NULL,
  `format` smallint NOT NULL,
  `institutional` smallint NOT NULL DEFAULT '0',
  `membership` smallint NOT NULL DEFAULT '0',
  `disable_public_display` smallint NOT NULL,
  `seq` double NOT NULL,
  PRIMARY KEY (`type_id`),
  KEY `subscription_types_journal_id` (`journal_id`),
  CONSTRAINT `subscription_types_journal_id` FOREIGN KEY (`journal_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Subscription types represent the kinds of subscriptions that a user or institution may have, such as an annual subscription or a discounted subscription.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription_types`
--

LOCK TABLES `subscription_types` WRITE;
/*!40000 ALTER TABLE `subscription_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscription_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `subscription_id` bigint NOT NULL AUTO_INCREMENT,
  `journal_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `type_id` bigint NOT NULL,
  `date_start` date DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `status` smallint NOT NULL DEFAULT '1',
  `membership` varchar(40) DEFAULT NULL,
  `reference_number` varchar(40) DEFAULT NULL,
  `notes` text,
  PRIMARY KEY (`subscription_id`),
  KEY `subscriptions_journal_id` (`journal_id`),
  KEY `subscriptions_user_id` (`user_id`),
  KEY `subscriptions_type_id` (`type_id`),
  CONSTRAINT `subscriptions_journal_id` FOREIGN KEY (`journal_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_type_id` FOREIGN KEY (`type_id`) REFERENCES `subscription_types` (`type_id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='A list of subscriptions, both institutional and individual, for journals that use subscription-based publishing.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temporary_files`
--

DROP TABLE IF EXISTS `temporary_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temporary_files` (
  `file_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `file_name` varchar(90) NOT NULL,
  `file_type` varchar(255) DEFAULT NULL,
  `file_size` bigint NOT NULL,
  `original_file_name` varchar(127) DEFAULT NULL,
  `date_uploaded` datetime NOT NULL,
  PRIMARY KEY (`file_id`),
  KEY `temporary_files_user_id` (`user_id`),
  CONSTRAINT `temporary_files_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COMMENT='Temporary files, e.g. where files are kept during an upload process before they are moved somewhere more appropriate.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temporary_files`
--

LOCK TABLES `temporary_files` WRITE;
/*!40000 ALTER TABLE `temporary_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `temporary_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage_stats_institution_temporary_records`
--

DROP TABLE IF EXISTS `usage_stats_institution_temporary_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usage_stats_institution_temporary_records` (
  `usage_stats_temp_institution_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `load_id` varchar(50) NOT NULL,
  `line_number` bigint NOT NULL,
  `institution_id` bigint NOT NULL,
  PRIMARY KEY (`usage_stats_temp_institution_id`),
  UNIQUE KEY `usitr_load_id_line_number_institution_id` (`load_id`,`line_number`,`institution_id`),
  KEY `usi_institution_id` (`institution_id`),
  CONSTRAINT `usi_institution_id_foreign` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`institution_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Temporary stats for views and downloads from institutions based on visitor log records. Data in this table is provisional. See the metrics_* tables for compiled stats.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage_stats_institution_temporary_records`
--

LOCK TABLES `usage_stats_institution_temporary_records` WRITE;
/*!40000 ALTER TABLE `usage_stats_institution_temporary_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `usage_stats_institution_temporary_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage_stats_total_temporary_records`
--

DROP TABLE IF EXISTS `usage_stats_total_temporary_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usage_stats_total_temporary_records` (
  `usage_stats_temp_total_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `ip` varchar(64) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `line_number` bigint NOT NULL,
  `canonical_url` varchar(255) NOT NULL,
  `issue_id` bigint DEFAULT NULL,
  `issue_galley_id` bigint DEFAULT NULL,
  `context_id` bigint NOT NULL,
  `submission_id` bigint DEFAULT NULL,
  `representation_id` bigint DEFAULT NULL,
  `submission_file_id` bigint unsigned DEFAULT NULL,
  `assoc_type` bigint NOT NULL,
  `file_type` smallint DEFAULT NULL,
  `country` varchar(2) NOT NULL DEFAULT '',
  `region` varchar(3) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `load_id` varchar(50) NOT NULL,
  PRIMARY KEY (`usage_stats_temp_total_id`),
  KEY `usage_stats_total_temporary_records_issue_id` (`issue_id`),
  KEY `usage_stats_total_temporary_records_issue_galley_id` (`issue_galley_id`),
  KEY `usage_stats_total_temporary_records_context_id` (`context_id`),
  KEY `usage_stats_total_temporary_records_submission_id` (`submission_id`),
  KEY `usage_stats_total_temporary_records_representation_id` (`representation_id`),
  KEY `usage_stats_total_temporary_records_submission_file_id` (`submission_file_id`),
  KEY `ust_load_id_context_id_ip_ua_url` (`load_id`,`context_id`,`ip`,`user_agent`,`canonical_url`),
  CONSTRAINT `ust_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `ust_issue_galley_id_foreign` FOREIGN KEY (`issue_galley_id`) REFERENCES `issue_galleys` (`galley_id`) ON DELETE CASCADE,
  CONSTRAINT `ust_issue_id_foreign` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`issue_id`) ON DELETE CASCADE,
  CONSTRAINT `ust_representation_id_foreign` FOREIGN KEY (`representation_id`) REFERENCES `publication_galleys` (`galley_id`) ON DELETE CASCADE,
  CONSTRAINT `ust_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE,
  CONSTRAINT `ust_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4202 DEFAULT CHARSET=utf8mb3 COMMENT='Temporary stats totals based on visitor log records. Data in this table is provisional. See the metrics_* tables for compiled stats.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage_stats_total_temporary_records`
--

LOCK TABLES `usage_stats_total_temporary_records` WRITE;
/*!40000 ALTER TABLE `usage_stats_total_temporary_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `usage_stats_total_temporary_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage_stats_unique_item_investigations_temporary_records`
--

DROP TABLE IF EXISTS `usage_stats_unique_item_investigations_temporary_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usage_stats_unique_item_investigations_temporary_records` (
  `usage_stats_temp_unique_item_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `ip` varchar(64) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `line_number` bigint NOT NULL,
  `context_id` bigint NOT NULL,
  `submission_id` bigint NOT NULL,
  `representation_id` bigint DEFAULT NULL,
  `submission_file_id` bigint unsigned DEFAULT NULL,
  `assoc_type` bigint NOT NULL,
  `file_type` smallint DEFAULT NULL,
  `country` varchar(2) NOT NULL DEFAULT '',
  `region` varchar(3) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `load_id` varchar(50) NOT NULL,
  PRIMARY KEY (`usage_stats_temp_unique_item_id`),
  KEY `usii_context_id` (`context_id`),
  KEY `usii_submission_id` (`submission_id`),
  KEY `usii_representation_id` (`representation_id`),
  KEY `usii_submission_file_id` (`submission_file_id`),
  KEY `usii_load_id_context_id_ip_ua` (`load_id`,`context_id`,`ip`,`user_agent`),
  CONSTRAINT `usii_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `usii_representation_id_foreign` FOREIGN KEY (`representation_id`) REFERENCES `publication_galleys` (`galley_id`) ON DELETE CASCADE,
  CONSTRAINT `usii_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE,
  CONSTRAINT `usii_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Temporary stats on unique downloads based on visitor log records. Data in this table is provisional. See the metrics_* tables for compiled stats.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage_stats_unique_item_investigations_temporary_records`
--

LOCK TABLES `usage_stats_unique_item_investigations_temporary_records` WRITE;
/*!40000 ALTER TABLE `usage_stats_unique_item_investigations_temporary_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `usage_stats_unique_item_investigations_temporary_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage_stats_unique_item_requests_temporary_records`
--

DROP TABLE IF EXISTS `usage_stats_unique_item_requests_temporary_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usage_stats_unique_item_requests_temporary_records` (
  `usage_stats_temp_item_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `ip` varchar(64) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `line_number` bigint NOT NULL,
  `context_id` bigint NOT NULL,
  `submission_id` bigint NOT NULL,
  `representation_id` bigint DEFAULT NULL,
  `submission_file_id` bigint unsigned DEFAULT NULL,
  `assoc_type` bigint NOT NULL,
  `file_type` smallint DEFAULT NULL,
  `country` varchar(2) NOT NULL DEFAULT '',
  `region` varchar(3) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `load_id` varchar(50) NOT NULL,
  PRIMARY KEY (`usage_stats_temp_item_id`),
  KEY `usir_context_id` (`context_id`),
  KEY `usir_submission_id` (`submission_id`),
  KEY `usir_representation_id` (`representation_id`),
  KEY `usir_submission_file_id` (`submission_file_id`),
  KEY `usir_load_id_context_id_ip_ua` (`load_id`,`context_id`,`ip`,`user_agent`),
  CONSTRAINT `usir_context_id_foreign` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `usir_representation_id_foreign` FOREIGN KEY (`representation_id`) REFERENCES `publication_galleys` (`galley_id`) ON DELETE CASCADE,
  CONSTRAINT `usir_submission_file_id_foreign` FOREIGN KEY (`submission_file_id`) REFERENCES `submission_files` (`submission_file_id`) ON DELETE CASCADE,
  CONSTRAINT `usir_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`submission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='Temporary stats on unique views based on visitor log records. Data in this table is provisional. See the metrics_* tables for compiled stats.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage_stats_unique_item_requests_temporary_records`
--

LOCK TABLES `usage_stats_unique_item_requests_temporary_records` WRITE;
/*!40000 ALTER TABLE `usage_stats_unique_item_requests_temporary_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `usage_stats_unique_item_requests_temporary_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_settings`
--

DROP TABLE IF EXISTS `user_group_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_group_settings` (
  `user_group_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_group_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`user_group_setting_id`),
  UNIQUE KEY `user_group_settings_unique` (`user_group_id`,`locale`,`setting_name`),
  KEY `user_group_settings_user_group_id` (`user_group_id`),
  CONSTRAINT `user_group_settings_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`user_group_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb3 COMMENT='More data about user groups, including localized properties such as the name.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_settings`
--

LOCK TABLES `user_group_settings` WRITE;
/*!40000 ALTER TABLE `user_group_settings` DISABLE KEYS */;
INSERT INTO `user_group_settings` VALUES (1,2,'','nameLocaleKey','default.groups.name.manager'),(2,2,'','abbrevLocaleKey','default.groups.abbrev.manager'),(3,2,'en','name','Journal manager'),(4,2,'en','abbrev','JM'),(5,3,'','nameLocaleKey','default.groups.name.editor'),(6,3,'','abbrevLocaleKey','default.groups.abbrev.editor'),(7,3,'en','name','Journal editor'),(8,3,'en','abbrev','JE'),(13,5,'','nameLocaleKey','default.groups.name.sectionEditor'),(14,5,'','abbrevLocaleKey','default.groups.abbrev.sectionEditor'),(15,5,'en','name','Section editor'),(16,5,'en','abbrev','SecE'),(17,6,'','nameLocaleKey','default.groups.name.guestEditor'),(18,6,'','abbrevLocaleKey','default.groups.abbrev.guestEditor'),(19,6,'en','name','Guest editor'),(20,6,'en','abbrev','GE'),(49,14,'','nameLocaleKey','default.groups.name.author'),(50,14,'','abbrevLocaleKey','default.groups.abbrev.author'),(51,14,'en','name','Author'),(52,14,'en','abbrev','AU'),(57,16,'','nameLocaleKey','default.groups.name.externalReviewer'),(58,16,'','abbrevLocaleKey','default.groups.abbrev.externalReviewer'),(59,16,'en','name','Reviewer'),(60,16,'en','abbrev','R'),(73,20,'','recommendOnly','0'),(74,20,'en','name','Co-Editor'),(75,20,'en','abbrev','CE'),(76,21,'','recommendOnly','0'),(77,21,'en','name','Managing Editor'),(78,21,'en','abbrev','ME'),(79,22,'','recommendOnly','0'),(80,22,'en','name','Assistant Editor'),(81,22,'en','abbrev','AE'),(82,3,'','recommendOnly','0'),(83,6,'','recommendOnly','0'),(84,23,'','recommendOnly','0'),(85,23,'en','name','Copyeditor'),(86,23,'en','abbrev','CE');
/*!40000 ALTER TABLE `user_group_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_stage`
--

DROP TABLE IF EXISTS `user_group_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_group_stage` (
  `user_group_stage_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `context_id` bigint NOT NULL,
  `user_group_id` bigint NOT NULL,
  `stage_id` bigint NOT NULL,
  PRIMARY KEY (`user_group_stage_id`),
  UNIQUE KEY `user_group_stage_unique` (`context_id`,`user_group_id`,`stage_id`),
  KEY `user_group_stage_context_id` (`context_id`),
  KEY `user_group_stage_user_group_id` (`user_group_id`),
  KEY `user_group_stage_stage_id` (`stage_id`),
  CONSTRAINT `user_group_stage_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE,
  CONSTRAINT `user_group_stage_user_group_id` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`user_group_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb3 COMMENT='Which stages of the editorial workflow the user_groups can access.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_stage`
--

LOCK TABLES `user_group_stage` WRITE;
/*!40000 ALTER TABLE `user_group_stage` DISABLE KEYS */;
INSERT INTO `user_group_stage` VALUES (48,1,3,1),(49,1,3,3),(50,1,3,4),(51,1,3,5),(7,1,5,1),(8,1,5,3),(9,1,5,4),(10,1,5,5),(52,1,6,1),(53,1,6,3),(54,1,6,4),(55,1,6,5),(56,1,14,1),(24,1,14,3),(25,1,14,4),(26,1,14,5),(31,1,16,3),(40,1,20,1),(41,1,20,3),(42,1,20,4),(43,1,20,5),(36,1,21,1),(37,1,21,3),(38,1,21,4),(39,1,21,5),(44,1,22,1),(45,1,22,3),(46,1,22,4),(47,1,22,5),(57,1,23,4);
/*!40000 ALTER TABLE `user_group_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_groups` (
  `user_group_id` bigint NOT NULL AUTO_INCREMENT,
  `context_id` bigint DEFAULT NULL,
  `role_id` bigint NOT NULL,
  `is_default` smallint NOT NULL DEFAULT '0',
  `show_title` smallint NOT NULL DEFAULT '1',
  `permit_self_registration` smallint NOT NULL DEFAULT '0',
  `permit_metadata_edit` smallint NOT NULL DEFAULT '0',
  `permit_settings` smallint NOT NULL DEFAULT '0',
  `masthead` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_group_id`),
  KEY `user_groups_context_id` (`context_id`),
  KEY `user_groups_user_group_id` (`user_group_id`),
  KEY `user_groups_role_id` (`role_id`),
  CONSTRAINT `user_groups_context_id` FOREIGN KEY (`context_id`) REFERENCES `journals` (`journal_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3 COMMENT='All defined user roles in a context, such as Author, Reviewer, Section Editor and Journal Manager.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
INSERT INTO `user_groups` VALUES (1,NULL,1,1,1,0,0,1,0),(2,1,16,1,1,0,1,1,0),(3,1,16,1,0,0,1,1,0),(5,1,17,1,1,0,1,0,1),(6,1,17,1,1,0,0,0,0),(14,1,65536,1,1,1,0,0,0),(16,1,4096,1,1,1,0,0,1),(20,1,16,0,0,0,1,1,1),(21,1,16,0,0,0,1,1,1),(22,1,4097,0,0,0,1,0,1),(23,1,4097,0,0,0,0,0,0);
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_interests`
--

DROP TABLE IF EXISTS `user_interests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_interests` (
  `user_interest_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `controlled_vocab_entry_id` bigint NOT NULL,
  PRIMARY KEY (`user_interest_id`),
  UNIQUE KEY `u_e_pkey` (`user_id`,`controlled_vocab_entry_id`),
  KEY `user_interests_user_id` (`user_id`),
  KEY `user_interests_controlled_vocab_entry_id` (`controlled_vocab_entry_id`),
  CONSTRAINT `user_interests_controlled_vocab_entry_id_foreign` FOREIGN KEY (`controlled_vocab_entry_id`) REFERENCES `controlled_vocab_entries` (`controlled_vocab_entry_id`) ON DELETE CASCADE,
  CONSTRAINT `user_interests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COMMENT='Associates users with user interests (which are stored in the controlled vocabulary tables).';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_interests`
--

LOCK TABLES `user_interests` WRITE;
/*!40000 ALTER TABLE `user_interests` DISABLE KEYS */;
INSERT INTO `user_interests` VALUES (1,17,3),(2,17,4),(3,25,19);
/*!40000 ALTER TABLE `user_interests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_settings`
--

DROP TABLE IF EXISTS `user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_settings` (
  `user_setting_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `locale` varchar(28) NOT NULL DEFAULT '',
  `setting_name` varchar(255) NOT NULL,
  `setting_value` mediumtext,
  PRIMARY KEY (`user_setting_id`),
  UNIQUE KEY `user_settings_unique` (`user_id`,`locale`,`setting_name`),
  KEY `user_settings_user_id` (`user_id`),
  KEY `user_settings_locale_setting_name_index` (`setting_name`,`locale`),
  CONSTRAINT `user_settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=138 DEFAULT CHARSET=utf8mb3 COMMENT='More data about users, including localized properties like their name and affiliation.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_settings`
--

LOCK TABLES `user_settings` WRITE;
/*!40000 ALTER TABLE `user_settings` DISABLE KEYS */;
INSERT INTO `user_settings` VALUES (1,1,'en','familyName','User1'),(2,1,'en','givenName','Test1'),(3,1,'en','preferredPublicName','Test User 1'),(4,1,'','preferredAvatarInitials','AW'),(5,2,'en','affiliation','Example University'),(6,2,'en','familyName','User2'),(7,2,'en','givenName','Test2'),(8,3,'en','affiliation','Example University'),(9,3,'en','familyName','User3'),(10,3,'en','givenName','Test3'),(11,1,'en','affiliation','Example University'),(12,1,'en','signature',''),(13,4,'en','affiliation','Example University'),(14,4,'en','familyName','User4'),(15,4,'en','givenName','Test4'),(16,5,'en','affiliation','Example University'),(17,5,'en','familyName','User5'),(18,5,'en','givenName','Test5'),(19,6,'en','affiliation','Example University'),(20,6,'en','familyName','User6'),(21,6,'en','givenName','Test6'),(22,7,'en','affiliation','Example University'),(23,7,'en','familyName','User7'),(24,7,'en','givenName','Test7'),(49,12,'en','affiliation','Example University'),(50,12,'en','biography',''),(51,12,'en','familyName','User12'),(52,12,'en','givenName','Test12'),(53,12,'en','preferredPublicName','Test User 12'),(54,12,'en','signature',''),(55,13,'en','affiliation','Example University'),(56,13,'en','biography',''),(57,13,'en','familyName','User13'),(58,13,'en','givenName','Test13'),(59,13,'en','preferredPublicName','Test User 13'),(60,13,'en','signature',''),(61,14,'en','affiliation','Example University'),(62,14,'en','biography',''),(63,14,'en','familyName','User14'),(64,14,'en','givenName','Test14'),(65,14,'en','preferredPublicName','Test User 14'),(66,14,'en','signature',''),(67,15,'en','affiliation','Example University'),(68,15,'en','familyName','User15'),(69,15,'en','givenName','Test15'),(70,16,'en','affiliation','Example University'),(71,16,'en','familyName','User16'),(72,16,'en','givenName','Test16'),(73,2,'en','biography',''),(74,2,'en','preferredPublicName','Test User 2'),(75,2,'en','signature',''),(76,17,'en','affiliation','Example University'),(77,17,'en','familyName','User17'),(78,17,'en','givenName','Test17'),(79,18,'en','affiliation','Example University'),(80,18,'en','familyName','User18'),(81,18,'en','givenName','Test18'),(82,19,'en','affiliation','Example University'),(83,19,'en','familyName','User19'),(84,19,'en','givenName','Test19'),(85,20,'en','affiliation','Example University'),(86,20,'en','familyName','User20'),(87,20,'en','givenName','Test20'),(88,21,'en','affiliation','Example University'),(89,21,'en','familyName','User21'),(90,21,'en','givenName','Test21'),(91,22,'en','affiliation','Example University'),(92,22,'en','familyName','User22'),(93,22,'en','givenName','Test22'),(94,23,'en','affiliation','Example University'),(95,23,'en','familyName','User23'),(96,23,'en','givenName','Test23'),(97,24,'en','affiliation','Example University'),(98,24,'en','familyName','User24'),(99,24,'en','givenName','Test24'),(100,25,'en','affiliation','Example University'),(101,25,'en','familyName','User25'),(102,25,'en','givenName','Test25'),(103,26,'en','affiliation','Example University'),(104,26,'en','familyName','User26'),(105,26,'en','givenName','Test26'),(106,26,'en','preferredPublicName','Test User 26'),(107,26,'','preferredAvatarInitials',''),(108,27,'en','affiliation','Example University'),(109,27,'en','familyName','User27'),(110,27,'en','givenName','Test27'),(111,28,'en','affiliation','Example University'),(112,28,'en','familyName','User28'),(113,28,'en','givenName','Test28'),(114,29,'en','affiliation','Example University'),(115,29,'en','familyName','User29'),(116,29,'en','givenName','Test29'),(117,30,'en','affiliation','Example University'),(118,30,'en','familyName','User30'),(119,30,'en','givenName','Test30'),(120,31,'en','affiliation','Example University'),(121,31,'en','familyName','User31'),(122,31,'en','givenName','Test31'),(123,32,'en','affiliation','Example University'),(124,32,'en','familyName','User32'),(125,32,'en','givenName','Test32'),(126,33,'en','affiliation','Example University'),(127,33,'en','familyName','User33'),(128,33,'en','givenName','Test33'),(129,34,'en','affiliation','Example University'),(130,34,'en','biography',''),(131,34,'en','familyName','User34'),(132,34,'en','givenName','Test34'),(133,34,'en','preferredPublicName','Test User 34'),(134,34,'en','signature',''),(135,35,'en','affiliation','Example University'),(136,35,'en','familyName','User35'),(137,35,'en','givenName','Test35');
/*!40000 ALTER TABLE `user_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_user_groups`
--

DROP TABLE IF EXISTS `user_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_user_groups` (
  `user_user_group_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_group_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `masthead` smallint DEFAULT NULL,
  PRIMARY KEY (`user_user_group_id`),
  KEY `user_user_groups_user_group_id` (`user_group_id`),
  KEY `user_user_groups_user_id` (`user_id`),
  CONSTRAINT `user_user_groups_user_group_id_foreign` FOREIGN KEY (`user_group_id`) REFERENCES `user_groups` (`user_group_id`) ON DELETE CASCADE,
  CONSTRAINT `user_user_groups_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb3 COMMENT='Maps users to their assigned user_groups.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_user_groups`
--

LOCK TABLES `user_user_groups` WRITE;
/*!40000 ALTER TABLE `user_user_groups` DISABLE KEYS */;
INSERT INTO `user_user_groups` VALUES (1,1,1,'2025-08-19 20:47:40',NULL,NULL),(2,2,1,NULL,NULL,NULL),(3,20,1,'2025-09-06 01:42:41',NULL,NULL),(4,21,2,'2025-09-07 00:00:00',NULL,1),(5,16,3,'2025-09-09 01:01:27',NULL,NULL),(6,14,3,'2025-09-09 01:01:31',NULL,NULL),(7,5,4,'2025-09-11 00:00:00',NULL,0),(10,14,6,'2025-10-28 04:35:59',NULL,NULL),(12,14,7,'2025-10-29 16:22:13',NULL,NULL),(17,3,12,'2025-11-13 02:13:09','2025-11-21 17:53:04',1),(18,2,13,'2025-11-13 02:16:39',NULL,1),(19,3,13,'2025-11-13 02:16:39','2025-11-21 17:51:48',1),(20,3,14,'2025-11-14 03:27:59','2025-11-21 17:52:47',1),(21,14,16,'2025-11-21 17:47:03',NULL,NULL),(22,20,13,'2025-11-21 17:52:18',NULL,1),(23,22,14,'2025-11-21 17:52:47','2025-11-21 17:55:31',1),(24,22,12,'2025-11-21 17:53:04','2025-11-21 17:55:40',1),(25,2,2,'2025-11-21 17:53:19',NULL,1),(26,3,14,'2025-11-21 17:55:31',NULL,1),(27,3,12,'2025-11-21 17:55:41',NULL,0),(28,16,17,'2025-11-21 18:15:13',NULL,1),(29,14,18,'2025-11-23 11:22:08',NULL,NULL),(30,16,19,'2025-11-23 16:57:28','2025-11-23 17:20:56',1),(31,16,20,'2025-11-23 17:19:07',NULL,1),(32,14,21,'2025-11-24 16:11:26',NULL,NULL),(33,14,22,'2025-12-19 18:51:15',NULL,NULL),(34,16,23,'2025-12-20 01:00:30',NULL,1),(35,14,24,'2025-12-20 06:27:34',NULL,NULL),(36,16,25,'2025-12-20 06:56:28',NULL,1),(37,16,26,'2025-12-20 07:06:54',NULL,NULL),(38,14,27,'2025-12-26 07:47:36',NULL,NULL),(39,14,28,'2026-01-05 05:31:12',NULL,NULL),(40,14,29,'2026-01-17 01:13:39',NULL,NULL),(41,14,30,'2026-01-20 12:42:52',NULL,NULL),(42,14,31,'2026-02-21 12:19:20',NULL,NULL),(43,14,32,'2026-02-24 14:53:17',NULL,NULL),(44,14,33,'2026-03-03 01:28:00',NULL,NULL),(45,5,34,'2026-07-10 02:52:40',NULL,0),(46,5,12,'2026-07-13 16:49:31',NULL,0),(47,6,12,'2026-07-13 16:49:55',NULL,0),(48,14,35,'2026-07-23 19:58:47',NULL,NULL);
/*!40000 ALTER TABLE `user_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `url` varchar(2047) DEFAULT NULL,
  `phone` varchar(32) DEFAULT NULL,
  `mailing_address` varchar(255) DEFAULT NULL,
  `billing_address` varchar(255) DEFAULT NULL,
  `country` varchar(90) DEFAULT NULL,
  `locales` varchar(255) NOT NULL DEFAULT '[]',
  `gossip` text,
  `date_last_email` datetime DEFAULT NULL,
  `date_registered` datetime NOT NULL,
  `date_validated` datetime DEFAULT NULL,
  `date_last_login` datetime DEFAULT NULL,
  `must_change_password` smallint DEFAULT NULL,
  `auth_id` bigint DEFAULT NULL,
  `auth_str` varchar(255) DEFAULT NULL,
  `disabled` smallint NOT NULL DEFAULT '0',
  `disabled_reason` text,
  `inline_help` smallint DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `users_username` (`username`),
  UNIQUE KEY `users_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3 COMMENT='All registered users, including authentication data and profile data.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'ci_user_1','$2y$12$F5aORFoKX83z6V4xFHYPI.VWfIfpCaqyVHL78nkhL8mj7blP3fGMK','ci_user_1@example.test','','','',NULL,'US','[]',NULL,NULL,'2025-08-19 20:47:39',NULL,'2026-07-24 20:16:04',NULL,NULL,NULL,0,NULL,1,'iaTqcXpigmbv6uUvmSkN499Sq5w4ySxlbKUR227HtGw9UXEDcngBGQAt9K8h'),(2,'ci_user_2','$2y$12$XVBXhE/uxFGDJ/1YXdyGaeOeKdtVCjnxyJRr4uYvNFw1ANBmIwUKS','ci_user_2@example.test','','','',NULL,'US','[]',NULL,NULL,'2025-09-07 17:06:36',NULL,'2025-11-23 15:20:45',0,NULL,NULL,0,NULL,1,'koi8o0B3l1UOyqA0eadlWRNorBsu6CfdHNkO3smJq5bPDS7y1zPdhlGczbDn'),(3,'ci_user_3','$2y$12$i35G31chxRLTWkW2OtKdyumLPNzyCCoEKBa3RVf5M1STY5r100vV6','ci_user_3@example.test','',NULL,NULL,NULL,'GB','[]',NULL,NULL,'2025-09-09 01:01:27',NULL,'2025-09-09 01:01:28',NULL,NULL,NULL,0,NULL,1,NULL),(4,'ci_user_4','$2y$12$HMutmT5/dimnLLj5om/Upe/f6oNuzczZjc0nEEdF60vJ6JezaB1wW','ci_user_4@example.test','',NULL,NULL,NULL,'DE','[]',NULL,NULL,'2025-09-11 06:09:32',NULL,'2025-09-16 14:55:18',NULL,NULL,NULL,0,NULL,1,'0cKTHCeNrgO15MyeecZzfMuAWnRvw1LhkssAgMYxl7K667hJQpJiPJw6hJPc'),(5,'ci_user_5','$2y$12$BgGbkSyrQuoqlebfI2sOlu8.cBsXD7jAXPWOm.xk31GPFyz1uVE7u','ci_user_5@example.test','',NULL,NULL,NULL,'ID','[]',NULL,NULL,'2025-09-27 20:05:45',NULL,'2025-09-27 20:05:45',NULL,NULL,NULL,0,NULL,1,NULL),(6,'ci_user_6','$2y$12$Yh0KI05RwpBHcVemrq29pONw/G4m1gfJWXgCZg4aqwZVVvssviBQ.','ci_user_6@example.test','',NULL,NULL,NULL,'GB','[]',NULL,NULL,'2025-10-28 04:35:55',NULL,'2025-10-28 04:35:56',NULL,NULL,NULL,0,NULL,1,NULL),(7,'ci_user_7','$2y$12$a7eaT59irEM7W73j5sPscu4ZnFDXYRuYOP2WZfjfrvRYLPqvzx/ne','ci_user_7@example.test','',NULL,NULL,NULL,'MY','[]',NULL,NULL,'2025-10-29 16:22:09',NULL,'2025-10-29 16:22:10',NULL,NULL,NULL,0,NULL,1,NULL),(12,'ci_user_12','$2y$12$Esffd7YG127pJjlx3vdW5.oWWUWX5Cmhvb3m6pTuq7S5qNkXKqPJC','ci_user_12@example.test','','','',NULL,'','[]',NULL,NULL,'2025-11-13 02:10:21',NULL,'2025-12-20 01:06:18',0,NULL,NULL,0,NULL,1,'oeAPQlBHlmfRZC3JNstYipnecs6aGcluVMiXDZMaYW2orynWJ5sVZvQV8WPq'),(13,'ci_user_13','$2y$12$G8GugcFAUOs4UoAGM41AVezdtukG661X1AEEfOuPGuhv2mAyrH8Fq','ci_user_13@example.test','','','',NULL,'','[]',NULL,NULL,'2025-11-13 02:16:32',NULL,'2025-12-20 07:42:48',0,NULL,NULL,0,NULL,1,'WuyNgCGEMOmPerKKzfjpHTldZcIyG01vTX4qNcwW5rz4sw7GDuCPIDbHQ5Rf'),(14,'ci_user_14','$2y$12$c3y/LSTiWp/rpZrfdVmkJeOkGWqgrDu7Qhv25DR5SUsjSvtpLhL0W','ci_user_14@example.test','','','',NULL,'','[]',NULL,NULL,'2025-11-13 02:18:22',NULL,'2026-02-26 17:25:08',0,NULL,NULL,0,NULL,1,'YCe55L2XpIRWnTUBafjPzZZaU8kIVyYPAiUTKbMrSzzw3P6B7E5IRCJNUz6U'),(15,'ci_user_15','$2y$12$.VVrQiSrzvsIkTqI3TllaOne7ZG.59A2GZN2CrWU9kDpcGoP0Prai','ci_user_15@example.test','',NULL,NULL,NULL,'US','[]',NULL,NULL,'2025-11-14 03:56:48',NULL,'2025-11-14 03:56:49',NULL,NULL,NULL,0,NULL,1,NULL),(16,'ci_user_16','$2y$12$vY1O9nsC5RUdmZ5yte4Ad.4tcFix2xBz1NwIK1tKXWIk3l8BxigJW','ci_user_16@example.test','',NULL,NULL,NULL,'US','[]',NULL,NULL,'2025-11-21 17:47:00',NULL,'2025-11-21 17:47:01',NULL,NULL,NULL,0,NULL,1,NULL),(17,'ci_user_17','$2y$12$svwcQV0QFyVhqIr.N1GjQ.ARRWUJOGghciC1mr.ej7U1dmQtAPLCS','ci_user_17@example.test','',NULL,NULL,NULL,NULL,'[]',NULL,NULL,'2025-11-21 18:15:13',NULL,'2026-07-11 16:54:41',1,NULL,NULL,0,NULL,1,NULL),(18,'ci_user_18','$2y$12$mQf.EldNGrjlRc4bSB.zh.aBFjkbMYhZ5qNCPoWXmZs4FctZyQTEG','ci_user_18@example.test','',NULL,NULL,NULL,'US','[]',NULL,NULL,'2025-11-23 11:22:04',NULL,'2025-11-23 11:22:05',NULL,NULL,NULL,0,NULL,1,NULL),(19,'ci_user_19','$2y$12$yKpOl6dl/zWZB3p2mfW2UOyFlpX.7ktZDLqGO7bdG3UFTR8jqd.6a','ci_user_19@example.test','',NULL,NULL,NULL,NULL,'[]',NULL,NULL,'2025-11-23 16:57:28',NULL,NULL,1,NULL,NULL,1,'',1,NULL),(20,'ci_user_20','$2y$12$VVi1U4gS8ypswPYYvnd2w.xI8MH3Ex.t3JHl7CmItTP.DM3ICUAQS','ci_user_20@example.test','',NULL,NULL,NULL,NULL,'[]',NULL,NULL,'2025-11-23 17:19:07',NULL,NULL,1,NULL,NULL,0,NULL,1,NULL),(21,'ci_user_21','$2y$12$4Rk4CiSPlihWvi2PZStcLuGeIqFdJHXhQG4V34XGXPdhxPilsAegC','ci_user_21@example.test','',NULL,NULL,NULL,'ID','[]',NULL,NULL,'2025-11-24 16:11:22',NULL,'2025-11-24 16:11:23',NULL,NULL,NULL,0,NULL,1,NULL),(22,'ci_user_22','$2y$12$pVOhGzbNSI8qPi5Eq1TXrem3AZyww59RaKdSo4if9GBk0oYZiPLhK','ci_user_22@example.test','',NULL,NULL,NULL,'CA','[]',NULL,NULL,'2025-12-19 18:25:19',NULL,'2025-12-19 18:25:20',NULL,NULL,NULL,0,NULL,1,NULL),(23,'ci_user_23','$2y$12$Aa3IzEQ.vChCvG3oTt96.OkBLTxD8JWcm.oGLL0SaUqAn7nipyVpq','ci_user_23@example.test','',NULL,NULL,NULL,NULL,'[]',NULL,NULL,'2025-12-20 01:00:30',NULL,'2025-12-20 01:03:31',0,NULL,NULL,0,NULL,1,'HVGEtJCl7kH4iTPsu1hbcj2TUus0XjRyGSyjVMfRGMqot9zXtdtXTJfTUopD'),(24,'ci_user_24','$2y$12$wGiHTrgx0oZQe79r9meYPeXGKZ.9N7EZjNlO6PPyY31jG4vMTPPZm','ci_user_24@example.test','',NULL,NULL,NULL,'UM','[]',NULL,NULL,'2025-12-20 06:27:33',NULL,'2025-12-20 06:35:38',NULL,NULL,NULL,0,NULL,1,'PQ9j9QTr60eMLBz311g9pMgYH2BEcCdtyRDVr905hPmdLgb0ArW2INKQyuob'),(25,'ci_user_25','$2y$12$eunoFd2H8GQsszjqrDn/SOGGQUkdW/ZjHe3J4xDci9Gj.SIuXsG8i','ci_user_25@example.test','',NULL,NULL,NULL,NULL,'[]',NULL,NULL,'2025-12-20 06:56:28',NULL,NULL,1,NULL,NULL,0,NULL,1,NULL),(26,'ci_user_26','$2y$12$cTsttuaPgDu8xlGca54JdubMLQ/5ElgxHRFnoThKqYNssASWpgC8S','ci_user_26@example.test','',NULL,NULL,NULL,'RO','[]',NULL,NULL,'2025-12-20 07:05:14',NULL,'2025-12-20 07:37:24',0,NULL,NULL,0,NULL,1,'WtPIVLGzfqE9U9rYGKLTR7eG9quFkyzFOQ5B15pWHtMqORVJKOK00FFvlGCn'),(27,'ci_user_27','$2y$12$lw/8X6eetGBbaFTbbJDEx.xxKjPYL0lzJedxDTxPoookX6vv67iNu','ci_user_27@example.test','',NULL,NULL,NULL,'MY','[]',NULL,NULL,'2025-12-26 07:47:32',NULL,'2025-12-26 07:47:33',NULL,NULL,NULL,0,NULL,1,NULL),(28,'ci_user_28','$2y$12$FJNNN4zPlw1eQE/YNUA5RO3WbfqXVURDi5T5JyNuxG2gcvauhpHnW','ci_user_28@example.test','',NULL,NULL,NULL,'CA','[]',NULL,NULL,'2026-01-05 05:31:08',NULL,'2026-01-05 05:31:09',NULL,NULL,NULL,0,NULL,1,NULL),(29,'ci_user_29','$2y$12$Cwmr0vdD1ep.gtguKxLlG.oeYUs63IaD0iupTFc6f2ifGbbSMvI/y','ci_user_29@example.test','',NULL,NULL,NULL,'US','[]',NULL,NULL,'2026-01-17 01:13:35',NULL,'2026-01-17 01:13:36',NULL,NULL,NULL,0,NULL,1,NULL),(30,'ci_user_30','$2y$12$vN7lUifkYqhnooxa2CowMOMZOn4Lrfs7mgweZb0shCs.3MhgMM2zy','ci_user_30@example.test','',NULL,NULL,NULL,'AU','[]',NULL,NULL,'2026-01-20 12:42:48',NULL,'2026-01-20 12:42:48',NULL,NULL,NULL,0,NULL,1,NULL),(31,'ci_user_31','$2y$12$ZATCbcIhbm3ci.uVo/S9Uupi0WiN4aeec9dsBplduUmWmKFYq6ToO','ci_user_31@example.test','',NULL,NULL,NULL,'MY','[]',NULL,NULL,'2026-02-21 12:19:15',NULL,'2026-02-21 12:19:16',NULL,NULL,NULL,0,NULL,1,NULL),(32,'ci_user_32','$2y$12$SKI7HQxWKZhv1Vcyf6c8beZ3QPhe8eICzeicwyDyK18Zoxowx9GhK','ci_user_32@example.test','',NULL,NULL,NULL,'ID','[]',NULL,NULL,'2026-02-24 14:53:13',NULL,'2026-02-24 14:53:14',NULL,NULL,NULL,0,NULL,1,NULL),(33,'ci_user_33','$2y$12$NpYHskmZnsMo3uDahf4wl.iGjA6cLakBO/ZXXCOJoVwwpK6Vnp8j6','ci_user_33@example.test','',NULL,NULL,NULL,'CA','[]',NULL,NULL,'2026-03-03 01:27:56',NULL,'2026-03-03 01:27:57',NULL,NULL,NULL,0,NULL,1,NULL),(34,'ci_user_34','$2y$12$upIdCTkJRkgonhvqd2mnVOlatuCFjlkIxHsHlge/yE04pL8fIiF3G','ci_user_34@example.test','','','',NULL,'US','[]',NULL,NULL,'2026-07-10 02:52:08',NULL,NULL,1,NULL,NULL,0,NULL,1,NULL),(35,'ci_user_35','$2y$12$73PWXDi7JwFWs2iAmR18uuUQHCO8LeGRtsz.kYfeUZ.8NGbG8NO5W','ci_user_35@example.test','',NULL,NULL,NULL,'US','[]',NULL,NULL,'2026-07-23 19:58:26',NULL,'2026-07-23 19:58:27',NULL,NULL,NULL,0,NULL,1,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `versions`
--

DROP TABLE IF EXISTS `versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `versions` (
  `version_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `major` int NOT NULL DEFAULT '0' COMMENT 'Major component of version number, e.g. the 2 in OJS 2.3.8-0',
  `minor` int NOT NULL DEFAULT '0' COMMENT 'Minor component of version number, e.g. the 3 in OJS 2.3.8-0',
  `revision` int NOT NULL DEFAULT '0' COMMENT 'Revision component of version number, e.g. the 8 in OJS 2.3.8-0',
  `build` int NOT NULL DEFAULT '0' COMMENT 'Build component of version number, e.g. the 0 in OJS 2.3.8-0',
  `date_installed` datetime NOT NULL,
  `current` smallint NOT NULL DEFAULT '0' COMMENT '1 iff the version entry being described is currently active. This permits the table to store past installation history for forensic purposes.',
  `product_type` varchar(30) DEFAULT NULL COMMENT 'Describes the type of product this row describes, e.g. "plugins.generic" (for a generic plugin) or "core" for the application itself',
  `product` varchar(30) DEFAULT NULL COMMENT 'Uniquely identifies the product this version row describes, e.g. "ojs2" for OJS 2.x, "languageToggle" for the language toggle block plugin, etc.',
  `product_class_name` varchar(80) DEFAULT NULL COMMENT 'Specifies the class name associated with this product, for plugins, or the empty string where not applicable.',
  `lazy_load` smallint NOT NULL DEFAULT '0' COMMENT '1 iff the row describes a lazy-load plugin; 0 otherwise',
  `sitewide` smallint NOT NULL DEFAULT '0' COMMENT '1 iff the row describes a site-wide plugin; 0 otherwise',
  PRIMARY KEY (`version_id`),
  UNIQUE KEY `versions_unique` (`product_type`,`product`,`major`,`minor`,`revision`,`build`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb3 COMMENT='Describes the installation and upgrade version history for the application and all installed plugins.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `versions`
--

LOCK TABLES `versions` WRITE;
/*!40000 ALTER TABLE `versions` DISABLE KEYS */;
INSERT INTO `versions` VALUES (1,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.metadata','dc11','',0,0),(2,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.blocks','languageToggle','LanguageToggleBlockPlugin',1,0),(3,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.blocks','developedBy','DevelopedByBlockPlugin',1,0),(4,1,0,1,0,'2025-08-19 20:47:40',1,'plugins.blocks','browse','BrowseBlockPlugin',1,0),(5,1,1,0,0,'2025-08-19 20:47:40',1,'plugins.blocks','subscription','SubscriptionBlockPlugin',1,0),(6,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.blocks','makeSubmission','MakeSubmissionBlockPlugin',1,0),(7,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.blocks','information','InformationBlockPlugin',1,0),(8,1,0,8,0,'2025-08-19 20:47:40',1,'plugins.generic','jatsTemplate','JatsTemplatePlugin',1,0),(9,0,1,0,0,'2025-08-19 20:47:40',1,'plugins.generic','citationStyleLanguage','CitationStyleLanguagePlugin',1,0),(10,3,0,0,0,'2025-08-19 20:47:40',1,'plugins.generic','crossref','CrossrefPlugin',0,0),(11,1,2,0,0,'2025-08-19 20:47:40',1,'plugins.generic','credit','CreditPlugin',1,0),(12,1,2,0,0,'2025-08-19 20:47:40',1,'plugins.generic','customBlockManager','CustomBlockManagerPlugin',1,0),(13,1,0,1,0,'2025-08-19 20:47:40',1,'plugins.generic','lensGalley','LensGalleyPlugin',1,0),(14,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.generic','webFeed','WebFeedPlugin',1,0),(15,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.generic','driver','DRIVERPlugin',1,0),(16,1,0,1,0,'2025-08-19 20:47:40',1,'plugins.generic','pdfJsViewer','PdfJsViewerPlugin',1,0),(17,1,2,0,0,'2025-08-19 20:47:40',1,'plugins.generic','staticPages','StaticPagesPlugin',1,0),(18,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.generic','announcementFeed','AnnouncementFeedPlugin',1,0),(19,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.generic','tinymce','TinyMCEPlugin',1,0),(20,2,0,0,0,'2025-08-19 20:47:40',1,'plugins.generic','datacite','DatacitePlugin',0,0),(21,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.generic','recommendBySimilarity','RecommendBySimilarityPlugin',1,1),(22,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.generic','htmlArticleGalley','HtmlArticleGalleyPlugin',1,0),(23,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.generic','dublinCoreMeta','DublinCoreMetaPlugin',1,0),(24,1,0,0,1,'2025-08-19 20:47:40',1,'plugins.generic','recommendByAuthor','RecommendByAuthorPlugin',1,1),(25,1,1,0,0,'2025-08-19 20:47:40',1,'plugins.generic','googleScholar','GoogleScholarPlugin',1,0),(26,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.generic','googleAnalytics','GoogleAnalyticsPlugin',1,0),(27,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.generic','usageEvent','',0,0),(28,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.importexport','users','',0,0),(29,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.importexport','pubmed','',0,0),(30,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.importexport','native','',0,0),(31,1,1,0,0,'2025-08-19 20:47:40',1,'plugins.importexport','doaj','',0,0),(32,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.oaiMetadataFormats','dc','',0,0),(33,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.oaiMetadataFormats','marcxml','',0,0),(34,1,0,6,0,'2025-08-19 20:47:40',0,'plugins.oaiMetadataFormats','oaiJats','',0,0),(35,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.oaiMetadataFormats','marc','',0,0),(36,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.oaiMetadataFormats','rfc1807','',0,0),(37,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.paymethod','manual','',0,0),(38,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.paymethod','paypal','',0,0),(39,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.pubIds','urn','URNPubIdPlugin',1,0),(40,2,0,1,0,'2025-08-19 20:47:40',1,'plugins.reports','reviewReport','',0,0),(41,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.reports','articles','',0,0),(42,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.reports','subscriptions','',0,0),(43,1,1,0,0,'2025-08-19 20:47:40',1,'plugins.reports','counterReport','',0,0),(44,1,0,0,0,'2025-08-19 20:47:40',1,'plugins.themes','default','DefaultThemePlugin',1,0),(45,3,5,0,1,'2025-08-19 20:47:22',0,'core','ojs2','',0,1),(46,1,1,2,2,'2025-08-19 22:13:38',1,'plugins.themes','classic','ClassicThemePlugin',1,0),(47,1,0,0,0,'2025-08-20 04:12:59',1,'plugins.themes','post45','Post45ThemePlugin',1,0),(48,1,1,3,0,'2025-08-20 04:38:17',1,'plugins.themes','pragma','PragmaThemePlugin',1,0),(49,1,0,0,0,'2025-09-04 18:26:13',1,'plugins.generic','mailgun','MailgunPlugin',1,1),(50,1,0,0,0,'2025-10-07 03:33:23',1,'plugins.generic','submissionsOnly','SubmissionsOnlyPlugin',1,0),(51,1,0,0,0,'2025-10-07 03:33:23',1,'plugins.generic','colorPalettes','ColorPalettesPlugin',1,0),(52,1,0,0,0,'2025-10-07 03:33:23',0,'plugins.themes','pragmaSubmissions','PragmaSubmissionsThemePlugin',1,0),(53,1,2,1,4,'2026-06-19 19:56:47',1,'plugins.generic','pflPlugin','PflPlugin',1,0),(54,1,0,6,1,'2026-06-19 19:56:47',1,'plugins.oaiMetadataFormats','oaiJats','',0,0),(55,3,5,0,4,'2026-06-19 19:56:46',1,'core','ojs2','',0,1),(56,1,0,0,0,'2026-07-05 21:42:11',0,'plugins.generic','post45Editorial','Post45EditorialPlugin',1,0),(58,2,0,0,0,'2026-07-10 18:01:50',0,'plugins.generic','post45Cfp','Post45CfpPlugin',1,0),(59,2,1,0,0,'2026-07-14 17:48:17',0,'plugins.generic','post45Cfp','Post45CfpPlugin',1,0),(60,1,0,3,0,'2026-07-23 23:02:04',0,'plugins.generic','post45Editorial','Post45EditorialPlugin',1,0),(61,2,1,1,0,'2026-07-25 17:39:35',1,'plugins.generic','post45Cfp','Post45CfpPlugin',1,0),(62,1,0,6,0,'2026-07-25 17:39:35',0,'plugins.generic','post45Editorial','Post45EditorialPlugin',1,0),(63,1,5,0,0,'2026-07-25 17:39:35',1,'plugins.themes','pragmaSubmissions','PragmaSubmissionsThemePlugin',1,0),(64,1,0,7,0,'2026-07-25 18:34:06',1,'plugins.generic','post45Editorial','Post45EditorialPlugin',1,0),(65,1,0,0,0,'2026-07-30 17:19:35',1,'plugins.generic','smtpLocalDomain','SmtpLocalDomainPlugin',1,1);
/*!40000 ALTER TABLE `versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ojs_test_ci'
--

--
-- Dumping routines for database 'ojs_test_ci'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-05 15:34:32
